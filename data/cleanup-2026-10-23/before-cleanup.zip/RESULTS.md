# BAIZE — Results

All thresholds were derived from σ_c and **frozen before any federated run
existed** (`DECISIONS.md` D-017). No threshold was adjusted after seeing a
result.

**σ_c = 0.00718** — cross-seed standard deviation of centralized test PR-AUC on
the domain-aware split, 5 seeds, converged.

---

## Headline findings

### RQ1 — Random splits inflate performance by 23.6%

Paired over 5 seeds at identical budget, domain-aware vs random splitting:

| split regime | test PR-AUC | sd |
|---|---:|---:|
| Random | 0.7598 | 0.0034 |
| **Domain-aware (primary)** | **0.6145** | **0.0072** |

Inflation **0.1452 absolute, 23.6% relative, 20.2 σ_c**; paired t = 34.2,
p = 4.4×10⁻⁶. Roughly a fifth of apparent performance in a randomly-split URL
classifier is registrable-domain memorisation rather than generalisation to
unseen sites.

Notable: this holds despite 93% of domains contributing a single URL. The effect
is carried by a concentrated minority of multi-URL domains (`geocities.com`
alone is 53,959 URLs), so a corpus without large free-hosting blocks might show
a smaller gap.

---

### H1 — Federated learning is nearly free under IID data

FedAvg, 10 IID clients, 60 rounds, vs centralized. **Not a matched-budget
comparison** — see corrections below. At this (federated-heavier) compute:

| | test PR-AUC | sd |
|---|---:|---:|
| Centralized | 0.6145 | 0.0072 |
| FedAvg (IID) | 0.6112 | 0.0072 |
| **gap** | **0.0033** | 0.0005 |

0.47 σ_c against a 0.0144 threshold, 0 of 5 seeds exceeding. **H1 SUPPORTED.**

The gap is statistically distinguishable from zero (paired t = 14.68,
p = 0.0001) while being far inside the practical-equivalence bound. Those are
different claims: FedAvg is *measurably but negligibly* worse than centralized
here.

---

### H4 — Data heterogeneity is what costs you

Label skew (Dirichlet α = 1.0) vs IID, matched budget within each seed:

| seed | rounds | IID | non-IID | gap |
|---:|---:|---:|---:|---:|
| 0 | 80/80 | 0.6174 | 0.5936 | 0.0238 |
| 1 | 60/60 | 0.6063 | 0.5765 | 0.0298 |
| 2 | 60/60 | 0.6152 | 0.5820 | 0.0332 |
| **mean** | | **0.6130** | **0.5840** | **0.0289** |

**4.03 σ_c**, 3 of 3 seeds over threshold, paired t = 10.59, p = 0.0088.
**H4 SUPPORTED.**

Set against H1, this is the central structural result: the federated
*architecture* costs 0.0033, while dropping the IID assumption costs 0.0289 —
roughly **8.5× more**. Federation is not the expensive part; heterogeneity is.

---

### H3 — Robust aggregation pays only against *identifiable* corruption

The same aggregator, same corpus, same threshold, two noise structures:

| noise structure | trimmed mean vs FedAvg |
|---|---:|
| **Homogeneous** — all 10 clients at 20% | **−0.0041** (hurts) |
| **Heterogeneous** — 3 of 10 clients at 40% | **+0.0800** (helps) |

Heterogeneous condition, 3 seeds:

| seed | FedAvg | best rnd | convergence | trimmed (β=0.3) | gain |
|---:|---:|---:|---|---:|---:|
| 0 | 0.5015 | 18 | DEGRADING | 0.5850 | +0.0835 |
| 1 | 0.5009 | 13 | CONVERGED | 0.5775 | +0.0766 |
| 2 | 0.5069 | 12 | DEGRADING | 0.5869 | +0.0801 |
| **mean** | **0.5031** | | | **0.5831** | **+0.0800** |

**11.1 σ_c**, 3 of 3 seeds, paired t = 40.30, p = 0.0006. **H3 SUPPORTED.**

The gain is a **lower bound**: FedAvg converged or degraded early in every seed
(best round 12–18 of 40) while trimmed mean was still improving at the cap.

**Why the sign flips.** Trimmed mean removes outlying coordinates. When every
client is equally corrupted there is nothing in the tails to trim, so trimming
discards honest gradient signal and costs performance. When corruption
concentrates in a minority, the corrupted updates *are* the tails and trimming
removes them almost cleanly. This was predicted in `THREAT_MODEL.md` §4
("assumes corrupted fraction < β") **before any experiment was run** — the
homogeneous negative is a documented prediction, not a post-hoc explanation.

#### β sensitivity (heterogeneous noise, 34 rounds, seed 0)

| β | trimmed/tail | removed | test PR-AUC | vs FedAvg |
|---:|---:|---:|---:|---:|
| 0 (FedAvg) | 0 | 0 | 0.5015 | — |
| 0.1 | 1 | 2 | 0.5481 | +0.047 |
| 0.3 | 3 | 6 | 0.5814 | +0.080 |
| 0.4 | 4 | 8 | 0.5795 | +0.078 |

Every β clears the threshold, including β = 0.1, which under-trims relative to
the 30% corrupted fraction. The advantage does **not** require knowing the
corruption rate. Under-trimming is costly (4.6 σ_c penalty); over-trimming is
nearly free. Practical reading: when the corruption rate is unknown, **err
high** — at least under IID data.

---

### H5 — No measurable cost under benign heterogeneity

Clean non-IID (α = 1.0), trimmed mean β = 0.3 vs FedAvg:

| seed | rounds | FedAvg | trimmed | diff |
|---:|---:|---:|---:|---:|
| 0 | 80/80 | 0.5936 | 0.5879 | −0.0057 |
| 1 | 60/60 | 0.5765 | 0.5778 | +0.0013 |
| 2 | 60/60 | 0.5820 | 0.5864 | +0.0044 |
| **mean** | | **0.5840** | **0.5840** | **−0.0000** |

0.00 σ_c, paired t = 0.00, **p = 0.997**. **H5 NOT SUPPORTED.**

H5 was included deliberately to test whether BAIZE's own proposed mechanism has
a downside. It does not, at this skew level. The sign is not even consistent
across seeds. The single-seed result reported earlier (−0.0057) was seed noise.

---

## What this adds up to

On this task, **trimmed-mean aggregation is close to a free option**: large
gains when corruption concentrates in a minority of clients, no measurable cost
when it does not, and insensitivity to β provided you avoid under-trimming.

H5's negative is what makes that recommendation unconditional. Had trimming been
expensive under benign heterogeneity, every recommendation would have had to be
conditioned on knowing the threat model in advance.

---

## Limitations — read before citing anything above

1. **The corpus predates ~2010.** HTTPS is 0.068% of rows; ~6.7% sits on
   Geocities, Tripod, Angelfire and similar. Every number here describes the
   pre-2010 web. No claim is made about live browsing today.
2. **Label noise floor is unmeasured.** 148 conflicting URLs is a *lower bound*.
   Injected noise sits on top of an unknown intrinsic rate, so RQ3 conditions are
   quoted against an uncertain baseline. The label audit is outstanding.
3. **Licence and provenance unverified** (D-014). Blocks publication.
4. **α = 1.0 was forced by the corpus.** At α = 0.5 the Dirichlet construction
   produced degenerate partitions (one client 100% positive with 589 samples) and
   at α = 0.1 an empty client. The standard non-IID construction does not
   transfer cleanly to a 2.4%-positive binary problem. A sharper skew might yet
   expose an H5 cost.
5. **One model family.** Logistic regression over hashed character n-grams.
6. **Server holds a clean validation set** (D-004) — a strong assumption that
   would not hold in a real deployment where nobody has clean labels.
7. **H2 has one seed.** The 20% and 40% noise results are signals, not decisions.
8. **Only trimmed mean was tested.** Coordinate median and norm clipping are
   implemented and tested but not run.

---

## Corrections from code review (D-026)

These are write-up corrections. The JSON numbers above were not recomputed.

1. **H1 is not matched-budget.** Centralized E1 sees 35 passes per example.
   FedAvg E2 sees `rounds × local_epochs` = 180 (seed 0 later 240) passes per
   example — about 5–7× more local SGD. `RESEARCH.md` §4.5 defined matching as
   comparable total gradient steps. The 0.0033 gap is therefore "FedAvg almost
   matches centralized **when given much more local work**." New runs record
   `training_budget.passes_per_example` so this cannot be missed again.
   Seed 0 was extended to 80 rounds while seeds 1–4 stopped at 60.
2. **H3 as decided is not the pre-registered H3.** The frozen rule was: at
   ≥30% noise, best robust aggregator beats FedAvg by > 2σ_c (E7). The decision
   JSON is E9: 3 of 10 clients at 40%, rest clean, 3 seeds, trimmed mean β=0.3.
   The homogeneous "hurts by −0.004" figure is **one seed at 20%**, inside seed
   noise, and must not be tabled as a finding. Class-conditional noise,
   quantity skew, coordinate median, and norm clipping were never run.
3. **Provenance.** Later federated files record `git_commit: …-DIRTY`. E1 JSONL
   rows have no git commit. Those runs are not tied to a clean tree.
4. **`E1_summary_lr160.json` caveat is stale.** It still says "not converged at
   40 epochs / best epoch = 40." The lr=160 JSONL has best epochs 30–35. The
   aggregator script no longer writes that caveat for un-pinned runs.

New pipeline behaviour (does not change the tables above): centralized
`run_experiment` selects the best validation epoch; val/test labels are
`mark_protected`; federated clients index a shared training matrix; unknown
source categories are dropped rather than mapped to 0; `NormalizedURL.raw`
no longer retains query/userinfo/port.

---

## Reproducing

```bash
pip install -r requirements.txt
python scripts/prepare_cache.py data/raw/url.csv
python scripts/e1_multiseed.py domain_aware 0 1 2 3 4
python scripts/e1_aggregate.py
python scripts/fedavg_run.py --tag e2_iid_seed0 --rounds 60
```

Runs are checkpointed and resumable; resume equivalence is proven bit-identical
(D-021). Every result JSON carries a git commit, dataset fingerprint, and the
full environment record.
