"""Phase 3 probe: what does one real federated run cost, and at what local LR?

Three unknowns block the whole federated matrix:
  1. local learning rate (the centralized optimum of 160 need not transfer)
  2. how many rounds until the global model plateaus
  3. wall-clock per run, which determines whether the matrix fits the schedule

This probe measures all three. It is NOT an experiment - no hypothesis is tested
and nothing here may be quoted as a result. It exists to parameterise E2 onward.

Usage:
    python scripts/phase3_probe.py lr 40 160 400     # LR sweep, short
    python scripts/phase3_probe.py rounds 160        # convergence at chosen LR
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import scipy.sparse as sp

from baize.data.partition import partition
from baize.evaluation.metrics import classification_metrics
from baize.federated.aggregation import fedavg
from baize.hparams import BATCH, L2, N_CLIENTS, SPLIT
from baize.models.linear import LogisticSGD, init_params

CACHE = Path("data/cache")
OUT = Path("experiments/results")
STRATEGY = SPLIT
SEED = 0


def build(seed: int = SEED):
    X = sp.load_npz(CACHE / "X.npz")
    store = np.load(CACHE / "split_indices.npz")
    labels = store["labels"]
    i_tr = store[f"{STRATEGY}_{seed}_train"]
    i_va = store[f"{STRATEGY}_{seed}_val"]
    y_tr, y_va = labels[i_tr], labels[i_va]
    parts, prep = partition(y_tr, "iid", n_clients=N_CLIENTS, seed=seed)
    if not prep.status.startswith("PASS"):
        raise RuntimeError(prep.status)
    # map client-local positions -> global row ids in the shared matrix
    global_parts = [i_tr[p] for p in parts]
    return X, y_tr, parts, global_parts, i_va, y_va, prep


def run(X, y_tr, parts, global_parts, i_va, y_va, lr, rounds, local_epochs, seed=SEED,
        verbose=True):
    """Minimal FedAvg loop, written inline so the probe has no hidden defaults."""
    n_features = X.shape[1]
    g = init_params(n_features)
    evaluator = LogisticSGD(n_features, l2=L2)
    models = [LogisticSGD(n_features, l2=L2, seed=seed * 100 + c) for c in range(len(parts))]
    rngs = [np.random.default_rng(seed * 1000 + c) for c in range(len(parts))]
    weights = np.array([len(p) for p in parts], dtype=np.float64)

    curve, t0 = [], time.time()
    for rnd in range(1, rounds + 1):
        deltas = []
        for c, (rows, local_idx) in enumerate(zip(global_parts, parts)):
            models[c].set_params(g)
            models[c].fit(X, y_tr[local_idx], epochs=local_epochs, batch_size=BATCH,
                          lr=lr, rng=rngs[c], indices=rows, compute_loss=False)
            deltas.append(models[c].get_params() - g)
        agg, _ = fedavg(deltas, weights=weights)
        g = g + agg
        if not np.all(np.isfinite(g)):
            print(f"    DIVERGED at round {rnd} (lr={lr})")
            return curve, float("nan"), time.time() - t0
        evaluator.set_params(g)
        pr = classification_metrics(y_va, evaluator.predict_proba_chunked(X, i_va))["pr_auc"]
        curve.append({"round": rnd, "val_pr_auc": pr})
        if verbose and (rnd % 5 == 0 or rnd <= 3):
            print(f"    round {rnd:>3}  val PR-AUC={pr:.4f}  ({time.time() - t0:.0f}s)",
                  flush=True)
    return curve, curve[-1]["val_pr_auc"], time.time() - t0


def main() -> None:
    mode = sys.argv[1]
    OUT.mkdir(parents=True, exist_ok=True)
    X, y_tr, parts, global_parts, i_va, y_va, prep = build()
    print(f"clients={N_CLIENTS} strategy=iid  shard sizes "
          f"min={min(prep.sizes):,} max={max(prep.sizes):,}  "
          f"pos_rate spread={max(prep.positive_rates) - min(prep.positive_rates):.4f}\n",
          flush=True)

    if mode == "lr":
        lrs = [float(a) for a in sys.argv[2:]]
        results = {}
        for lr in lrs:
            print(f"  lr={lr}", flush=True)
            curve, final, secs = run(X, y_tr, parts, global_parts, i_va, y_va,
                                     lr=lr, rounds=8, local_epochs=1, verbose=False)
            per_round = secs / max(len(curve), 1)
            results[lr] = {"final": final, "secs": secs, "per_round": per_round,
                           "curve": curve}
            pts = " ".join(f"r{c['round']}={c['val_pr_auc']:.4f}" for c in curve[::2])
            print(f"    {pts}   final={final:.4f}  ({secs:.0f}s, "
                  f"{per_round:.1f}s/round)", flush=True)
        (OUT / "phase3_probe_lr.json").write_text(json.dumps(results, indent=2, default=str))

    elif mode == "rounds":
        lr = float(sys.argv[2])
        local_epochs = int(sys.argv[3]) if len(sys.argv) > 3 else 3
        ROUNDS = int(sys.argv[4]) if len(sys.argv) > 4 else 25
        print(f"  convergence probe: lr={lr}, local_epochs={local_epochs}", flush=True)
        curve, final, secs = run(X, y_tr, parts, global_parts, i_va, y_va,
                                 lr=lr, rounds=ROUNDS, local_epochs=local_epochs)
        per_round = secs / max(len(curve), 1)
        print(f"\n  final val PR-AUC={final:.4f}  {secs:.0f}s total, "
              f"{per_round:.1f}s/round")
        print(f"  projected 50-round run: {per_round * 50 / 60:.1f} min")
        (OUT / "phase3_probe_rounds.json").write_text(json.dumps(
            {"lr": lr, "local_epochs": local_epochs, "curve": curve,
             "secs": secs, "per_round": per_round}, indent=2))
    else:
        raise SystemExit("mode must be 'lr' or 'rounds'")


if __name__ == "__main__":
    main()
