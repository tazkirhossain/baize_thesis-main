"""E2 aggregate and the H1 decision.

H1 (RESEARCH.md §2): FedAvg under an IID partition is competitive with
centralized training. Frozen decision rule (DECISIONS.md D-017):

    SUPPORTED  if mean centralized-minus-FedAvg PR-AUC gap <= 2*sigma_c = 0.0144
    FALSIFIED  if the gap exceeds it consistently across seeds

The threshold was frozen from E1 before any federated run existed. It is read
here, not recomputed, so the decision cannot drift to fit the data.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
from scipy import stats

from baize.hparams import BATCH, CENTRALIZED_EPOCHS, LOCAL_EPOCHS, LR, N_CLIENTS, ROUNDS

OUT = Path("experiments/results")
SEEDS = [0, 1, 2, 3, 4]


def main() -> None:
    summary = json.loads((OUT / "E1_summary_lr160.json").read_text())
    sigma_c = summary["sigma_c"]
    threshold = 2 * sigma_c

    cen_rows = sorted(
        [json.loads(l) for l in (OUT / "E1_domain_aware_seeds_lr160.jsonl")
         .read_text().splitlines() if l.strip()],
        key=lambda r: r["seed"],
    )
    cen = {r["seed"]: r for r in cen_rows}

    fed = {}
    for s in SEEDS:
        d = json.loads((OUT / f"e2_iid_seed{s}.json").read_text())
        fed[s] = d

    print("=" * 74)
    print("BAIZE E2 - FEDAVG (IID, 10 clients) vs CENTRALIZED")
    print("=" * 74)
    print(f"  split=domain_aware  rounds (declared)={ROUNDS}  "
          f"local_epochs={LOCAL_EPOCHS}  lr={LR}  batch={BATCH}  clients={N_CLIENTS}")
    print("  NOTE: compare per-seed config['rounds'] — seed 0 was extended to 80;")
    print("  H1 is NOT a matched-budget comparison (federated passes_per_example")
    print("  = rounds*local_epochs, centralized = 35). See RESULTS.md corrections.")
    print(f"  sigma_c = {sigma_c:.5f}  (frozen from E1, D-017)")
    print(f"  H1 threshold = 2*sigma_c = {threshold:.5f}\n")

    print(f"  {'seed':>5}{'centralized':>14}{'FedAvg':>12}{'gap':>10}"
          f"{'best rnd':>10}{'plateau':>9}")
    gaps, c_arr, f_arr = [], [], []
    for s in SEEDS:
        c = cen[s]["pr_auc"]
        f = fed[s]["test_metrics"]["pr_auc"]
        gaps.append(c - f)
        c_arr.append(c)
        f_arr.append(f)
        print(f"  {s:>5}{c:>14.4f}{f:>12.4f}{c - f:>10.4f}"
              f"{fed[s]['best_round']:>10}{str(fed[s]['plateaued']):>9}")

    gaps = np.array(gaps)
    c_arr, f_arr = np.array(c_arr), np.array(f_arr)
    print(f"  {'mean':>5}{c_arr.mean():>14.4f}{f_arr.mean():>12.4f}{gaps.mean():>10.4f}")
    print(f"  {'sd':>5}{c_arr.std(ddof=1):>14.4f}{f_arr.std(ddof=1):>12.4f}"
          f"{gaps.std(ddof=1):>10.4f}")

    t = stats.ttest_rel(c_arr, f_arr)
    w = stats.wilcoxon(c_arr, f_arr)

    print("\n" + "=" * 74)
    print("H1 DECISION")
    print("=" * 74)
    print(f"  mean gap (centralized - FedAvg) : {gaps.mean():.5f}")
    print(f"  gap in sigma_c units            : {gaps.mean() / sigma_c:.2f}")
    print(f"  frozen threshold (2 sigma_c)    : {threshold:.5f}")
    print(f"  seeds where gap exceeds thresh  : {int((gaps > threshold).sum())} of {len(gaps)}")
    print(f"  paired t-test                   : t={t.statistic:.2f}, p={t.pvalue:.4f}")
    print(f"  Wilcoxon signed-rank            : W={w.statistic:.1f}, p={w.pvalue:.4f}")

    supported = gaps.mean() <= threshold
    verdict = "SUPPORTED" if supported else "FALSIFIED"
    print(f"\n  ==> H1 {verdict}")
    if supported:
        print("      FedAvg over 10 IID clients reaches centralized performance")
        print("      within the pre-registered tolerance on this corpus.")
    print("\n  Scope: IID partition, 10 clients, full participation, clean labels,")
    print("  this corpus, this model. Says nothing about non-IID or noisy settings -")
    print("  those are RQ5 and RQ3.")

    # D-019 has TWO halves. The first E2 aggregation checked only the plateau
    # spread and reported convergence while best_round == cap for all 5 seeds -
    # exactly the pinning signature D-019 names as a warning. Extending 40 -> 60
    # rounds moved seed 0 from 0.6094 to 0.6149. Both halves are now checked.
    all_plateaued = all(fed[s]["plateaued"] for s in SEEDS)
    caps = {s: fed[s]["config"]["rounds"] for s in SEEDS}
    pinned = [s for s in SEEDS if fed[s]["best_round"] >= caps[s]]
    print(f"\n  D-019 convergence check:")
    print(f"    plateau spread < 0.005 for all seeds : {all_plateaued}")
    print(f"    best_round pinned at cap             : {pinned if pinned else 'none'}")
    if pinned:
        print(f"    WARNING: seeds {pinned} may still be improving. The measured gap")
        print( "    is therefore an UPPER bound - more rounds can only help FedAvg -")
        print( "    so an H1 SUPPORTED verdict is safe in direction, but an H1")
        print( "    FALSIFIED verdict would NOT be trustworthy under this condition.")
    if gaps.mean() > threshold * 0.7:
        print("  WARNING (D-022): gap is close to the threshold. Tighten the plateau")
        print("  criterion and re-run before relying on this decision.")

    (OUT / "E2_H1_decision.json").write_text(json.dumps({
        "sigma_c": sigma_c, "threshold": threshold,
        "centralized_mean": float(c_arr.mean()), "fedavg_mean": float(f_arr.mean()),
        "mean_gap": float(gaps.mean()), "gap_sd": float(gaps.std(ddof=1)),
        "gap_in_sigma_c": float(gaps.mean() / sigma_c),
        "per_seed_gap": {str(s): float(g) for s, g in zip(SEEDS, gaps)},
        "paired_t": {"t": float(t.statistic), "p": float(t.pvalue)},
        "wilcoxon": {"W": float(w.statistic), "p": float(w.pvalue)},
        "H1": verdict, "all_plateaued": bool(all_plateaued),
        "per_seed_rounds": {str(s): fed[s]["config"]["rounds"] for s in SEEDS},
        "budget_note": (
            "NOT matched: federated passes_per_example = rounds*local_epochs; "
            f"centralized = {CENTRALIZED_EPOCHS}. Do not describe H1 as matched-budget."
        ),
    }, indent=2))
    print(f"\n[saved {OUT / 'E2_H1_decision.json'}]")


if __name__ == "__main__":
    main()
