"""End-to-end smoke run on SYNTHETIC data. Not a result. Pipeline check only."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

from baize.data.dataset import make_synthetic_dataset
from baize.experiments.runner import ExperimentConfig, run_experiment

ds = make_synthetic_dataset(n_domains=800, seed=7, name="synthetic-v0")

print("=" * 66)
print("E1-style: CENTRALIZED, clean, domain-aware  [SYNTHETIC]")
print("=" * 66)
r1 = run_experiment(ds, ExperimentConfig(
    experiment_id="SMOKE-CENTRAL", mode="centralized",
    split_strategy="domain_aware", centralized_epochs=8, seed=0))
print(r1.split_report); print()
print(r1.summary())

print()
print("=" * 66)
print("E2-style: FEDAVG, IID, clean  [SYNTHETIC]")
print("=" * 66)
r2 = run_experiment(ds, ExperimentConfig(
    experiment_id="SMOKE-FEDAVG", mode="federated", n_clients=10,
    partition_strategy="iid", rounds=25, seed=0))
print(r2.summary())
