"""Send structured push notifications with rich embeds to Discord from GitHub Actions."""

from __future__ import annotations

import json
import os
import sys
import urllib.request


def format_payload(event: dict) -> dict:
    repo = event.get("repository", {}).get("full_name", "baize_thesis")
    ref = event.get("ref", "").replace("refs/heads/", "")
    compare_url = event.get("compare", "")
    pusher = event.get("pusher", {}).get("name", event.get("sender", {}).get("login", "unknown"))
    sender_avatar = event.get("sender", {}).get(
        "avatar_url", f"https://github.com/{pusher}.png"
    )

    commits = event.get("commits", [])
    commit_count = len(commits)
    plural = "s" if commit_count != 1 else ""

    commit_lines: list[str] = []
    all_added: set[str] = set()
    all_modified: set[str] = set()
    all_removed: set[str] = set()

    for c in commits[:10]:
        short_id = c.get("id", "")[:7]
        msg = c.get("message", "").split("\n")[0]
        url = c.get("url", "")
        commit_lines.append(f"[`{short_id}`]({url}) {msg}")
        all_added.update(c.get("added", []))
        all_modified.update(c.get("modified", []))
        all_removed.update(c.get("removed", []))

    if commit_count > 10:
        commit_lines.append(f"*... and {commit_count - 10} more commits*")

    description = "\n".join(commit_lines) if commit_lines else "No commit details available."

    fields = [
        {"name": "🌿 Branch", "value": f"`{ref}`", "inline": True},
        {"name": "📊 Commits", "value": f"**{commit_count}** new commit{plural}", "inline": True},
    ]

    if compare_url:
        fields.append({"name": "🔍 Compare", "value": f"[View Diff]({compare_url})", "inline": True})

    file_summary: list[str] = []
    if all_added:
        names = ", ".join(f"`{f}`" for f in sorted(all_added)[:5])
        extra = f" *(+{len(all_added)-5} more)*" if len(all_added) > 5 else ""
        file_summary.append(f"🟢 **Added ({len(all_added)})**: {names}{extra}")
    if all_modified:
        names = ", ".join(f"`{f}`" for f in sorted(all_modified)[:5])
        extra = f" *(+{len(all_modified)-5} more)*" if len(all_modified) > 5 else ""
        file_summary.append(f"🟡 **Modified ({len(all_modified)})**: {names}{extra}")
    if all_removed:
        names = ", ".join(f"`{f}`" for f in sorted(all_removed)[:5])
        extra = f" *(+{len(all_removed)-5} more)*" if len(all_removed) > 5 else ""
        file_summary.append(f"🔴 **Removed ({len(all_removed)})**: {names}{extra}")

    if file_summary:
        fields.append({"name": "📁 Changes", "value": "\n".join(file_summary), "inline": False})

    return {
        "username": "GitHub",
        "avatar_url": "https://github.githubassets.com/images/modules/logos_page/GitHub-Mark.png",
        "embeds": [
            {
                "title": f"📦 [{repo}] {commit_count} commit{plural} pushed to `{ref}`",
                "url": compare_url or f"https://github.com/{repo}/tree/{ref}",
                "color": 3066993,  # Emerald Green
                "author": {
                    "name": pusher,
                    "url": f"https://github.com/{pusher}",
                    "icon_url": sender_avatar,
                },
                "description": description,
                "fields": fields,
                "footer": {
                    "text": "BAIZE Research Pipeline • Push Logger",
                    "icon_url": "https://github.githubassets.com/favicons/favicon.png",
                },
            }
        ],
    }


def main() -> int:
    webhook_url = os.environ.get("DISCORD_WEBHOOK", "").strip()
    if not webhook_url:
        print("DISCORD_WEBHOOK is not set; skipping notification.", file=sys.stderr)
        return 0

    event_path = os.environ.get("GITHUB_EVENT_PATH")
    if not event_path or not os.path.isfile(event_path):
        print(f"GITHUB_EVENT_PATH not found or invalid: {event_path!r}", file=sys.stderr)
        return 1

    with open(event_path, "r", encoding="utf-8") as f:
        event = json.load(f)

    payload = format_payload(event)
    data = json.dumps(payload).encode("utf-8")

    req = urllib.request.Request(
        webhook_url,
        data=data,
        headers={"Content-Type": "application/json", "User-Agent": "BAIZE-Discord-Notifier/1.0"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            print(f"Discord notification delivered successfully (HTTP {resp.status}).")
    except urllib.error.HTTPError as exc:
        print(f"Failed to deliver Discord notification: HTTP {exc.code}", file=sys.stderr)
        return 1
    except Exception as exc:
        print(f"Network error delivering Discord notification: {type(exc).__name__}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
