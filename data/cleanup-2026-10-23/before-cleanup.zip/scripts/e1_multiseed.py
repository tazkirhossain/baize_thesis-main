"""E1 multi-seed: measure sigma_c and the random vs domain-aware gap.

sigma_c is the cross-seed standard deviation of centralized test PR-AUC on the
domain-aware split. DECISIONS.md D-008 makes every hypothesis threshold in
RESEARCH.md §2 a multiple of it, so this run is a prerequisite for freezing
those thresholds and therefore for every federated experiment that follows.

Usage:
    python scripts/e1_multiseed.py random
    python scripts/e1_multiseed.py domain_aware
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import scipy.sparse as sp

from baize.evaluation.budget import describe_budget, passes_per_example
from baize.evaluation.metrics import classification_metrics, precision_at_base_rate
from baize.hparams import BATCH, CENTRALIZED_EPOCHS, L2, LR
from baize.models.linear import LogisticSGD
from baize.provenance import environment_record

# lr=2.0 (the original E1 setting) was severely under-trained: a probe showed
# lr=160 at 12 epochs beating lr=2 at 40. Convergence check at lr=160 plateaus
# from ~epoch 30 (val PR-AUC 0.6086 -> 0.6106 -> 0.6105 -> 0.6095 at ep 30/35/40/45).
# TAG keeps the under-trained v1 results on disk as evidence rather than
# overwriting them - D-015 requires documenting both sigma_c values.
TAG = os.environ.get("E1_TAG", "lr160")
EPOCHS = int(os.environ.get("E1_EPOCHS", str(CENTRALIZED_EPOCHS)))
LR = float(os.environ.get("E1_LR", str(LR)))
SEEDS = [0, 1, 2, 3, 4]
CACHE = Path("data/cache")
OUT = Path("experiments/results")


def main(strategy: str, seeds: list[int]) -> None:
    """Run the given seeds and APPEND each result to a JSON-lines file.

    Seeds are run incrementally rather than in one batch because a full 5-seed
    sweep exceeds the available wall-clock per invocation. Appending per seed
    means a interrupted sweep loses at most one seed's work, and the aggregate
    is computed separately from whatever has accumulated.
    """
    t0 = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    jsonl = OUT / f"E1_{strategy}_seeds_{TAG}.jsonl"
    X = sp.load_npz(CACHE / "X.npz")
    store = np.load(CACHE / "split_indices.npz")
    labels = store["labels"]
    print(f"X {X.shape} nnz={X.nnz:,}  loaded in {time.time() - t0:.0f}s\n", flush=True)

    done = set()
    if jsonl.exists():
        done = {json.loads(l)["seed"] for l in jsonl.read_text().splitlines() if l.strip()}
    for seed in seeds:
        if seed in done:
            print(f"  seed {seed}: already recorded, skipping", flush=True)
            continue
        t1 = time.time()
        i_tr = store[f"{strategy}_{seed}_train"]
        i_va = store[f"{strategy}_{seed}_val"]
        i_te = store[f"{strategy}_{seed}_test"]
        y_tr, y_va, y_te = labels[i_tr], labels[i_va], labels[i_te]

        model = LogisticSGD(X.shape[1], l2=L2, seed=seed)
        rng = np.random.default_rng(seed)

        best_val, best_params, best_ep = -np.inf, model.get_params(), -1
        for ep in range(1, EPOCHS + 1):
            model.fit(X, y_tr, epochs=1, batch_size=BATCH, lr=LR, rng=rng,
                      indices=i_tr, compute_loss=False)
            mv = classification_metrics(y_va, model.predict_proba_chunked(X, i_va))
            if mv["pr_auc"] > best_val:
                best_val, best_params, best_ep = mv["pr_auc"], model.get_params(), ep

        # select on validation, then touch test exactly once
        model.set_params(best_params)
        mt = classification_metrics(y_te, model.predict_proba_chunked(X, i_te))
        rec = {
            "seed": seed,
            "best_epoch": best_ep,
            "val_pr_auc": best_val,
            "provenance": environment_record(),
            "training_budget": describe_budget(
                len(y_tr), passes_per_example(centralized_epochs=EPOCHS)
            ),
            **mt,
        }
        with jsonl.open("a") as f:
            f.write(json.dumps(rec) + "\n")
        print(f"  seed {seed}: val={best_val:.4f} (ep {best_ep})  "
              f"TEST PR-AUC={mt['pr_auc']:.4f}  roc={mt['roc_auc']:.4f}  "
              f"f1={mt['f1']:.4f}  ({time.time() - t1:.0f}s)", flush=True)

    print(f"\n[appended to {jsonl}  {time.time() - t0:.0f}s]")


if __name__ == "__main__":
    strategy = sys.argv[1]
    seeds = [int(a) for a in sys.argv[2:]] or SEEDS
    main(strategy, seeds)
