"""Cache the feature matrix and split indices once, for reuse across all seeds.

The hashing vectoriser is STATELESS - it has no fitted vocabulary - so
transforming the whole corpus once and slicing per split is exactly equivalent
to transforming each split separately, with no leakage. (This would NOT be valid
for TF-IDF, which fits a vocabulary and must see training data only.)

Doing it once instead of ten times saves roughly ten minutes of the sigma_c run
and, more importantly, guarantees every seed sees byte-identical features.
"""

from __future__ import annotations

import gc
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import scipy.sparse as sp

from baize.data.features import build_vectorizer
from baize.data.loaders import load_url_csv
from baize.data.splits import _domain_aware_indices, _stratified_random_indices
from baize.data.validation import deduplicate
from baize.hparams import N_FEATURES, NGRAM_RANGE
SEEDS = [0, 1, 2, 3, 4]
FRACTIONS = (0.70, 0.15, 0.15)
CACHE = Path("data/cache")


def main(path: str = "data/raw/url.csv") -> None:
    t0 = time.time()
    CACHE.mkdir(parents=True, exist_ok=True)

    ds, _ = load_url_csv(path, name="url-csv-v1")
    ds, _ = deduplicate(ds)
    print(f"corpus {len(ds):,}  pos_rate {ds.positive_rate:.4%}  "
          f"fingerprint {ds.fingerprint()[:16]}  ({time.time() - t0:.0f}s)", flush=True)

    labels = ds.labels.copy()
    domains = ds.domains

    # --- split indices for every (strategy, seed) --------------------------- #
    index_store: dict[str, np.ndarray] = {}
    for seed in SEEDS:
        rng = np.random.default_rng(seed)
        tr, va, te = _stratified_random_indices(labels, FRACTIONS, rng)
        for nm, arr in zip(("train", "val", "test"), (tr, va, te)):
            index_store[f"random_{seed}_{nm}"] = arr

        rng = np.random.default_rng(seed)
        tr, va, te = _domain_aware_indices(domains, labels, FRACTIONS, rng)
        for nm, arr in zip(("train", "val", "test"), (tr, va, te)):
            index_store[f"domain_aware_{seed}_{nm}"] = arr

        # Verify the domain guarantee directly on the index arrays, since this
        # path bypasses make_splits and therefore bypasses its leakage gate.
        d_tr = set(domains[index_store[f"domain_aware_{seed}_train"]].tolist())
        d_te = set(domains[index_store[f"domain_aware_{seed}_test"]].tolist())
        d_va = set(domains[index_store[f"domain_aware_{seed}_val"]].tolist())
        assert not (d_tr & d_te) and not (d_tr & d_va) and not (d_va & d_te), (
            f"domain leakage at seed {seed} - BLOCK"
        )
    print(f"split indices built and leakage-checked for {len(SEEDS)} seeds "
          f"({time.time() - t0:.0f}s)", flush=True)

    np.savez_compressed(CACHE / "split_indices.npz", labels=labels, **index_store)

    texts = ds.texts
    del ds, domains
    gc.collect()

    t1 = time.time()
    vec = build_vectorizer("hashing", n_features=N_FEATURES, ngram_range=NGRAM_RANGE)
    X = vec.transform(texts)
    X = X.astype(np.float32)
    X.indices = X.indices.astype(np.int32)
    X.indptr = X.indptr.astype(np.int32)
    del texts, vec
    gc.collect()

    print(f"X: {X.shape}  nnz={X.nnz:,}  "
          f"{(X.data.nbytes + X.indices.nbytes + X.indptr.nbytes) / 1e9:.2f} GB  "
          f"({time.time() - t1:.0f}s)", flush=True)

    sp.save_npz(CACHE / "X.npz", X, compressed=False)
    print(f"[cached to {CACHE}  total {time.time() - t0:.0f}s]")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "data/raw/url.csv")
