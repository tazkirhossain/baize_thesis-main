"""Aggregate E1 results: sigma_c and the random vs domain-aware comparison.

The two regimes are compared PAIRED by seed. Seed controls the data ordering and
the partition draw, so the same seed is a genuinely matched pair and a paired
test removes the seed-to-seed component of the variance. With n=5 the normality
assumption behind a paired t-test cannot be checked, so the Wilcoxon signed-rank
statistic is reported alongside; at n=5 its smallest attainable two-sided p-value
is 0.0625, which is a limit of the design, not evidence of weakness.

Master spec §49: do not interpret differences smaller than the cross-seed spread.
Here the difference is ~18x it, which is why the conclusion is safe despite n=5.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
from scipy import stats

from baize.hparams import BATCH, CENTRALIZED_EPOCHS, LR

OUT = Path("experiments/results")


TAG = os.environ.get("E1_TAG", "lr160")


def load(strategy: str) -> list[dict]:
    p = OUT / f"E1_{strategy}_seeds_{TAG}.jsonl"
    rows = [json.loads(l) for l in p.read_text().splitlines() if l.strip()]
    return sorted(rows, key=lambda r: r["seed"])


def block(strategy: str, rows: list[dict]) -> np.ndarray:
    pr = np.array([r["pr_auc"] for r in rows])
    print(f"\nE1 / {strategy} / {len(rows)} seeds")
    print(f"  {'seed':>5}{'test PR-AUC':>14}{'ROC-AUC':>10}{'F1':>9}"
          f"{'recall':>9}{'FPR':>10}{'best ep':>9}")
    for r in rows:
        print(f"  {r['seed']:>5}{r['pr_auc']:>14.4f}{r['roc_auc']:>10.4f}{r['f1']:>9.4f}"
              f"{r['recall']:>9.4f}{r['fpr']:>10.5f}{r['best_epoch']:>9}")
    print(f"  {'mean':>5}{pr.mean():>14.4f}{np.mean([r['roc_auc'] for r in rows]):>10.4f}"
          f"{np.mean([r['f1'] for r in rows]):>9.4f}"
          f"{np.mean([r['recall'] for r in rows]):>9.4f}"
          f"{np.mean([r['fpr'] for r in rows]):>10.5f}")
    print(f"  {'sd':>5}{pr.std(ddof=1):>14.4f}")
    return pr


def main() -> None:
    print("=" * 72)
    print("BAIZE E1 - CENTRALIZED BASELINE, MULTI-SEED")
    print("=" * 72)
    print("  model      : logistic regression, hashed char 3-5 grams, 2^18 features")
    print(f"  budget     : {CENTRALIZED_EPOCHS} epochs, lr={LR}, batch={BATCH}, identical for both regimes")
    print("  corpus     : url-csv-v1, 1,468,243 rows post-dedup, pos_rate 2.371%")
    print("  selection  : best validation PR-AUC; test evaluated once per seed")
    print(f"  TAG        : {TAG}")

    dom_rows, rnd_rows = load("domain_aware"), load("random")
    rnd = block("random", rnd_rows)
    dom = block("domain_aware", dom_rows)

    sigma_c = float(dom.std(ddof=1))
    print("\n" + "=" * 72)
    print("SIGMA_C  (DECISIONS.md D-008)")
    print("=" * 72)
    print(f"  sigma_c   = {sigma_c:.5f}   (cross-seed sd of centralized test PR-AUC,")
    print("                             domain-aware split, the primary regime)")
    print(f"  2 sigma_c = {2 * sigma_c:.5f}")
    print(f"  3 sigma_c = {3 * sigma_c:.5f}")

    print("\n  Frozen decision rules for RESEARCH.md §2:")
    print(f"    H1 supported  : FedAvg-vs-centralized PR-AUC gap <= {2 * sigma_c:.4f}")
    print(f"    H2 supported  : clean->30% noise drop           >  {3 * sigma_c:.4f}")
    print(f"    H3 supported  : best robust agg beats FedAvg by >  {2 * sigma_c:.4f} at 30% noise")
    print(f"    H4 supported  : IID-vs-non-IID gap              >  {2 * sigma_c:.4f}")
    print(f"    H5 supported  : robust agg underperforms FedAvg by > {2 * sigma_c:.4f} on clean non-IID")

    # --- paired comparison -------------------------------------------------- #
    seeds_d = [r["seed"] for r in dom_rows]
    seeds_r = [r["seed"] for r in rnd_rows]
    n = min(len(seeds_d), len(seeds_r))
    common = sorted(set(seeds_d) & set(seeds_r))
    a = np.array([r["pr_auc"] for r in rnd_rows if r["seed"] in common])
    b = np.array([r["pr_auc"] for r in dom_rows if r["seed"] in common])
    diff = a - b

    print("\n" + "=" * 72)
    print("RQ1 - SPLIT REGIME COMPARISON (paired by seed)")
    print("=" * 72)
    print(f"  paired seeds            : {common}")
    print(f"  random      mean PR-AUC : {a.mean():.4f}")
    print(f"  domain-aware mean PR-AUC: {b.mean():.4f}")
    print(f"  inflation (random-dom)  : {diff.mean():.4f} "
          f"(sd of diff {diff.std(ddof=1):.4f})")
    print(f"  relative inflation      : {diff.mean() / b.mean():.1%}")
    print(f"  in units of sigma_c     : {diff.mean() / sigma_c:.1f} sigma_c")

    t = stats.ttest_rel(a, b)
    w = stats.wilcoxon(a, b)
    print(f"\n  paired t-test           : t={t.statistic:.2f}, p={t.pvalue:.2e}")
    print(f"  Wilcoxon signed-rank    : W={w.statistic:.1f}, p={w.pvalue:.4f}"
          "   (0.0625 is the floor at n=5)")
    print("\n  Interpretation: a random split lets the same registrable domain appear")
    print("  in train and test, so part of the apparent performance is domain")
    print("  memorisation rather than generalisation to unseen sites. Headline")
    print("  numbers must come from the domain-aware regime (D-002).")

    best_epochs = [r["best_epoch"] for r in dom_rows + rnd_rows if "best_epoch" in r]
    pinned = bool(best_epochs) and all(ep == max(best_epochs) for ep in best_epochs) and max(best_epochs) >= CENTRALIZED_EPOCHS
    if pinned:
        caveat = (
            f"best epoch pinned at the cap for every seed (cap={max(best_epochs)}); "
            "absolute PR-AUC is a lower bound and sigma_c should be re-measured "
            "after a run whose best epoch varies"
        )
    else:
        caveat = (
            "best epoch varies across seeds (not pinned at the epoch cap); "
            "sigma_c is measured at the declared centralized budget"
        )
    summary = {
        "sigma_c": sigma_c,
        "thresholds": {"2_sigma_c": 2 * sigma_c, "3_sigma_c": 3 * sigma_c},
        "random": {"mean_pr_auc": float(a.mean()), "sd": float(a.std(ddof=1)),
                   "seeds": common},
        "domain_aware": {"mean_pr_auc": float(b.mean()), "sd": float(b.std(ddof=1)),
                         "seeds": common},
        "inflation_abs": float(diff.mean()),
        "inflation_rel": float(diff.mean() / b.mean()),
        "inflation_sigma_c": float(diff.mean() / sigma_c),
        "paired_t": {"t": float(t.statistic), "p": float(t.pvalue)},
        "wilcoxon": {"W": float(w.statistic), "p": float(w.pvalue)},
        "tag": TAG,
        "centralized_epochs": CENTRALIZED_EPOCHS,
        "lr": LR,
        "caveat": caveat,
        "best_epochs": best_epochs,
    }
    summary_path = OUT / f"E1_summary_{TAG}.json"
    summary_path.write_text(json.dumps(summary, indent=2))
    print(f"\n[saved {summary_path}]")


if __name__ == "__main__":
    main()
