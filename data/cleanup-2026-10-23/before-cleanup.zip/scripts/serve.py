"""Local demo server: URL checker + frozen experiment visualisation.

    .venv/bin/python scripts/serve.py

Binds to 127.0.0.1:8765 by default. Does not fetch the submitted URL. Does not
add web-framework dependencies — stdlib `http.server` only.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from baize.demo_server import make_server
from baize.inference import bootstrap_classifier


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="BAIZE local demo frontend")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--force-synthetic", action="store_true")
    p.add_argument("--retrain", action="store_true")
    p.add_argument("--corpus", default=str(ROOT / "data" / "raw" / "url.csv"))
    p.add_argument("--model", default=str(ROOT / "data" / "models" / "classifier.npz"))
    p.add_argument("--corpus-sample", type=int, default=80_000)
    args = p.parse_args(argv)

    print("BAIZE demo — training or loading the local classifier…", flush=True)
    clf = bootstrap_classifier(
        model_path=args.model,
        corpus_path=args.corpus,
        force_synthetic=args.force_synthetic,
        corpus_sample=args.corpus_sample,
        retrain=args.retrain,
    )
    print(
        f"  source={clf.source}  n_train={clf.meta.get('n_train')}  "
        f"n_features={clf.n_features}  pos_rate={clf.meta.get('positive_rate')}",
        flush=True,
    )
    httpd = make_server(clf, host=args.host, port=args.port)
    print(f"Open http://{args.host}:{args.port}/", flush=True)
    print("The server never fetches submitted URLs.", flush=True)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nstopping", flush=True)
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
