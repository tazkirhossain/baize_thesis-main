"""Phase 1: full-corpus validation report.

Produces the evidence required by the Phase 1 gate in RESEARCH.md:
dataset characterisation, deduplication, leakage check, and both split regimes.

Run:  python scripts/phase1_report.py data/raw/url.csv
"""

from __future__ import annotations

import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from baize.data.loaders import load_url_csv, load_with_categories
from baize.data.splits import make_splits
from baize.data.validation import deduplicate, validate_dataset


def main(path: str) -> None:
    t0 = time.time()

    print("=" * 70)
    print("BAIZE PHASE 1 - DATASET VALIDATION REPORT")
    print("=" * 70)
    print(f"source: {path}\n")

    ds, mapping = load_url_csv(path, name="url-csv-v1")
    print(mapping.render())
    print(f"\n[loaded and normalised in {time.time() - t0:.0f}s]\n")

    print("=" * 70)
    vrep = validate_dataset(ds)
    print(vrep.render())

    print("\n" + "=" * 70)
    clean, drep = deduplicate(ds, conflict="drop")
    print(drep.render())
    print(f"\n  fingerprint (post-dedup): {clean.fingerprint()}")
    print(f"  positive rate            : {clean.positive_rate:.4%}")

    # --- domain-level structure ------------------------------------------- #
    print("\n" + "=" * 70)
    print("DOMAIN STRUCTURE (determines whether a domain-aware split is viable)")
    doms = clean.domains
    dom_counts = Counter(doms.tolist())
    sizes = np.array(list(dom_counts.values()))
    print(f"  unique registrable domains : {len(dom_counts):,}")
    print(f"  urls per domain            : mean={sizes.mean():.2f} "
          f"median={np.median(sizes):.0f} p99={np.percentile(sizes, 99):.0f} max={sizes.max():,}")
    print(f"  domains with a single URL  : {(sizes == 1).sum():,} "
          f"({(sizes == 1).mean():.1%} of domains)")
    largest = dom_counts.most_common(1)[0]
    print(f"  largest domain share       : {largest[1] / len(clean):.3%}")

    # positive-class domain concentration
    pos_doms = set(doms[clean.labels == 1].tolist())
    neg_doms = set(doms[clean.labels == 0].tolist())
    print(f"  domains with any positive  : {len(pos_doms):,}")
    print(f"  domains with any negative  : {len(neg_doms):,}")
    print(f"  domains carrying BOTH      : {len(pos_doms & neg_doms):,}"
          "   <- these force a label decision at group level")

    # --- both split regimes ------------------------------------------------ #
    for strategy in ("random", "domain_aware"):
        print("\n" + "=" * 70)
        s = make_splits(clean, strategy=strategy, seed=0)
        print(s.report.render())

    # --- per-category composition of the negative class -------------------- #
    print("\n" + "=" * 70)
    print("NEGATIVE-CLASS COMPOSITION (for per-category error analysis)")
    df = load_with_categories(path)
    counts = df["label"].value_counts()
    total = int(counts.sum())
    for cat, n in counts.items():
        tag = "POSITIVE" if str(cat).lower() == "adult" else ""
        print(f"  {str(cat):<12}{n:>10,}{n / total:>9.2%}  {tag}")

    print(f"\n[total {time.time() - t0:.0f}s]")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "data/raw/url.csv")
