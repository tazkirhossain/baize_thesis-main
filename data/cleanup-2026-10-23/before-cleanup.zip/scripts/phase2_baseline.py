"""Phase 2 (E1): centralized baseline.

One split regime per process invocation - the vectorised training matrix for
this corpus is large enough that holding two regimes at once exhausts memory on
a 4 GB machine. Running them separately also keeps each result independently
reproducible from its own command line.

Usage:
    python scripts/phase2_baseline.py random 0
    python scripts/phase2_baseline.py domain_aware 0
"""

from __future__ import annotations

import gc
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np

from baize.data.features import build_vectorizer
from baize.data.loaders import load_url_csv
from baize.data.splits import assert_no_leakage, make_splits
from baize.data.validation import deduplicate
from baize.evaluation.budget import describe_budget, passes_per_example
from baize.evaluation.metrics import (
    classification_metrics,
    format_metrics,
    precision_at_base_rate,
)
from baize.hparams import BATCH, CENTRALIZED_EPOCHS, L2, LR, N_FEATURES, NGRAM_RANGE
from baize.models.linear import LogisticSGD
from baize.provenance import environment_record

EPOCHS = int(os.environ.get("E1_EPOCHS", str(CENTRALIZED_EPOCHS)))
# Allow the same env overrides as e1_multiseed so this script cannot silently
# fall back to the superseded lr=2 / 25-epoch setting (D-017).
N_FEATURES = int(os.environ.get("E1_N_FEATURES", str(N_FEATURES)))
LR = float(os.environ.get("E1_LR", str(LR)))


def main(strategy: str, seed: int, path: str = "data/raw/url.csv") -> None:
    t0 = time.time()
    ds, _ = load_url_csv(path, name="url-csv-v1")
    ds, _ = deduplicate(ds)

    splits = make_splits(ds, strategy=strategy, seed=seed)
    assert_no_leakage(splits.report)

    y_tr = splits.train.labels
    y_va = splits.val.labels
    y_te = splits.test.labels

    vec = build_vectorizer("hashing", n_features=N_FEATURES, ngram_range=NGRAM_RANGE)
    X_tr = vec.transform(splits.train.texts)
    X_va = vec.transform(splits.val.texts)
    X_te = vec.transform(splits.test.texts)

    # Release the URL objects and split containers: from here only the sparse
    # matrices and label arrays are needed, and the NormalizedURL list is by far
    # the largest live object.
    fingerprint = ds.fingerprint()
    n_total = len(ds)
    del ds, splits, vec
    gc.collect()

    print(f"[{strategy} seed={seed}] train={X_tr.shape} pos_rate={y_tr.mean():.4f} "
          f"prep={time.time() - t0:.0f}s", flush=True)

    model = LogisticSGD(N_FEATURES, l2=L2, seed=seed)
    rng = np.random.default_rng(seed)

    best_val, best_params, best_ep = -np.inf, model.get_params(), -1
    history = []
    for ep in range(1, EPOCHS + 1):
        t1 = time.time()
        model.fit(X_tr, y_tr, epochs=1, batch_size=BATCH, lr=LR, rng=rng)
        mv = classification_metrics(y_va, model.predict_proba(X_va))
        history.append({"epoch": ep, "val_pr_auc": mv["pr_auc"]})
        if mv["pr_auc"] > best_val:
            best_val, best_params, best_ep = mv["pr_auc"], model.get_params(), ep
        print(f"   ep {ep:>2}  val PR-AUC={mv['pr_auc']:.4f}  ({time.time() - t1:.0f}s)", flush=True)

    # Select on validation, then touch the test set exactly once.
    model.set_params(best_params)
    mt = classification_metrics(y_te, model.predict_proba(X_te))

    print()
    print(format_metrics(mt, f"CENTRALIZED / {strategy} / seed {seed} / best epoch {best_ep}"))
    print("\n  Projected precision at assumed deployment base rates")
    print("  (PROJECTION from an assumed prior, not a measurement):")
    for br in (0.05, 0.0237, 0.01):
        print(f"      base rate {br:<8} -> precision "
              f"{precision_at_base_rate(mt['recall'], mt['fpr'], br):.4f}")

    out = Path("experiments/results")
    out.mkdir(parents=True, exist_ok=True)
    rec = {
        "experiment_id": f"BAIZE-E1-{strategy}-seed{seed}",
        "split_strategy": strategy,
        "seed": seed,
        "dataset_fingerprint": fingerprint,
        "n_records": n_total,
        "hyperparams": {"epochs": EPOCHS, "n_features": N_FEATURES, "lr": LR,
                        "batch_size": BATCH, "l2": L2},
        "provenance": environment_record(),
        "training_budget": describe_budget(
            len(y_tr), passes_per_example(centralized_epochs=EPOCHS)
        ),
        "best_epoch": best_ep,
        "val_pr_auc": best_val,
        "test_metrics": mt,
        "history": history,
        "wall_seconds": time.time() - t0,
    }
    (out / f"E1_{strategy}_seed{seed}.json").write_text(json.dumps(rec, indent=2))
    print(f"\n[saved experiments/results/E1_{strategy}_seed{seed}.json  "
          f"total {time.time() - t0:.0f}s]")


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 0)
