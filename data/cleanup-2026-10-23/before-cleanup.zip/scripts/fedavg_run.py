"""Resumable FedAvg runner.

A 50-round federated run takes roughly 10 minutes, which exceeds the wall-clock
available per invocation. This runner checkpoints the global parameters, the
per-client RNG states and the round history after every round, so a run can be
extended across several invocations and resumes exactly where it stopped.

Resuming is bit-exact for the aggregation path: client RNG states are saved and
restored, so the sequence of mini-batch permutations is unchanged by where the
run was interrupted. Mechanism coverage lives in
`tests/test_pipeline.py::TestModel::test_rng_checkpoint_resumes_training`.

Usage:
    python scripts/fedavg_run.py --tag e2_iid_seed0 --rounds 20
    python scripts/fedavg_run.py --tag e2_iid_seed0 --rounds 50   # extends
"""

from __future__ import annotations

import argparse
import json
import pickle
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import scipy.sparse as sp

from baize.provenance import environment_record

from baize.data.noise import apply_client_noise, apply_noise, assert_noise_valid
from baize.data.partition import partition
from baize.evaluation.budget import describe_budget, passes_per_example
from baize.evaluation.convergence import check_convergence
from baize.evaluation.metrics import classification_metrics
from baize.federated.aggregation import get_aggregator
from baize.hparams import BATCH, L2, LOCAL_EPOCHS, LR, N_CLIENTS, SPLIT
from baize.models.linear import LogisticSGD, init_params

CACHE = Path("data/cache")
OUT = Path("experiments/results")
CKPT = Path("data/checkpoints")


def build_state(args):
    X = sp.load_npz(CACHE / "X.npz")
    store = np.load(CACHE / "split_indices.npz")
    labels = store["labels"]
    i_tr = store[f"{args.split}_{args.seed}_train"]
    i_va = store[f"{args.split}_{args.seed}_val"]
    i_te = store[f"{args.split}_{args.seed}_test"]
    y_tr = labels[i_tr].copy()
    y_va, y_te = labels[i_va], labels[i_te]

    parts, prep = partition(y_tr, args.partition, n_clients=args.clients,
                            seed=args.seed, **json.loads(args.partition_params))
    if not prep.status.startswith("PASS"):
        raise RuntimeError(f"partition gate: {prep.status}")

    noise_rep = None
    if args.noise_process == "client_heterogeneous":
        rates = json.loads(args.noise_client_rates)
        y_tr, noise_rep = apply_client_noise(y_tr, parts, rates, seed=args.seed)
        assert_noise_valid(noise_rep)
    elif args.noise_process != "none":
        y_tr, noise_rep = apply_noise(y_tr, process=args.noise_process,
                                      rate=args.noise_rate, seed=args.seed)
        assert_noise_valid(noise_rep)

    return X, y_tr, y_va, y_te, i_tr, i_va, i_te, parts, prep, noise_rep


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", required=True)
    ap.add_argument("--rounds", type=int, required=True, help="target total rounds")
    ap.add_argument("--split", default=SPLIT)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--clients", type=int, default=N_CLIENTS)
    ap.add_argument("--partition", default="iid")
    ap.add_argument("--partition-params", default="{}")
    ap.add_argument("--aggregation", default="fedavg")
    ap.add_argument("--aggregation-params", default="{}")
    ap.add_argument("--local-epochs", type=int, default=LOCAL_EPOCHS)
    ap.add_argument("--lr", type=float, default=LR)
    ap.add_argument("--batch", type=int, default=BATCH)
    ap.add_argument("--l2", type=float, default=L2)
    ap.add_argument("--noise-process", default="none")
    ap.add_argument("--noise-rate", type=float, default=0.0)
    ap.add_argument("--noise-client-rates", default="[]")
    ap.add_argument("--malicious", default="[]")
    ap.add_argument("--malicious-behaviour", default="sign_flip")
    args = ap.parse_args()

    CKPT.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    ck_path = CKPT / f"{args.tag}.pkl"

    t0 = time.time()
    X, y_tr, y_va, y_te, i_tr, i_va, i_te, parts, prep, noise_rep = build_state(args)
    global_parts = [i_tr[p] for p in parts]
    n_features = X.shape[1]
    weights = np.array([len(p) for p in parts], dtype=np.float64)
    aggregate = get_aggregator(args.aggregation)
    agg_kwargs = json.loads(args.aggregation_params)
    malicious = set(json.loads(args.malicious))

    if ck_path.exists():
        st = pickle.loads(ck_path.read_bytes())
        g = st["g"]
        rng_states = st["rng_states"]
        history = st["history"]
        best = st["best"]
        start = st["round"] + 1
        print(f"[resumed {args.tag} at round {start} of {args.rounds}]", flush=True)
    else:
        g = init_params(n_features)
        rng_states = [np.random.default_rng(args.seed * 1000 + c).bit_generator.state
                      for c in range(len(parts))]
        history, best, start = [], {"val_pr_auc": -np.inf, "round": -1, "params": None}, 1
        print(f"[new run {args.tag}] clients={args.clients} partition={args.partition} "
              f"agg={args.aggregation} noise={args.noise_process}@{args.noise_rate}",
              flush=True)
        if noise_rep:
            print(f"  noise realised={noise_rep.realised_rate:.4f} "
                  f"({noise_rep.deviation_sigmas:.2f} SE)  {noise_rep.status}", flush=True)

    if start > args.rounds:
        print(f"[already at round {start - 1} >= target {args.rounds}]")
    else:
        models = [LogisticSGD(n_features, l2=args.l2) for _ in parts]
        evaluator = LogisticSGD(n_features, l2=args.l2)
        rngs = []
        for stt in rng_states:
            r = np.random.default_rng()
            r.bit_generator.state = stt
            rngs.append(r)

        for rnd in range(start, args.rounds + 1):
            deltas = []
            for c, (rows, local_idx) in enumerate(zip(global_parts, parts)):
                models[c].set_params(g)
                models[c].fit(X, y_tr[local_idx], epochs=args.local_epochs,
                              batch_size=args.batch, lr=args.lr, rng=rngs[c],
                              indices=rows, compute_loss=False)
                d = models[c].get_params() - g
                if c in malicious:
                    if args.malicious_behaviour == "sign_flip":
                        d = -d
                    elif args.malicious_behaviour == "scale":
                        d = d * 10.0
                    elif args.malicious_behaviour == "gaussian":
                        d = rngs[c].normal(0, 1.0, size=d.shape)
                deltas.append(d)

            agg, _ = aggregate(deltas, weights=weights, **agg_kwargs)
            g = g + agg
            if not np.all(np.isfinite(g)):
                raise RuntimeError(f"round {rnd}: non-finite global parameters - BLOCK")

            evaluator.set_params(g)
            pr = classification_metrics(y_va, evaluator.predict_proba_chunked(X, i_va))["pr_auc"]
            history.append({"round": rnd, "val_pr_auc": pr})
            if pr > best["val_pr_auc"]:
                best = {"val_pr_auc": pr, "round": rnd, "params": g.copy()}

            ck_path.write_bytes(pickle.dumps({
                "g": g, "rng_states": [r.bit_generator.state for r in rngs],
                "history": history, "best": best, "round": rnd,
            }))
            if rnd % 5 == 0 or rnd <= 2:
                print(f"  round {rnd:>3}  val PR-AUC={pr:.4f}  ({time.time() - t0:.0f}s)",
                      flush=True)

    # --- final: select on validation, touch test once ----------------------- #
    ev = LogisticSGD(n_features, l2=args.l2)
    ev.set_params(best["params"])
    mt = classification_metrics(y_te, ev.predict_proba_chunked(X, i_te))
    conv = check_convergence([h["val_pr_auc"] for h in history])
    plateaued = conv.converged

    print(f"\n  best round {best['round']} val={best['val_pr_auc']:.4f}")
    print(f"  TEST PR-AUC={mt['pr_auc']:.4f}  roc={mt['roc_auc']:.4f}  f1={mt['f1']:.4f}")
    print(f"  {conv.render()}")
    if conv.status == "IMPROVING":
        print(f"  -> extend: projected +{conv.projected_gain:.4f} over {conv.window} more rounds")
    elif conv.status == "DEGRADING":
        print(f"  -> DO NOT extend: fitting noise past round {conv.best_index + 1}; "
              "report the early-stopped round as a result")

    (OUT / f"{args.tag}.json").write_text(json.dumps({
        "tag": args.tag, "config": vars(args),
        "provenance": environment_record(), "best_round": best["round"],
        "best_val_pr_auc": best["val_pr_auc"], "test_metrics": mt,
        "history": history, "plateaued": bool(plateaued),
        "convergence": {"status": conv.status, "slope": conv.slope_per_round,
                        "t": conv.t_statistic, "projected_gain": conv.projected_gain,
                        "best_index": conv.best_index, "best_at_cap": conv.best_at_cap},
        "noise_realised": None if noise_rep is None else noise_rep.realised_rate,
        "client_sizes": prep.sizes, "client_pos_rates": prep.positive_rates,
        "training_budget": describe_budget(
            len(y_tr),
            passes_per_example(
                rounds=len(history),
                local_epochs=args.local_epochs,
                participation=1.0,
            ),
        ),
        "selected_checkpoint": {
            "kind": "round", "index": best["round"], "val_pr_auc": best["val_pr_auc"]
        },
    }, indent=2))
    print(f"[saved {OUT / (args.tag + '.json')}]")


if __name__ == "__main__":
    main()
