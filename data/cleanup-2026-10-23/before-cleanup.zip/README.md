# BAIZE - the adult url detector

Privacy-conscious adult-website detection from URLs under federated learning
with noisy labels.

**Status: Phases 0-6 complete. Four hypotheses decided at n>=3 seeds.**
See [RESULTS.md](RESULTS.md) for findings and, importantly, limitations.

| | claim | result | evidence |
|---|---|---|---|
| RQ1 | Random splits inflate PR-AUC | **+23.6%** (20.2 sigma_c) | 5 seeds |
| H1 | Federation is nearly free | 0.0033 (0.47 sigma_c) | 5 seeds, SUPPORTED |
| H4 | Heterogeneity is the real cost | 0.0289 (4.03 sigma_c) | 3 seeds, SUPPORTED |
| H3 | Robust agg pays only vs *identifiable* corruption | -0.004 uniform / **+0.080** concentrated | 3 seeds, SUPPORTED |
| H5 | Its cost under benign skew | 0.0000 (p=0.997) | 3 seeds, NOT SUPPORTED |

All thresholds were frozen from sigma_c **before any federated run existed**.

The corpus predates ~2010 (HTTPS is 0.068% of rows). Every number describes the
pre-2010 web. Licence and provenance are unverified and block publication.

## What is built

| Component | State | Module |
|---|---|---|
| URL normalisation + privacy minimisation | working, tested | `baize/data/url.py` |
| Dataset container, fingerprinting | working, tested | `baize/data/dataset.py` |
| Validation + deduplication gate | working, tested | `baize/data/validation.py` |
| Random + domain-aware splits, leakage gate | working, tested | `baize/data/splits.py` |
| Label noise + statistical validation gate | working, tested | `baize/data/noise.py` |
| Client partitioners (IID, label skew, quantity skew) | working, tested | `baize/data/partition.py` |
| Hashing / TF-IDF char n-gram features | working | `baize/data/features.py` |
| Logistic regression with param-vector interface | working, tested | `baize/models/linear.py` |
| User-supplied character CNN | architecture + client-local Flower trainer; full-corpus study pending | `src/models/character_cnn/model.py`, `src/client/flower_client.py` |
| DeBERTa-v3-base | pretrained loader + Flower training interface; full pretrained run pending | `src/models/deberta_v3_base/model.py` |
| Five-client neural FedAvg | deterministic sampling, local validation, original-training-count weights | `src/server/flower_strategy.py` |
| Both-class metrics and comparison exports | JSON, tables, PNG/SVG; per-round train/validation, timing/payload accounting | `src/evaluation/`, `scripts/report_evaluation.py` |
| FedAvg, coordinate median, trimmed mean, norm clipping | working, tested | `baize/federated/aggregation.py` |
| Federated client incl. simulated attacks | working, tested | `baize/federated/client.py` |
| Federated simulator | working, tested | `baize/federated/simulator.py` |
| Metrics, calibration, abstention, base-rate projection | working, tested | `baize/evaluation/metrics.py` |
| Experiment runner with provenance | working, tested | `baize/experiments/runner.py` |
| Local demo UI (URL box + pipeline viz) | working, tested | `web/`, `baize/inference.py`, `scripts/serve.py` |

Not built: browser extension, in-browser WASM inference, LLM evaluation, calibration
fitting, model registry, drift, adversarial URL transformations. See
`docs/RESEARCH.md` §0 for which of these are deferred deliberately.

## Pipeline order (enforced by the runner)

```
load -> validate -> deduplicate -> split -> [LEAKAGE GATE]
     -> partition -> [PARTITION GATE] -> noise -> [NOISE GATE]
     -> train -> select on VALIDATION -> evaluate ONCE on clean test
```

Deduplication runs before splitting. Doing it after would leave identical URLs
already scattered across partitions, and removing them then does not undo the
leakage.

## Gates

All three raise rather than warn. A silently leaking split looks like a good
result, which is why it must be impossible to ignore.

- `LeakageError` - duplicate URLs across partitions, or domain overlap under a
  domain-aware split
- `NoiseValidationError` - realised noise rate more than 4 binomial standard
  errors from target; also fires if anything tries to noise a protected array
- `ValidationError` - single-class corpus, degenerate balance, too few domains

## Running

For the separate character CNN architecture, optional PyTorch installation and
tensor usage, see [docs/NEURAL_MODELS.md](docs/NEURAL_MODELS.md). The research training path uses these two neural models. The numerical logistic
classifiers and their training runner have been removed; the legacy demo retains
its documented model.
For the five-client Flower server/client commands, configurable training and
weighting/privacy policies, see [docs/FEDERATED_TRAINING.md](docs/FEDERATED_TRAINING.md).
Run `python scripts/federated.py smoke --output data/fl-smoke-new` for a tiny
synthetic two-round check after installing `pip install -e ".[federated]"`.
Evaluation usage and definitions: [docs/EVALUATION_REPORTING.md](docs/EVALUATION_REPORTING.md).
The verified current [tables and plots](results/evaluation_reporting_v4/README.md)
separate real numerical results from synthetic CNN smoke measurements; no winning
method or real-data neural performance is claimed.

For client-owned preprocessing, run `python scripts/prepare_clients.py --clients 5`
to clean and allocate unsplit datasets. Then each client runs
`python scripts/split_client.py --client-dir data/client-datasets-v3/client_000`
with its own directory to create its local train/validation/test sets.
See [docs/PREPROCESSING.md](docs/PREPROCESSING.md) for validation gates, privacy,
feature normalization, reports, and the boundary with the legacy training scripts.

```bash
pip install -r requirements.txt
python -m pytest tests/ -q        # 82 tests
python scripts/smoke.py           # end-to-end on synthetic data
python scripts/serve.py           # local frontend at http://127.0.0.1:8765/
```

### Local frontend

A one-page lab notebook: paste a URL, see adult / non-adult / uncertain, and
inspect the same pipeline the experiments use (minimise → hashed char 3–5-grams
→ logistic SGD → abstention band). Frozen RQ1/H1/H4/H3/H5 bars are read from
`experiments/results/*.json`; checking a URL does not retrain them.

The server **never fetches** the submitted page. Query, fragment, userinfo and
port are stripped before scoring and are not echoed back.

```bash
python scripts/serve.py --force-synthetic   # works with no corpus
python scripts/serve.py                     # if data/raw/url.csv is present,
                                            # trains a cached corpus-sample demo
```

`--force-synthetic` trains on abstract markers (`zqvx`, `harbour`, …). That
model will not classify real adult sites. A corpus-sample demo still is not the
thesis 2^18-feature / 35-epoch checkpoint, and the corpus is pre-~2010. Weights
land in `data/models/` (gitignored).

## Before any reported result

1. Identify the corpus and fill in `docs/DATASET.md` (D-010) — done.
2. Write the source-label mapping (`docs/LABELING_POLICY.md` §4) — done; label *audit* still outstanding.
3. `provenance["git_commit"]` records `git rev-parse HEAD`, with a `-DIRTY` suffix if the tree does not match that commit. Several saved federated JSONs still say `-DIRTY` and are not archival.
4. Measure sigma_c over 5 seeds and freeze the hypothesis thresholds (D-008 / D-017) — done.

See [RESULTS.md](RESULTS.md) § "Corrections from code review" before citing H1 or H3.

## Known measurement issue

On the synthetic fixture, cross-seed standard deviation of test PR-AUC is
approximately 0.078 - larger than the clean-vs-40%-noise gap. Any comparison on
a corpus this small is dominated by seed variance. Measure sigma_c on the real
corpus before trusting any difference, and treat 5 seeds as a minimum, not a
sufficiency.
## Five-client IID data preparation

Neural training selects a training-only balancing method in the `balancing`
section of `config/federated/character_cnn.json` or `deberta_v3_base.json`.
`config/balancing/` retains model-independent sampler presets. See
[CLASS_BALANCING.md](docs/CLASS_BALANCING.md) for counts, method support and the
remaining numerical-only SMOTE utility. The numerical classifier runner was removed.

All strategies follow [the shared shuffled-pool assignment policy](docs/PARTITION_SAMPLING.md).
Explicit `label_skew` and `category_skew` strategies accept exact target-count
plans through the same configuration entry point.
The exact requested label-skew preset and separate category-skew preset are
documented in [NON_IID_PARTITIONING.md](docs/NON_IID_PARTITIONING.md).

For selectable IID/non-IID methods, use `scripts/partition_clients.py --config`
with `config/five_client_iid.json` or `config/five_client_non_iid.json` and a fresh
`--output` directory. Both use the same local split/feature loader. See
[configurable experiments](docs/EXPERIMENT_CONFIGURATION.md) for commands,
customization and preparation-comparison checks. Model-performance comparisons
remain a subsequent training/evaluation task.

The current IID baseline reuses the audited cleaned corpus without changing its
totals. Run `python scripts/partition_iid.py` from the repository root. Settings
are in `config/five_client_iid.json`; output is ignored local
`data/client-iid-v1/`. Then each client independently runs:

```powershell
python scripts/split_client.py --client-dir data/client-iid-v1/client_000
```

Repeat for `client_001` through `client_004`. URLs are unique across clients;
domains may span clients but have one shared train/validation/test role.
The 70/15/15 fractions are approximate at row level. See
[docs/IID_PARTITIONING.md](docs/IID_PARTITIONING.md) for reproduction and leakage
rules. Existing training scripts still use the legacy simulation.

