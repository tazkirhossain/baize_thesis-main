# BAIZE — Research Design (Phase 0)

**Status:** DRAFT — awaiting supervisor sign-off
**Scope constraint:** 8 weeks to thesis submission, assumed single researcher
**Phase 0 gate:** NOT PASSED until §1 scope decision is confirmed and §3 dataset is identified

---

## 0. Scope decision (read this first)

The BAIZE master specification defines 10 research questions, 19 development phases,
14+ experiments, a browser extension, and a governance layer. That is a multi-year
programme. It cannot be executed in 8 weeks by one person at a standard that would
survive examination.

This document scopes the work into three tiers. **Only Tier 1 is promised.** Tier 2 is
attempted if the schedule holds. Tier 3 is written up as future work with a stated
reason for exclusion — which is a legitimate and expected thesis section, not a failure.

| Tier | Research questions | Commitment |
|---|---|---|
| **1 — Core** | RQ1 Classification, RQ2 FL vs centralized, RQ3 Noisy labels, RQ4 Robust aggregation, RQ5 Client heterogeneity | Must be completed and defensible |
| **2 — Stretch** | RQ10 Calibration & abstention, RQ7 LLM-assisted evaluation (narrowed, see §6) | Attempted only if Week 5 checkpoint is met |
| **3 — Deferred** | RQ6 Formal privacy (DP / secure aggregation), RQ8 Concept drift, RQ9 Adversarial URL robustness | Documented as future work with justification |

**Why these five are the core.** RQ1–RQ5 form one connected argument with a single
experimental infrastructure: build a URL classifier, federate it, degrade it with label
noise, try to repair it with robust aggregation, and check whether client heterogeneity
changes the answer. Every experiment reuses the same dataset, the same models, and the
same simulator. Nothing in Tier 1 requires infrastructure that does not also serve
another Tier 1 experiment. That is what makes it fit in 8 weeks.

**Why the deferred three are deferred.**

- **RQ6 (formal privacy).** Implementing DP-SGD in a federated setting and producing a
  meaningful ε with a correct privacy accountant is not a two-week task, and a wrong ε
  is worse than no ε. BAIZE will still make *architectural* privacy arguments
  (data minimisation, local inference, no raw-history transmission) — see `PRIVACY.md`.
  It will not claim a formal guarantee.
- **RQ8 (concept drift).** Requires reliable timestamps in the dataset. Whether this is
  even possible is unknown until Phase 1 completes. Do not commit to it in the proposal.
- **RQ9 (adversarial URL robustness).** Doing this properly requires a validity
  constraint (see `THREAT_MODEL.md` §5) that makes it substantially more work than it
  first appears. Done cheaply it produces a meaningless result.

**Browser extension.** Built as a proof-of-concept deployment artefact in Week 6,
approximately 2–3 days. It demonstrates that the model runs locally in a browser and
produces Adult / Non-Adult / Uncertain. It is **not** evaluated as a research
contribution and no claim in the thesis depends on it. Measure and report model size,
load time, and inference latency; that is all.

---

## 1. Research questions (scoped)

### RQ1 — Classification performance
How accurately can adult websites be detected from URL string features alone, and what
is the performance gap between a random split and a domain-aware split?

The second clause is the important one. URL classification results reported on random
splits are routinely inflated because the same registrable domain appears in both train
and test, reducing the task to domain memorisation. Reporting both splits is a
methodological contribution in its own right.

### RQ2 — Federated vs centralized
Under IID client partitions, how does FedAvg compare to centralized training on the same
data, at matched total training budget?

### RQ3 — Label noise
How does symmetric, class-conditional, and client-heterogeneous label noise at rates
{0, 10, 20, 30, 40}% degrade federated model performance on a clean held-out test set?

### RQ4 — Robust aggregation
Do coordinate-wise median, trimmed mean, and update-norm filtering mitigate the
degradation measured in RQ3, and under what noise conditions do they fail?

### RQ5 — Client heterogeneity
How does non-IID partitioning (label skew, quantity skew) interact with label noise and
with robust aggregation? Specifically: does robust aggregation that helps under IID
noise *hurt* under non-IID cleanliness by discarding legitimate minority clients?

RQ5 as phrased is the most interesting question in Tier 1. Robust aggregators identify
outlying updates; under non-IID data, a client with an unusual but *correct* label
distribution looks exactly like a noisy client. If BAIZE demonstrates that tension
quantitatively, that is a genuine result.

### RQ7 — LLM-assisted evaluation (Tier 2, narrowed — see §6)
### RQ10 — Calibration and abstention (Tier 2)

---

## 2. Hypotheses with pre-registered decision rules

Thresholds are declared **before** results are seen. Where a threshold depends on the
scale of natural variation, it is expressed relative to the cross-seed standard
deviation of the centralized baseline, which is measured in Phase 2 and then frozen.

Let `σ_c` = cross-seed standard deviation of centralized PR-AUC on the clean
domain-aware test set, measured over 5 seeds in Phase 2.

| ID | Hypothesis | Supported if | Falsified if |
|---|---|---|---|
| H1 | FedAvg under IID partition is competitive with centralized training | mean PR-AUC gap ≤ 2σ_c | gap > 2σ_c, consistently across seeds |
| H2 | Label noise monotonically degrades federated performance | PR-AUC decreases monotonically in noise rate, and the 0%→30% drop exceeds 3σ_c | no monotone trend, or drop within 3σ_c |
| H3 | Robust aggregation reduces noise-induced degradation | at ≥30% noise, best robust aggregator beats FedAvg by > 2σ_c | no robust aggregator beats FedAvg by > 2σ_c at any tested noise level |
| H4 | Non-IID partitioning degrades federated performance relative to IID at equal noise | PR-AUC gap > 2σ_c | gap ≤ 2σ_c |
| H5 | Robust aggregation imposes a cost under clean non-IID data | robust aggregators underperform FedAvg by > 2σ_c on clean non-IID | no significant difference |

H5 is a hypothesis that BAIZE's own proposed mechanism has a downside. It is included
deliberately. A thesis that only tests hypotheses favourable to its own system is weaker,
not stronger.

**These are hypotheses, not conclusions.** Any of them may be falsified, and a falsified
H3 is a publishable, thesis-worthy result — it would mean that for this task and this
noise model, robust aggregation does not deliver. Report it if it happens.

---

## 3. Dataset — open item, blocking

The dataset is described in the master spec as "approximately 500,000 mixed
websites/URLs." **It is not yet identified in this document.** Phase 1 cannot start until
it is. Record here, once known: name, source URL, version, licence, collection date and
methodology, and any published known limitations.

Do not proceed on an assumed sample count, field schema, or class balance. Phase 1's
first deliverable is a validation report that establishes these empirically.

Three RQ-level dependencies hang on Phase 1's findings:
- If the corpus has too few distinct registrable domains, the domain-aware split may be
  degenerate — RQ1's second clause weakens.
- If no reliable timestamps exist, RQ8 is unanswerable — already deferred.
- The dataset's own label noise rate (estimated by manual audit, see `LABELING_POLICY.md`
  §6) is a floor on all noise experiments and must be reported alongside injected noise.

---

## 4. Methodology

### 4.1 Splits
Two split regimes, both produced in Phase 1 and frozen:
- **Random split** — stratified by class. Reported for comparability with prior work.
- **Domain-aware split** — grouped by registrable domain (eTLD+1); no domain appears in
  more than one partition. **This is the primary regime.** Headline numbers come from it.

Proportions: 70 / 15 / 15 train / validation / test.

### 4.2 Test set protection
The test set is clean (no injected noise), is never used for model selection, and is
evaluated **once per experiment configuration** after all selection is complete. Every
model-selection decision uses validation only.

### 4.3 Validation set assumption — declare explicitly
Many robust-FL methods implicitly assume the server holds a small clean validation set.
BAIZE makes this assumption **explicitly**: the server holds a clean validation set of
modest size, drawn from the same distribution. This is stated as a limitation, because it
is a strong assumption that would not hold in a real deployment where nobody has clean
labels. Do not hide it.

### 4.4 Models
Start simple; escalate only on evidence.
- **Baseline:** character n-gram TF-IDF (3–5 grams) + logistic regression.
- **Neural:** small character-level CNN or MLP over learned character embeddings,
  constrained to a size that is plausible for browser deployment.

A transformer is used only if the two above are exhausted and there is a measured reason.
There will not be time. Assume there will not be time.

Model size, inference latency, and parameter count are recorded for every model, since
browser deployability is a design constraint on the whole project.

### 4.5 Federated simulation
Single-process simulation. Configurable: number of clients, partition strategy, rounds,
local epochs, batch size, client participation fraction, aggregation method, seed.

Default for headline experiments: N = 10 clients, full participation, 50 rounds,
3 local epochs — to be confirmed after a convergence check in Week 3.

**Matched-budget comparison (RQ2):** centralized and federated runs must see
comparable `passes_per_example` (centralized epochs vs `rounds × local_epochs ×
participation`), or the comparison is confounded. Record the budget for both.
Scripts write this onto every new result as `training_budget`. The published
E2 H1 comparison did **not** match (35 vs 180); do not describe it as matched
(D-026).

### 4.6 Noise injection
Applied to **training partitions only**, after splitting, with a recorded seed.
Mechanisms: symmetric flipping, class-conditional flipping, client-heterogeneous rates.
Validation gate: realised noise rate must match target within tolerance (see spec §27),
else the run is BLOCKED. Report realised, not target, rates in all results.

### 4.7 Aggregation methods
FedAvg (baseline); coordinate-wise median; trimmed mean (trim fraction β, swept);
update-norm clipping / norm-based filtering. Each documented with its threat model,
assumptions, and failure modes in `THREAT_MODEL.md`.

### 4.8 Metrics
**Primary metric, declared in advance: PR-AUC** on the clean domain-aware test set.
Chosen because the task is class-imbalanced and because ROC-AUC is optimistic under
imbalance.

Also reported for every configuration: accuracy, precision, recall, F1, ROC-AUC, FPR,
FNR, confusion matrix.

### 4.9 Deployment base-rate caveat — important
Dataset class balance is not deployment class balance. If adult sites are a small
fraction of real browsing traffic, a FPR that looks acceptable on a balanced test set
produces a large absolute number of false blocks in practice. Report, alongside headline
metrics, **precision recalculated at one or more assumed deployment base rates**, with the
assumption stated explicitly and flagged as an assumption rather than a measurement.

False positives and false negatives are not symmetric in cost here, and the thesis should
say which asymmetry it assumes and why. That is a stated design position, not an
empirical finding.

### 4.10 Convergence must be demonstrated, not assumed

No baseline or federated result is accepted until the validation metric is shown
to plateau. Required evidence: the metric curve extending past the chosen budget,
and best-epoch (or best-round) varying across seeds rather than pinning at the
cap. "Best epoch == cap for every seed" is a warning sign, not a result.

This was added after the first E1 run produced a complete, reproducible,
5-seed analysis with p = 1.9e-06 of a model that was merely under-optimised at
lr=2. Raising the learning rate to 160 moved test PR-AUC from 0.485 to 0.614 and
changed the headline RQ1 magnitude from 35% to 23.6%. The statistics were
correct throughout; the optimisation was not. See DECISIONS.md D-017 to D-019.

### 4.11 Statistics
5 seeds for headline comparisons; 3 seeds for parameter sweeps. Report mean and standard
deviation. Do not interpret differences smaller than the cross-seed spread. Where a
formal test is used, state the test and its assumptions; with n=5 the appropriate options
are limited and this should be acknowledged rather than papered over with a t-test whose
assumptions are unchecked.

---

## 5. Experiment matrix (Tier 1)

| ID | Configuration | Seeds | Answers |
|---|---|---|---|
| E1 | Centralized, clean, both split regimes, both model families | 5 | RQ1, establishes σ_c |
| E2 | FedAvg, IID, clean, N=10 | 5 | RQ2 / H1 |
| E3 | FedAvg, IID, noise ∈ {10,20,30,40}%, symmetric | 3 | RQ3 / H2 |
| E4 | FedAvg, IID, class-conditional noise at 20%, 30% | 3 | RQ3 |
| E5 | FedAvg, non-IID (label skew, quantity skew), clean | 3 | RQ5 / H4 |
| E6 | FedAvg, non-IID × noise {20,30}% | 3 | RQ5 |
| E7 | Robust aggregators × noise {20,30,40}%, IID | 3 | RQ4 / H3 |
| E8 | Robust aggregators, non-IID, **clean** | 3 | RQ5 / H5 |
| E9 | Heterogeneous noise: k of N clients noisy, k ∈ {1,3,5} | 3 | RQ3, RQ4 |
| E10 | Client count N ∈ {5, 10, 20} at fixed total data | 3 | RQ2, secondary |

E10 is the first thing to cut if the schedule slips.

**Ablation** is read directly off this matrix: E2→E3 isolates noise; E3→E7 isolates
robust aggregation; E2→E5 isolates heterogeneity. No separate ablation experiments are
needed, which is a deliberate design choice to save time.

---

## 6. RQ7 narrowed: what the LLM evaluation claim actually is

The master spec (§38, §41) states that final release decisions come from an explicit
quantitative policy and the LLM is advisory. If that holds, **the LLM cannot change any
outcome, so "does the LLM add value" has no dependent variable and is unfalsifiable as
written.**

If RQ7 is attempted, it is narrowed to one measurable claim:

> Given structured metric tables from the experiment matrix, does an LLM produce
> model-comparison summaries that are (a) factually grounded in the supplied numbers,
> and (b) consistent with the quantitative selection policy?

Measured by: **grounding rate** (proportion of factual assertions in the LLM output that
are checkable against the supplied table and correct), **fabrication rate** (assertions
not derivable from the supplied data), and **agreement rate** with the quantitative
policy's ranking, over repeated runs on the same input.

This is a claim about LLM reliability as an analysis tool, not a claim that the LLM
improves the models. Do not overstate it. It is a small, honest result.

---

## 7. Eight-week plan

| Week | Work | Gate |
|---|---|---|
| 1 | Dataset identification, loader, validation, dedup, leakage check, both splits, label audit sample | Dataset integrity PASS → `DATASET.md` |
| 2 | Centralized baselines (E1), error analysis, serialization round-trip, σ_c measured | Baseline reproducible |
| 3 | FL simulator, FedAvg, IID (E2), convergence check, reproducibility check | FedAvg reproducibility PASS |
| 4 | Partitioners (non-IID), noise injection + noise validation, E3–E6 | Noise validation PASS |
| 5 | Robust aggregators, E7–E9, multi-seed runs | **Checkpoint: if behind, cut Tier 2 entirely** |
| 6 | Figures, statistics, E10 if time; browser extension PoC (2–3 days); Tier 2 if on schedule | All Tier 1 results complete |
| 7 | Writing | Draft complete |
| 8 | Writing, reproducibility rerun of one experiment from saved config, limitations chapter | Submission |

**Weeks 7–8 are writing and are not negotiable.** Experiments finish in Week 6 or they
are cut. A thesis with fewer experiments and a good write-up passes; a thesis with more
experiments and a rushed write-up does not.

### Cut order if the schedule slips
1. E10 (client scaling)
2. Tier 2 entirely (LLM evaluation, calibration/abstention)
3. Browser extension PoC
4. Neural model family — report classical baseline only, and say why
5. Reduce seeds from 5 to 3 on headline experiments, and state it as a limitation

Do not cut, under any circumstances: the domain-aware split, the clean test set
protection, the noise validation gate, or the limitations chapter.

---

## 8. Risks to this plan

| Risk | Impact | Mitigation |
|---|---|---|
| Dataset is dirtier than expected; Week 1 overruns | Everything shifts | Hard stop Friday Week 1; ship with documented known issues rather than perfecting |
| Domain-aware split collapses performance to near-chance | RQ1 headline weakens | This is itself a finding; report it and pivot the narrative to "URL-only detection generalises poorly across domains" |
| Robust aggregation shows no benefit (H3 falsified) | Perceived as negative result | Pre-registration in §2 makes this a legitimate result; write it up as such |
| Supervisor expects all 10 RQs | Scope conflict late | **Resolve in Week 1.** Present this document. |
| Compute insufficient for 5 seeds × full matrix | Statistics weaken | Measure single-run cost in Week 3 and re-plan the matrix then, not in Week 6 |

---

## 9. Note on references

Method names used in this document (FedAvg, coordinate-wise median, trimmed mean, Krum,
DP-SGD, temperature scaling) refer to established techniques in the federated learning
and calibration literature. **Citations for the thesis must be verified against the actual
papers before submission** — do not cite from a secondary summary, including this
document. Author lists, titles, venues, and years must be checked at source.
