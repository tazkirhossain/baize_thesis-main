# BAIZE — Labelling Policy (Phase 0)

**Status:** DRAFT — must be finalised before Phase 1 label audit
**Why this exists:** "adult website" is not self-defining. Without a written policy, the
label noise being studied in RQ3 is partly the researcher's own inconsistency, and the
mapping from the source dataset's labels to BAIZE's target is an undocumented judgement
call. Both are fatal to the thesis's credibility.

---

## 1. Target definition

BAIZE performs **binary classification**:

```
1 = Adult
0 = Non-Adult
```

### Adult (label 1)
A page or site whose **primary purpose** is the delivery of sexually explicit material —
pornographic imagery or video, explicit sexual text, live sexual performance, or
commercial sexual services.

The operative test is *primary purpose*, not the presence of any sexual content.

### Non-Adult (label 0)
Everything else, including sites that contain incidental, clinical, educational, or
artistic sexual content where that is not the site's primary commercial purpose.

### Scope narrowing — state this explicitly
"Adult" here means **sexually explicit content only**. It does **not** cover the broader
"adult / age-restricted" category used by some commercial filtering products, which
typically bundles gambling, alcohol, tobacco, drugs, weapons, and graphic violence.

If the source dataset uses the broader definition, that is a **label mapping problem**,
not a detail — see §4. Do not silently inherit a different definition.

---

## 2. Inclusion and exclusion

### Included (label 1)
- Pornographic video and image hosting or aggregation
- Adult live-streaming and webcam platforms
- Commercial escort and sexual-services advertising
- Explicit erotic fiction sites where that is the site's purpose
- Adult content subscription and creator-monetisation platforms
- Adult retail where the storefront presents explicit imagery

### Excluded (label 0)
- Sexual health, contraception, STI, and clinical anatomy resources
- Sex education, including frank material aimed at adolescents or adults
- LGBTQ+ community, advocacy, health, and support resources
- Medical, academic, and research sites discussing sexuality
- Fine art, photography, and museum collections including nudes
- Mainstream news reporting on the adult industry or on sexual topics
- Dating and matchmaking platforms without explicit content
- Lingerie, swimwear, and fashion retail
- General social platforms that host user content of all kinds
- Fiction and literature archives with mixed content

The exclusions matter more than the inclusions. **A classifier that flags sexual health
and LGBTQ+ resources as adult is a harmful classifier**, and this is a well-known failure
mode of keyword-based content filters. False positives on these categories should be
called out specifically in error analysis (`RESEARCH.md` §4.9), not buried in an
aggregate FPR.

---

## 3. Ambiguous cases — rulings

Rulings are made once, here, and applied consistently. Each is a judgement, and a
different project could rule differently; what matters is that the ruling is written down.

| Case | Ruling | Reasoning |
|---|---|---|
| Mixed-content platform (mainstream site hosting some explicit user content) | **0** | Primary purpose is general; labelling 1 would flag major platforms wholesale |
| Adult creator platform where explicit content is the main draw | **1** | Primary purpose test |
| Site currently parked, expired, or redirecting, formerly adult | **0**, flag for exclusion | Label reflects current content; prefer removing from dataset |
| Domain that only *appears* adult from the URL string but is not | **0** | The label describes the site, not the string. These are the hard negatives that make the task real. |
| Explicit site with a completely innocuous URL | **1** | These are the irreducible false negatives. Keep them; they define the ceiling. |
| Non-English adult site | **1** | Policy is language-independent |
| Adult content behind a paywall or age gate | **1** | Access control does not change purpose |
| Escort / massage advertising with ambiguous framing | **1** if sexual services are the evident offering; otherwise **0**, and flag | Genuinely uncertain; record as ambiguous in the audit |
| Any site suggesting child sexual abuse material | **Exclude from dataset entirely; do not label, do not access, escalate** | See §7 |

---

## 4. Source label mapping — mandatory Phase 1 deliverable

The source dataset almost certainly does not use BAIZE's definition. Before any training:

1. Enumerate the source dataset's label set verbatim.
2. Record the source's own published definition of each label, if one exists. If none
   exists, record that fact — it is a limitation.
3. Write an explicit mapping table: `source_label → BAIZE_label`, with a one-line
   justification per row.
4. Identify source labels that **cannot** be mapped cleanly. Options: exclude those rows,
   or map them and document the assumption. Excluding is usually more defensible.
5. Report how many samples each mapping decision affects.

**If the source dataset uses a broad "adult/age-restricted" category that bundles
gambling and violence with pornography, BAIZE has three choices:** narrow the target to
match §1 and accept unmappable rows; widen BAIZE's definition to match the source and
rewrite §1 accordingly; or exclude the ambiguous subcategories. Whichever is chosen, it is
a documented decision in `DECISIONS.md`, and it changes what RQ1's headline number means.

---

## 5. URL-only evidence — the fundamental caveat

The label describes **site content**. The model's only evidence is the **URL string**.
These are different objects. There exist explicit sites with neutral URLs and neutral
sites with suggestive URLs, and no URL-only model can resolve them.

This is not a limitation of BAIZE's method; it is a property of the task. It sets a
ceiling on achievable performance that is unknown and dataset-dependent. Do not report a
high accuracy figure as if it approached a solved problem, and do not attribute residual
error entirely to model capacity.

---

## 6. Label audit procedure (Phase 1, Week 1)

The dataset's own label noise is a floor under every noise experiment in RQ3. Injecting
20% noise into a corpus that already has 8% noise means the model sees roughly 26% wrong
labels, not 20% — and the RQ3 curve is meaningless if the baseline is unknown.

**Procedure:**
1. Draw a random sample — 300 URLs is a reasonable starting size, stratified by class —
   with a recorded seed.
2. Assess each against §1–§3 **without visiting the sites** (see §7). Use domain
   reputation data, public category listings, and the URL structure itself. Where the
   assessment cannot be made confidently from these, mark `UNDETERMINED` rather than
   guessing.
3. Record: agreement with dataset label, disagreement, undetermined.
4. Report the estimated label error rate **with a confidence interval**, and report the
   undetermined fraction separately — a high undetermined rate means the estimate is weak
   and must be presented as such.
5. Report disagreements broken down by direction (adult→non-adult vs the reverse), since
   asymmetry informs the class-conditional noise model in E4.

If two people are available, have both audit an overlapping subset and report
inter-annotator agreement. With one person, state that the audit is single-annotator and
therefore an estimate of *consistency with the policy*, not of ground truth.

---

## 7. Safety and handling constraints during labelling

- **Do not browse to URLs in the dataset to verify labels.** Assess from metadata,
  reputation sources, and URL structure. Visiting is unnecessary for this research, may
  breach institutional acceptable-use policy, and carries security risk.
- If any URL is suspected of relating to child sexual abuse material, do not access it,
  do not include it in the dataset, do not catalogue it, and follow your institution's
  reporting procedure immediately. This overrides every research consideration in this
  document.
- Do not reproduce explicit URLs verbatim in the thesis, in figures, or in error-analysis
  tables. Use structural descriptions or redacted forms.
- Handle the dataset under whatever access controls the source licence requires; record
  the licence in `DATASET.md`.
