# Agreed project structure

Recorded: 18 October 2026 (Asia/Dhaka).

This is the user's preferred target architecture for future development. Adapt
the existing repository incrementally instead of forcing a complete rewrite.
Saving this preference does not move files or implement Flower clients/servers.

```text
config/                 Experiment configurations
data/                   Ignored local datasets and generated client partitions
src/
  data/                 Preprocessing, partitioning, local splitting, balancing
  models/               Model implementations, organized by descriptive model name
  client/               Flower client implementation
  server/               Flower server and aggregation
  evaluation/           Metrics and report generation
scripts/                Data preparation and experiment entry points
results/                Structured aggregate metrics and generated plots
tests/                  Partition, balancing, leakage and metric tests
README.md               Setup and reproduction instructions
docs/                   Research policies, architecture and completed-work record
```

## Responsibilities

- `config/`: declared experiment settings such as seeds, client counts, split
  fractions, feature settings, model settings and training budgets. Credentials
  and secrets do not belong in committed configuration files.
- `data/`: raw CSV, cleaned records, client-owned data, local splits, exclusions,
  code/runtime snapshots and sensitive generated artifacts. Keep this ignored.
- `src/data/`: reusable data logic. Keep entry-point orchestration in `scripts/`.
  Any future balancing/resampling must operate on training data only.
- `src/models/`: use model-specific module or directory names. When using two or
  more models, keep their implementations distinguishable; avoid generic names
  such as `model1` and `model2`.
- `src/client/`: each Flower client's local data loading, training and local
  validation/test evaluation. A client should need only its own data directory
  and the shared preprocessing/model configuration.
- `src/server/`: Flower orchestration, model/update aggregation and appropriate
  aggregation of client-reported evaluation results.
- `src/evaluation/`: reusable metrics, evaluation checks and reports, separate
  from data preparation and training entry points.
- `results/`: only aggregate, sanitized metrics and plots intended for sharing.
  Raw URLs, IDs, row-level exclusions, secrets and checkpoints must remain in
  ignored local storage. Do not weaken the existing safety guard to publish them.
- `tests/`: integrity and behavioral tests, including leakage, unique client
  ownership, local splitting, future training-only balancing, and metrics.
- `README.md`: current environment setup, preparation, client splitting,
  experiment commands and reproduction instructions.

## Existing repository mapping

| Target location | Current implementation/status |
|---|---|
| `config/` | IID, exact label-skew, separate category-skew and optional Dirichlet presets; legacy settings also live in dataclasses and scripts |
| `data/` | Ignored audited source `data/client-datasets-v3/`; historical IID plus independent `client-label-skew-v1/` and `client-category-skew-v1/` outputs |
| `src/data/` | Configurable IID/Dirichlet strategies, shared audited partition engine, comparison checks and domain split policy; existing cleaning/loading remains in `baize/data/` |
| `src/models/` | User-supplied `character_cnn/model.py`; pretrained DeBERTa-v3-base loader/binary head in `deberta_v3_base/model.py`; numerical classifiers removed; legacy model remains `baize/models/linear.py` |
| `src/client/` | Immutable split reader, fixed neural encoders and Flower neural training/evaluation endpoint |
| `src/server/` | Five-client Flower FedAvg, sampling/contracts, local transport and local-validation aggregation; legacy simulator retained in `baize/federated/` |
| `src/evaluation/` | Shared both-class metrics, distributed counts, source-backed comparison exports and static research plots; legacy metrics remain in `baize/evaluation/` |
| `scripts/` | Already present; preparation and local splitting entry points are implemented |
| `results/` | Historical experiment metrics are in `experiments/results/`; preserve their provenance when adapting |
| `tests/` | Already present, including preprocessing and repository safety tests |
| `README.md` | Already present; update commands whenever implementation paths change |

## Migration and data rules

1. Follow this target structure when planning future work. Do not duplicate
   implementations across old and new paths or break existing imports merely
   to make the directory tree match immediately.
2. When relocating modules, update packaging, imports, scripts, tests, documented
   commands and path-based defaults together. Preserve compatibility where needed.
3. Keep historical result files and data/source snapshots intact; a directory
   reorganization does not establish new experimental results.
4. Preserve the agreed preparation order: global offline cleaning/deduplication,
   unique URL client allocation, local approximate 70/15/15 splits on each client,
   then client-side feature extraction and normalization. Learned preprocessing
   must use training data only. The user selected URL-level IID for this baseline:
   domains may span clients but have one shared split role across all clients.
   Historical domain-exclusive allocations remain available as separate outputs.
5. Do not silently resample or change dataset totals during restructuring.
   Keep the source identity and exclusion audit intact.
6. Preserve version-control safeguards. Run the repository safety check before
   committing in a real Git checkout. This exported workspace currently has no
   Git index, so prior tracked/remote state is not verifiable here.

See `PREPROCESSING.md` for the active data workflow and `version2_readme.md` for
the completed-work record and remaining implementation tasks.
