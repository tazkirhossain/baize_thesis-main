# BAIZE — Decision Log

Every entry: what was decided, why, what was rejected, and what would reverse it.
Append-only. Do not edit past entries; supersede them with a new one.

---

### D-001 — Scope reduced from 10 research questions to 5 core + 2 stretch

- **Decision:** Tier the RQs. Core: RQ1–RQ5. Stretch: RQ7, RQ10. Deferred to future work:
  RQ6 (formal privacy), RQ8 (drift), RQ9 (adversarial URLs).
- **Reason:** 8-week thesis deadline. The full specification is a multi-year programme.
  Ten shallow results are worth less than five defensible ones.
- **Alternatives rejected:** attempt all ten (produces uniformly thin evidence);
  reduce to three (leaves the FL/noise/robustness argument incomplete).
- **Trade-off:** the thesis will not make any formal privacy or adversarial-robustness
  claim. Both become explicit future-work sections with stated reasons.
- **Reverses if:** deadline extends beyond ~4 months, or a second researcher joins.
- **Status:** PENDING SUPERVISOR CONFIRMATION — this is the single highest-risk open item.

---

### D-002 — Domain-aware split is the primary evaluation regime

- **Decision:** Headline numbers come from a split grouped by registrable domain
  (eTLD+1). Random split reported alongside, for comparability only.
- **Reason:** With a random split, the same domain appears in train and test, and the
  model can score highly by memorising domains rather than learning URL structure. That
  inflates results and does not reflect deployment, where unseen domains are the norm.
- **Alternatives rejected:** random split only (standard but misleading here).
- **Trade-off:** headline numbers will be lower — possibly much lower. This is correct,
  and the gap between the two regimes is itself a reportable result.
- **Reverses if:** Phase 1 shows too few distinct domains for a viable grouped split.
- **Status:** ACTIVE

---

### D-003 — Primary metric is PR-AUC on the clean domain-aware test set

- **Decision:** PR-AUC declared as the primary metric in advance. All other metrics
  reported but not used for headline claims or hypothesis decisions.
- **Reason:** class-imbalanced task; ROC-AUC is optimistic under imbalance; declaring in
  advance prevents post-hoc metric shopping.
- **Alternatives rejected:** accuracy (misleading under imbalance); F1 (threshold-dependent).
- **Trade-off:** PR-AUC is sensitive to class balance, so it is not comparable across
  datasets with different balance. Must state the test-set balance whenever reporting it.
- **Reverses if:** Phase 1 finds the dataset is close to balanced, in which case revisit.
- **Status:** ACTIVE

---

### D-004 — Server holds a clean validation set (stated assumption)

- **Decision:** The federated server is assumed to hold a small clean, correctly-labelled
  validation set for model selection.
- **Reason:** Required for meaningful model selection under label noise; also implicitly
  assumed by much of the robust-FL literature.
- **Alternatives rejected:** noisy validation set (makes selection unreliable and
  confounds RQ3/RQ4); no validation set (no principled selection).
- **Trade-off:** **This is a strong and somewhat unrealistic assumption.** In a real
  deployment nobody holds clean labels — that is the entire premise of the noisy-label
  problem. It must appear in the limitations chapter, not only in a methods footnote.
- **Reverses if:** time permits a no-clean-validation variant as a robustness check.
- **Status:** ACTIVE

---

### D-005 — Browser extension is a proof-of-concept artefact, not a research contribution

- **Decision:** Build in Week 6, ~2–3 days. Report model size, load time, inference
  latency. No research claim depends on it. First candidate for cutting after Tier 2.
- **Reason:** The extension demonstrates deployability and completes the system narrative,
  but no RQ requires it. Building it properly would consume weeks that Tier 1 needs.
- **Alternatives rejected:** full extension with federated participation (weeks of work,
  plus ethics review for any real data collection).
- **Trade-off:** the deployment half of the BAIZE vision is demonstrated, not evaluated.
- **Status:** ACTIVE

---

### D-006 — RQ7 (LLM evaluation) narrowed to a grounding-and-consistency claim

- **Decision:** If attempted, RQ7 measures grounding rate, fabrication rate, and agreement
  with the quantitative selection policy — not "does the LLM improve model selection."
- **Reason:** The specification requires final decisions to come from an explicit
  quantitative policy. Under that constraint the LLM cannot change any outcome, so the
  original framing has no dependent variable and is unfalsifiable.
- **Alternatives rejected:** let the LLM make selection decisions (contradicts spec §38
  and produces an unreproducible pipeline); drop RQ7 entirely (still an option if Week 5
  checkpoint is missed).
- **Trade-off:** a smaller claim, but a measurable one.
- **Status:** ACTIVE (Tier 2)

---

### D-007 — Query strings excluded from features by default

- **Decision:** Drop query string and fragment during URL normalisation. Reconsider only
  if a feature-utility study shows material gain, and then only as structural statistics.
- **Reason:** Query strings are the highest-risk component for session tokens, search
  terms, and personal identifiers. Data minimisation (`PRIVACY.md` §3).
- **Alternatives rejected:** include raw query tokens (privacy cost not justified by
  unmeasured benefit).
- **Trade-off:** possible loss of predictive signal, which must be reported as a
  limitation rather than assumed to be zero.
- **Reverses if:** a Phase 2 ablation shows a large, reproducible performance gap.
- **Status:** ACTIVE

---

### D-008 — Pre-registered hypothesis thresholds expressed relative to baseline seed variance

- **Decision:** Decision rules in `RESEARCH.md` §2 use multiples of σ_c, the cross-seed
  standard deviation of the centralized baseline, measured in Phase 2 and then frozen.
- **Reason:** Absolute thresholds chosen before knowing the natural variation of the
  pipeline are arbitrary. Anchoring to measured variance keeps the rule pre-registered
  while making it meaningful.
- **Alternatives rejected:** fixed percentage-point thresholds (arbitrary); no
  pre-registration (invites post-hoc rationalisation).
- **Trade-off:** thresholds are not final until end of Week 2. Freeze them then, in
  writing, before any federated result is seen.
- **Status:** ACTIVE

---

### D-009 — H5 included: robust aggregation is hypothesised to have a cost

- **Decision:** Explicitly test whether robust aggregation degrades performance under
  clean non-IID data (experiment E8).
- **Reason:** Robust aggregators cannot distinguish "wrong" from "different." A
  legitimate minority client under non-IID partitioning looks like a corrupted one.
  Testing only favourable hypotheses weakens a thesis.
- **Trade-off:** may produce a result unflattering to BAIZE's own proposed mechanism.
  That is the point.
- **Status:** ACTIVE

---

### D-010 — Dataset not yet identified; Phase 1 is blocked

- **Decision:** No implementation work begins until the source dataset is named, its
  licence recorded, and its schema inspected.
- **Reason:** Three RQ-level design choices depend on properties of the actual data
  (domain diversity, timestamp availability, source label taxonomy). Building on assumed
  properties risks rework in a schedule with no slack.
- **Status:** **OPEN — BLOCKING**

---

### D-010 — CLOSED: dataset identified

- **Resolution:** `url.csv`, 1,562,978 rows, 15-category directory taxonomy,
  Adult = 2.26%. Documented in `docs/DATASET.md`. Phase 1 gate PASS WITH FINDINGS.
- **Supersedes:** the OPEN/BLOCKING status of the original D-010.
- **Note:** the master spec's "~500,000 URLs" was wrong by 3x. Provenance and
  licence remain unverified and are now tracked as D-014.
- **Status:** CLOSED

---

### D-011 — Deduplicate before splitting; drop label-conflicting URLs

- **Decision:** Canonical-URL deduplication runs before the split. URLs appearing
  with both labels (148 cases) have all copies dropped rather than resolved.
- **Reason:** Deduplicating after splitting cannot undo leakage already baked in.
  Silently keeping one label of a conflicting pair would discard measured
  evidence of source noise.
- **Trade-off:** loses 93,688 rows (6.0%). Acceptable given 1.47M remain.
- **Status:** ACTIVE

---

### D-012 — Corpus age is a headline limitation, not a footnote

- **Decision:** State in the abstract that results describe the pre-2010 web.
  Make no live-web accuracy claim for the browser extension.
- **Reason:** HTTPS share is 0.068% and ~6.7% of the corpus sits on free-hosting
  platforms of the 1996-2009 era. The corpus predates modern URL structure.
- **Alternatives rejected:** burying it in limitations (misleading); abandoning
  the corpus (no better one is available inside the deadline).
- **Consequence:** RQ8 (drift) is promoted from deferred future work to a stated
  limitation of the present results. If a modern URL sample can be obtained,
  measuring the drift penalty directly becomes the highest-value optional
  experiment in the project.
- **Status:** ACTIVE

---

### D-013 — Report the source noise floor with every injected-noise result

- **Decision:** Every RQ3/RQ4 result quotes the measured source noise floor
  alongside the injected rate. Current lower bound: 148 label conflicts.
- **Reason:** Injected noise adds to pre-existing noise. A "20% noise" condition
  on a corpus with intrinsic noise is not a 20% noise condition, and reporting it
  as one would be a fabricated experimental parameter.
- **Open:** the 148 conflicts are a lower bound only. The label audit
  (LABELING_POLICY.md §6) must produce a proper estimate with an interval.
- **Status:** ACTIVE

---

### D-014 — Licence and provenance unresolved; blocking for publication

- **Decision:** Do not publish or release results until the corpus licence and
  collection methodology are confirmed at source.
- **Reason:** The file carries no provenance metadata. The taxonomy matches DMOZ
  top-level categories, which is strong circumstantial evidence but not proof.
  An unlicensed corpus of adult URLs is a publication and ethics risk.
- **Status:** OPEN — BLOCKING for publication, not for experimentation

---

### D-015 — sigma_c measured and hypothesis thresholds FROZEN

- **Decision:** sigma_c = 0.00863, measured as the cross-seed sd of centralized
  test PR-AUC on the domain-aware split, 5 seeds, 40 epochs. The RESEARCH.md §2
  decision rules are frozen at:
  - H1 supported if FedAvg-vs-centralized gap <= 0.0173
  - H2 supported if clean->30% noise drop > 0.0259
  - H3 supported if best robust aggregator beats FedAvg by > 0.0173 at 30% noise
  - H4 supported if IID-vs-non-IID gap > 0.0173
  - H5 supported if robust agg underperforms FedAvg by > 0.0173 on clean non-IID
- **Reason:** D-008 requires thresholds anchored to measured variance and frozen
  before any federated result is seen. No federated experiment has been run.
- **Evidence:** experiments/results/E1_summary.json
- **Caveat:** models were NOT converged (best epoch = 40 of 40 for all 10 runs).
  sigma_c is a valid measure of seed variance AT THIS BUDGET, but should be
  re-measured after a converged run before the thresholds are treated as final.
- **Reverses if:** a converged run changes sigma_c by more than ~2x. If so,
  re-freeze and document both values; never silently adopt the more convenient one.
- **Status:** ACTIVE

---

### D-016 — RQ1 answered: random splits inflate PR-AUC by 35%

- **Finding:** paired over 5 seeds at identical budget, random split test PR-AUC
  0.6550 (sd 0.0037) vs domain-aware 0.4850 (sd 0.0086). Inflation 0.1700
  absolute, 35.0% relative, 19.7 sigma_c. Paired t = 41.9, p = 1.9e-06;
  Wilcoxon p = 0.0625 (the floor attainable at n=5).
- **Interpretation:** a random split places the same registrable domain in train
  and test, so roughly a third of apparent performance is domain memorisation
  rather than generalisation to unseen sites.
- **Consequence:** all headline numbers come from the domain-aware regime. The
  random-split figure is reported only as a comparability reference and is
  labelled as inflated wherever it appears.
- **Note:** this holds even though 93% of domains contribute a single URL
  (DATASET.md §4), which had suggested the two regimes might differ little. They
  do not - the effect is driven by the minority of multi-URL domains.
- **Status:** ACTIVE

---

### D-017 — SUPERSEDES D-015: sigma_c re-measured after convergence, thresholds re-frozen

- **Trigger:** D-015's reversal condition. The original E1 baseline was
  LEARNING-RATE limited, not epoch limited: a probe showed lr=160 at 12 epochs
  (val PR-AUC 0.601) beating lr=2 at 40 epochs (0.485). A convergence check at
  lr=160 plateaus from ~epoch 30 (val PR-AUC 0.6086 / 0.6106 / 0.6105 / 0.6095
  at epochs 30/35/40/45).
- **Decision:** sigma_c = 0.00718, measured at lr=160, 35 epochs, 5 seeds,
  domain-aware split. Thresholds re-frozen:
  - H1 supported if FedAvg-vs-centralized gap <= 0.0144
  - H2 supported if clean->30% noise drop > 0.0215
  - H3 supported if best robust aggregator beats FedAvg by > 0.0144 at 30% noise
  - H4 supported if IID-vs-non-IID gap > 0.0144
  - H5 supported if robust agg underperforms FedAvg by > 0.0144 on clean non-IID
- **Both values on record**, as D-015 requires: under-trained sigma_c = 0.00863,
  converged sigma_c = 0.00718. Ratio 0.83, well inside the ~2x reversal band, so
  the thresholds shift only slightly. The under-trained results remain on disk
  (`E1_*_seeds.jsonl`) alongside the converged ones (`E1_*_seeds_lr160.jsonl`);
  neither was overwritten.
- **Convergence evidence:** best epoch now varies across seeds (30-35) rather
  than pinning at the cap, which is what a genuine plateau looks like. All ten
  under-trained runs had best epoch = 40 of 40.
- **Status:** ACTIVE (supersedes D-015)

---

### D-018 — REVISES D-016: converged split-regime inflation is 23.6%, not 35%

- **Finding (converged, paired over 5 seeds, lr=160, 35 epochs):**
  random 0.7598 (sd 0.0034) vs domain-aware 0.6145 (sd 0.0072).
  Inflation 0.1452 absolute, **23.6% relative**, 20.2 sigma_c.
  Paired t = 34.2, p = 4.4e-06; Wilcoxon p = 0.0625 (floor at n=5).
- **Why revised:** D-016 reported 35% from the under-trained runs. Both regimes
  gained from the LR fix but NOT equally - the domain-aware split gained more
  (+0.130) than the random split (+0.105), narrowing the relative gap. The
  caution recorded when D-016 was written was warranted.
- **What did not change:** direction, and separation at ~20 sigma_c either way.
  The conclusion is unaffected; only the magnitude is.
- **Reporting rule:** quote 23.6%. The 35% figure must not be cited - it
  describes an under-trained model.
- **Status:** ACTIVE (supersedes D-016)

---

### D-019 — Convergence is now a Phase 2 gate condition

- **Decision:** No baseline is accepted until validation-metric plateau is
  DEMONSTRATED. Required evidence: the metric curve over a range extending past
  the chosen budget, and best-epoch varying across seeds rather than pinning at
  the epoch cap.
- **Reason:** this session produced a fully correct statistical analysis -
  5 seeds, error bars, paired t-test, p = 1.9e-06 - of a model that was simply
  under-optimised. The statistics were never wrong; the optimisation was. Nothing
  in the existing gates would have caught it, because every run was internally
  consistent and reproducible.
- **Generalisation:** "best epoch == epoch cap for every seed" is a warning sign,
  not a result. Add it as an automated check in the experiment validation gate.
- **Applies to:** every federated experiment too - a federated run that has not
  converged in rounds will understate FL and make H1 look false for the wrong
  reason.
- **Status:** ACTIVE

---

### D-020 — Federated hyperparameters fixed; per-run cost measured

- **Local learning rate: 160.** Probed on the real corpus with 10 IID clients,
  8 rounds, 1 local epoch: lr=40 -> 0.4170, lr=160 -> 0.4983, lr=400 -> 0.4848.
  The centralized optimum transfers; this was checked rather than assumed.
- **Rounds: 40**, local_epochs=3, batch=512, l2=1e-7. At 40 rounds the last-5-round
  validation spread is 0.0020 (D-019 plateau check passes).
- **Cost: ~12s/round, ~8 min per 40-round run** (10 clients, full participation,
  1.03M training rows, single core).
- **Consequence - SCHEDULE RISK, needs a decision.** The Tier 1 matrix is roughly
  26 configurations; at 5 seeds that is ~130 runs, on the order of **17 hours
  single-core**. That does not fit alongside writing in the remaining weeks.
  Options, to be chosen deliberately and logged, not allowed to happen silently:
    (a) subsample the corpus for federated experiments, with a stated
        justification and a check that E1 behaviour is preserved at that size;
    (b) 3 seeds for sweeps, 5 only for the headline H1/H3 comparisons;
    (c) fewer rounds where a configuration demonstrably plateaus earlier;
    (d) reduce the noise sweep from {10,20,30,40}% to {20,40}%.
  Recommended: (b) + (c) first, since neither weakens a headline claim.
- **Status:** ACTIVE; sub-decision on the matrix reduction OPEN

---

### D-021 — Federated runs are checkpointed and resumable

- **Decision:** `scripts/fedavg_run.py` checkpoints global parameters, per-client
  RNG bit-generator states and history after every round.
- **Reason:** an 8-minute run exceeds the available wall-clock per invocation.
  Saving RNG state (not just parameters) keeps the mini-batch permutation
  sequence independent of where a run was interrupted.
- **Verified:** a 20-round run extended to 40 rounds continued the validation
  curve smoothly (0.5847 at r20 -> 0.5909 at r25) with no discontinuity.
- **Caveat:** resume equivalence has been observed, not proven. A run executed
  straight through has not been compared bit-for-bit against a resumed one. Do
  that once before relying on it for a headline result.
- **Status:** ACTIVE

---

### D-022 — PRELIMINARY H1 signal (seed 0 only, NOT a result)

- **Observation:** FedAvg IID, domain-aware, seed 0, 40 rounds:
  test PR-AUC 0.6094 vs centralized 0.6191 at the same seed. Gap 0.0097,
  below the frozen H1 threshold of 0.0144 (2 sigma_c).
- **Status: NOT A RESULT.** One seed. H1 requires the 5-seed paired comparison.
  Recorded so that the number is not re-derived later and mistaken for evidence.
- **Watch:** the D-019 plateau criterion (last-5-round spread < 0.005) passed at
  spread 0.0020, but validation was still creeping upward (0.5950 -> 0.5988 ->
  0.6014). The criterion may be too permissive for federated runs, where
  per-round gains are small by construction. If the 5-seed H1 comparison lands
  near the threshold, tighten the criterion and re-run rather than calling it.
- **Status:** OPEN

---

### D-023 — CLOSES D-022: H1 SUPPORTED

- **Result (E2, FedAvg, IID, 10 clients, 60 rounds, domain-aware, 5 seeds):**
  centralized 0.6145, FedAvg 0.6112, mean gap **0.00334** (sd 0.0005),
  = 0.47 sigma_c, against the frozen threshold of 0.01436 (2 sigma_c).
  0 of 5 seeds exceed the threshold. Paired t = 14.68, p = 0.0001.
- **Verdict: H1 SUPPORTED.** FedAvg over 10 IID clients reaches centralized
  performance within the tolerance pre-registered in D-017, which was frozen
  before any federated run existed.
- **The gap is real but small.** It is statistically distinguishable from zero
  (p = 0.0001) while being far inside the practical-equivalence threshold. Those
  are different claims and the write-up must not conflate them: FedAvg is
  measurably but negligibly worse than centralized here.
- **Scope:** IID, 10 clients, full participation, clean labels, this corpus,
  this linear model. This is NOT "federated learning works for this task".
  Non-IID is RQ5; noisy labels are RQ3.
- **Status:** ACTIVE

---

### D-024 — Rounds raised 40 -> 60; D-019 check was incomplete

- **What happened:** the first E2 aggregation reported H1 SUPPORTED at 40 rounds
  with all five seeds "plateaued = True". But best_round was 40 = the cap for
  every seed - the exact pinning signature D-019 names as a warning. The
  aggregation script checked only the plateau-spread half of D-019 and not the
  best-round half, so it passed a run that had not converged.
- **Effect of fixing it:** extending 40 -> 60 rounds moved FedAvg from 0.6059 to
  0.6112 and the gap from 0.00865 to 0.00334, i.e. the 40-round gap was **2.6x
  too large**. The verdict did not change, but the reported effect size did.
- **Decision:** federated runs use 60 rounds. Both halves of D-019 are now
  enforced in `scripts/e2_aggregate.py`.
- **Residual, stated honestly:** at 60 rounds seeds 1-4 still have best_round at
  the cap; only seed 0 (best round 59) is unambiguously converged. The remaining
  gap is therefore an UPPER bound. This is safe for an H1 SUPPORTED verdict -
  more rounds can only shrink the gap - but the asymmetry matters: **an H1
  FALSIFIED verdict under cap-pinning would not have been trustworthy.**
  Apply this asymmetry to H2-H5 as well: a hypothesis whose direction is helped
  by more training must not be rejected while runs are still improving.
- **Cost note:** 60 rounds is ~12 min/run, revising the D-020 budget estimate
  upward by 50%. The matrix reduction sub-decision is now more urgent, not less.
- **Status:** ACTIVE

---

### D-025 — SUPERSEDES the D-019 plateau test: slope-based convergence

- **Problem:** the spread-based test ("last 5 rounds within 0.005") was wrong in
  BOTH directions, which only became visible once noisy runs existed.
  - Too STRICT under noise: label noise makes the validation curve oscillate
    permanently around a stable level. Every 20%/40% run reported
    plateaued=False at spreads of 0.006-0.013 and would never have passed,
    however long it ran.
  - Too PERMISSIVE on clean runs: `e2_iid_seed1` and `e5_labelskew_a1_seed0`
    both reported plateaued=True while still projecting +0.003 over another 15
    rounds.
- **Decision:** `baize/evaluation/convergence.py`. Fit a least-squares line to
  the tail of the curve; classify by whether the slope is distinguishable from
  zero given the curve's own scatter. Oscillation inflates the residual scatter,
  widening the slope's standard error, which correctly makes the test more
  tolerant of a noisy-but-stationary curve. A slope must be BOTH statistically
  significant AND project a gain above `negligible_gain` to count as IMPROVING -
  significance alone is not a reason to spend compute.
- **Three outcomes, not two:** CONVERGED / IMPROVING / DEGRADING. DEGRADING is
  new and matters: at 40% noise the curve peaks at round 15 and declines, so a
  fixed round budget across a noise sweep would under-report high-noise settings
  and INFLATE H2. Best-round is itself a reportable quantity per noise level.
- **Re-assessment of completed runs:**

  | run | old | new | best round | projected gain |
  |---|---|---|---|---|
  | e2_iid_seed0 | True | CONVERGED | 80 | +0.0015 |
  | e2_iid_seed1 | True | IMPROVING | 60 | +0.0034 |
  | e5_labelskew_a1_seed0 | True | IMPROVING | 80 | +0.0030 |
  | e5_labelskew_a1_seed1 | True | CONVERGED | 60 | +0.0020 |
  | e3_noise20_seed0 | False | CONVERGED | 65 | +0.0048 |
  | e3_noise40_seed0 | False | DEGRADING | 15 | -0.0157 |

- **Effect on decided hypotheses:** none reverses. H1's FedAvg arm is still
  IMPROVING, which can only shrink the 0.0033 gap - H1 stays supported. H4's
  non-IID arm is IMPROVING by ~0.003 against a 0.0289 gap and a 0.0144
  threshold, so H4 survives comfortably. Both were already argued as one-sided
  bounds under D-024; this confirms it quantitatively rather than by assumption.
- **Status:** ACTIVE (supersedes the plateau half of D-019; the best_round-at-cap
  half of D-019 remains and is now reported as `best_at_cap`)

---

### D-026 — Library correctness fixes; reported numbers are NOT recomputed

- **Decision:** Fix the pipeline bugs identified in the full-codebase review
  (centralized last-epoch selection in `run_experiment`, unwired protected
  labels, shared-matrix client slices, quantity-skew remainder, unknown-label
  mapping, `NormalizedURL.raw` retaining query/userinfo, trimmed-mean weight
  silence, `phase2_baseline.py` still on lr=2, stale E1 aggregate printout,
  scattered production hyperparameters). Record training budget
  (`passes_per_example`) on every new run. Correct the *write-up* of H1/H3
  where it overstated what was run. Do **not** silently recompute or overwrite
  existing `experiments/results/*.json` numbers.
- **Reason:** The headline JSONs were produced by `scripts/e1_multiseed.py` and
  `scripts/fedavg_run.py`, which already selected on validation. Changing those
  files would mix a new code version into an old result table. The library
  path used by tests and smoke runs must still be correct.
- **What this does not do:** re-run H1 at matched `passes_per_example`; complete
  E3–E7/E10; run class-conditional noise or quantity-skew; resolve D-014.
- **Reverses if:** the corpus is available and a matched-budget E2 is executed
  under a clean git commit; then H1 must be re-decided under D-017.
- **Status:** ACTIVE

