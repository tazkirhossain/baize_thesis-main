# BAIZE — Dataset Documentation

**Phase 1 gate: PASS WITH FINDINGS**
Closes `DECISIONS.md` D-010.

---

## 1. Identification

| Field | Value |
|---|---|
| File | `src/url.csv` from `github.com/Tazkir-Hossain/Federated_Learning_Char_CNN_Model` |
| Size | 81,158,072 bytes |
| Format | Headerless CSV, 3 fields: `id,url,label` |
| Rows | 1,562,978 (all rows parse to exactly 3 fields — no embedded commas) |
| Dataset ID | `url-csv-v1` |
| Fingerprint (post-dedup, SHA-256) | `c37afd419b3c7dc4aeaf2b58192fb5c943a8daef4b44ea5a59d09c87f050b73a` |
| **Provenance** | **UNVERIFIED** |
| **Licence** | **UNKNOWN — must be resolved before publication** |
| **Collection date** | **Not stated in the file; estimated pre-2010, see §5** |

The row count is 1.56M, **not the ~500,000 assumed in the master specification**.
Update the spec.

The 15-category label taxonomy (Adult, Arts, Business, Computers, Games, Health,
Home, Kids, News, Recreation, Reference, Science, Shopping, Society, Sports)
matches the Open Directory Project (DMOZ) top-level categories. That is strong
circumstantial evidence of DMOZ derivation, but the file contains no provenance
metadata and I have not verified it against a DMOZ release. **Treat as unverified
until confirmed at source.** Licence and collection methodology are required
before any publication.

---

## 2. Label mapping (`LABELING_POLICY.md` §4)

`Adult -> 1`, all 14 other categories `-> 0`. This retains the original
repository's mapping for comparability.

| Category | Count | Share | BAIZE |
|---|---:|---:|:---:|
| Arts | 253,840 | 16.24% | 0 |
| Society | 243,943 | 15.61% | 0 |
| Business | 240,177 | 15.37% | 0 |
| Computers | 117,962 | 7.55% | 0 |
| Science | 110,286 | 7.06% | 0 |
| Recreation | 106,586 | 6.82% | 0 |
| Sports | 101,328 | 6.48% | 0 |
| Shopping | 95,270 | 6.10% | 0 |
| Health | 60,097 | 3.85% | 0 |
| Reference | 58,247 | 3.73% | 0 |
| Games | 56,477 | 3.61% | 0 |
| Kids | 46,182 | 2.95% | 0 |
| **Adult** | **35,325** | **2.26%** | **1** |
| Home | 28,269 | 1.81% | 0 |
| News | 8,989 | 0.58% | 0 |

**Positive rate 2.26% (2.37% post-deduplication).** The corpus is severely
imbalanced. This confirms D-003: PR-AUC is the correct primary metric and
accuracy is actively misleading — a model predicting all-negative scores 97.7%.

### Two mapping caveats for the limitations chapter

1. **Definition mismatch.** `LABELING_POLICY.md` §1 defines Adult as "primary
   purpose is sexually explicit material." A directory's editorial Adult category
   need not coincide with that. The mapping is an assumption, not a measurement.
2. **Cross-category false negatives.** Explicit sites filed under Shopping or
   Society become label 0 and are silent errors in the ground truth. The §6 label
   audit must sample non-Adult categories, not only Adult.

Categories our policy explicitly excludes from Adult — Health, Society, Kids —
already map to 0, which agrees with the policy.

---

## 3. Validation results

| Check | Result |
|---|---|
| Rows read | 1,562,975 |
| Retained after URL normalisation | 1,561,931 |
| Dropped at load | 1,044 (0.07%) |
| — no registrable domain | 575 |
| — unsupported scheme (ftp/sherlock/gopher/telnet/news/irc) | 464 |
| — host without dot | 5 |
| Exact duplicate canonical URLs | 93,540 (5.99%) |
| **Retained after deduplication** | **1,468,243** |
| **Label conflicts (same URL, both labels)** | **148** |
| Unique registrable domains | 864,150 |

**The 148 label conflicts are direct, measured evidence of noise already present
in the source.** Both copies were dropped. This is a *lower bound* on the source
noise floor — it only catches disagreements on identical URLs — and it must be
reported alongside every injected-noise rate in RQ3. Injecting 20% noise into a
corpus with a non-zero intrinsic noise rate does not produce a 20% noise
condition.

**Status: PASS WITH FINDINGS.** No blocking condition.

---

## 4. Domain structure

| Property | Value |
|---|---|
| Unique registrable domains | 864,150 |
| URLs per domain | mean 1.70, median 1, p99 7, max 52,944 |
| Domains with a single URL | 803,661 (93.0%) |
| Largest single domain share | 3.61% (`geocities.com`, 53,959 URLs) |
| Domains containing ≥1 positive | 21,033 |
| Domains containing ≥1 negative | 843,874 |
| Domains containing **both** labels | 757 |

93% of domains contribute exactly one URL, so the domain-aware split is closer to
the random split here than it would be on a corpus with deep per-domain crawls.
It still matters — see §6.

**Note on grouping.** `include_psl_private_domains=False` collapses free-hosting
platforms into one group, so all 53,959 `geocities.com` URLs land in a single
partition. That is the conservative choice for leakage. It also means those
platforms host both classes under one group key, which is why 757 domains carry
both labels.

---

## 5. The corpus is old — this is the single most important limitation

| Evidence | Value | Interpretation |
|---|---:|---|
| HTTPS share | **0.068%** (1,055 of 1,562,978) | Today's web is predominantly HTTPS. A corpus this close to zero predates widespread TLS adoption. |
| `geocities.com` | 53,959 URLs | Service shut down in 2009 |
| `tripod.com` | 22,000 | Free-hosting era |
| `angelfire.com` | 20,845 | Free-hosting era |
| `freewebs.com` | 5,355 | Free-hosting era |
| `fortunecity.com` | 2,600 | Free-hosting era |

Roughly 6.7% of the corpus sits on free-hosting platforms characteristic of the
1996–2009 web, and HTTPS is effectively absent. I am confident the corpus
predates ~2010; I cannot date it precisely without provenance from the source.

### Consequences — these are not optional caveats

- **Every performance number is a statement about the pre-2010 web**, not the
  current one. Say this explicitly in the abstract, not only in limitations.
- **The browser extension PoC cannot be claimed to work on today's web.** A model
  trained here has never seen a modern URL structure. Report the extension as a
  deployability demonstration and make no accuracy claim for live browsing.
- **RQ8 (concept drift) changes status.** It was deferred for lack of timestamps
  (`RESEARCH.md` §0). The corpus age converts drift from "future work" into a
  *headline limitation of the present results*. If a modern URL sample can be
  obtained cheaply, even a few thousand hand-checked current URLs evaluated
  against the trained model would be a strong addition — measuring the drift
  penalty directly rather than deferring it.

---

## 6. Baseline result (E1, converged, 5 seeds)

Centralized logistic regression over hashed character 3-5-grams, 2^18 features,
lr=160, 35 epochs, batch 512, identical budget for both regimes. Selection on
validation; test evaluated once per seed. Convergence verified: validation
PR-AUC plateaus from ~epoch 30, and best epoch varies across seeds (30-35).

| Split regime | Test PR-AUC | sd | ROC-AUC | F1 | recall | FPR |
|---|---:|---:|---:|---:|---:|---:|
| Random | 0.7598 | 0.0034 | 0.9549 | 0.704 | 0.614 | 0.0031 |
| **Domain-aware (primary)** | **0.6145** | **0.0072** | 0.9248 | 0.551 | 0.413 | 0.0018 |

**sigma_c = 0.00718** (DECISIONS.md D-017). This is the unit in which every
hypothesis threshold in RESEARCH.md §2 is expressed.

### RQ1 answered

Random splits inflate PR-AUC by **0.1452 absolute, 23.6% relative, 20.2 sigma_c**
(paired t = 34.2, p = 4.4e-06 over 5 seeds; Wilcoxon p = 0.0625, the floor
attainable at n=5). Roughly a fifth of apparent performance in a randomly-split
URL classifier is domain memorisation rather than generalisation to unseen sites.

This holds despite 93% of domains contributing a single URL (§4). The effect is
carried by the minority of multi-URL domains - `geocities.com` alone is 53,959
URLs - which means the inflation is driven by a concentrated subset and a corpus
without large free-hosting blocks might show a smaller gap.

### Superseded figures - do not cite

An earlier run at lr=2 reported domain-aware 0.4850 and 35% inflation. That model
was under-trained (best epoch = 40 of 40 for all ten runs). Those numbers are
retained on disk as provenance (`E1_*_seeds.jsonl`) but must not be cited.
See D-017, D-018, D-019.

### Remaining caveat

Recall is 0.41 on the domain-aware split at threshold 0.5. That is a threshold
artefact at a 2.4% base rate, not a model failure, and is what the Phase 8
calibration and abstention work addresses.

## 7. Findings about the original repository

Recorded because they motivated design decisions, and because they are useful
prior work to discuss in the thesis.

1. **The training negatives were 100% Arts.** `load_data(balance=True)` selects
   the first `count_minority` negatives in file order. The CSV is sorted by
   category with Adult occupying rows 1–35,325, so the negative class drawn is
   entirely Arts. I reproduced this: 35,325 of 35,325 selected negatives are
   Arts. The reported accuracy 0.855 / F1 0.904 therefore describe an
   **Adult vs Arts** task, not Adult vs non-Adult.
2. **A destructive preprocessing chain exists but is not on the training path.**
   `remove_urls` applies `re.sub(r"https?://\S+", "", text)` to text that *is* a
   URL; on this corpus it reduces 99.98% of inputs to the empty string. It is
   configured in `data_loader.py`'s demo block and `readme.txt`, but `train.py`
   defaults to `--steps ["lower"]`, so the trained models were not affected. It
   remains a live landmine.
3. **Random split.** `random_split` over URLs allows the same domain in train and
   test — the effect quantified in §6.

None of this is unusual; all three are the kind of defect that motivates BAIZE's
validation gates, and all three were caught by those gates on first contact with
the data.

---

## 8. Outstanding before any reported result

1. Resolve **licence and provenance** with the source. Blocking for publication.
2. Run the **§6 label audit** (300 URLs, stratified, no site visits) to estimate
   the source noise floor above the 148-conflict lower bound.
3. σ_c is measured and frozen (D-017). `git_commit` is recorded by
   `baize.provenance.git_commit()` on new runs; existing E1 JSONL rows and
   some E2 files predate that, and later federated files are tagged `-DIRTY`.
4. Re-run H1 at equal `passes_per_example` before describing federation as
   "nearly free at matched budget" (D-026).
