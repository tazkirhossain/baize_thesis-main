# BAIZE — Privacy Model (Phase 0)

**Status:** DRAFT
**Central rule:** every privacy property is labelled `IMPLEMENTED`, `PLANNED`, or
`FUTURE WORK`. Nothing moves to `IMPLEMENTED` until it exists in code and is validated
by a test. The thesis may only claim what is `IMPLEMENTED`.

---

## 1. What BAIZE claims, and what it does not

### Claims it intends to make
- Raw browsing history is not transmitted to the central server by design.
- Inference runs locally in the browser; the URL being classified does not leave the
  device for classification purposes.
- Transmitted data is minimised to what the research objective requires.
- Where data is transmitted, its content, purpose, and retention are documented (§4).

### Claims it will NOT make
- ❌ "BAIZE guarantees privacy"
- ❌ "BAIZE is private because it uses federated learning"
- ❌ "Model updates contain no personal information"
- ❌ "Differentially private" — nothing in this thesis provides an ε
- ❌ "Secure aggregation protects clients from the server"
- ❌ "GDPR compliant" / "anonymised"

**Federated learning is not a privacy mechanism.** It is a data-locality architecture that
*reduces* centralisation of raw data. It provides no formal guarantee, and the literature
on gradient-based reconstruction shows that model updates can leak information about
training data. BAIZE's honest position: FL changes what is exposed, not whether anything
is exposed.

---

## 2. Status table

| Mechanism | Status | Notes |
|---|---|---|
| Local inference in browser | `PLANNED` (Week 6 PoC) | Demonstrable, not a guarantee |
| No raw-history upload | `PLANNED` | Architectural; verify by network-traffic test |
| URL field minimisation (§3) | `IMPLEMENTED` | Parser stores only scheme/host/path; query, fragment, userinfo, and port are scrubbed from `NormalizedURL.raw` and covered by `tests/test_pipeline.py::TestURLPrivacy`. Applies to the simulated pipeline, not to a browser extension. |
| Update norm clipping | `PLANNED` | Implemented for *robustness* (RQ4); has privacy side-benefits but is **not** DP |
| TLS in transit | `FUTURE WORK` | Simulation is single-process; no real network in this thesis |
| Secure aggregation | `FUTURE WORK` | Not implemented. Server sees individual updates. |
| Differential privacy (DP-SGD / DP-FedAvg) | `FUTURE WORK` | No ε will be reported |
| Privacy accountant | `FUTURE WORK` | — |
| Client anonymity / unlinkability | `FUTURE WORK` | Client IDs are pseudonymous integers in simulation only |

**All Tier 1 experiments run in single-process simulation on a public dataset.** No real
user data is collected at any point in this thesis. This substantially limits what
privacy claims are even meaningful, and that limitation should be stated up front rather
than glossed.

---

## 3. Data minimisation specification

If URL data is processed for feature extraction or ever transmitted, apply this
normalisation first. The rule is: keep what the classifier demonstrably needs, drop
everything else.

**Drop unconditionally:**
- Query string and fragment (`?...`, `#...`) — high risk of session tokens, search terms,
  email addresses, and personal identifiers
- Userinfo component (`user:password@`)
- Cookies, headers, referrer, and all browser state
- Timestamps at finer than day granularity
- Any user or device identifier
- Port, unless a feature study shows it carries signal

**Retain:**
- Scheme
- Registrable domain (eTLD+1), subdomain labels
- Path segments

**Open question for Phase 1:** the master spec (§18) lists query structure as a candidate
feature. Given the privacy cost, query-derived features should only be considered if a
feature-utility study shows a material gain, and even then only as structural statistics
(length, digit ratio, parameter count) rather than raw content. Default: exclude. If
excluded, say so and note the possible performance cost as a limitation.

---

## 4. Communication path audit

For the thesis's simulated system. A real deployment would require this table to be
re-derived and re-validated.

| Path | Data | Purpose | Sensitivity | Retention | Status |
|---|---|---|---|---|---|
| Browser → local model | Full URL, in memory | Inference | High | None — not persisted | `PLANNED` |
| Browser → local store | Normalised URL features, only if user opts into training | Local training | Medium | Local only, user-clearable | `FUTURE WORK` |
| Client → Server | Model parameter delta, sample count | Aggregation | **Non-zero — updates can leak** | Per-round, discarded after aggregation | Simulated |
| Server → Client | Global model parameters | Distribution | Low | Versioned | Simulated |
| Server → Evaluation | Global model, aggregate metrics | Evaluation | Low | Persisted | `PLANNED` |
| Evaluation → LLM | **Aggregate metric tables only** | Analysis | Low, *if enforced* | Prompt logs | Tier 2 |

**Hard rule on the LLM path:** no raw URLs, no per-client data, no user data is ever sent
to an external LLM API. Only aggregate numeric metric tables. If error analysis requires
example URLs, they come from the public dataset and are marked as such — and even then,
prefer paraphrased or structurally described examples over verbatim adult URLs in the
thesis text.

---

## 5. A concrete leakage concern worth stating

Character-level and n-gram URL models have sparse input representations. In a model with
an embedding or vocabulary layer, the gradient with respect to an embedding row is
non-zero only for tokens that actually appeared in the client's local batch. A server
observing a client's update can therefore learn something about **which character n-grams
or tokens that client's URLs contained** — without any sophisticated reconstruction
attack, simply by reading which rows moved.

I am confident about the mechanism (sparse gradients reveal token presence). I have not
verified experimentally how much is recoverable for this specific architecture and
setting, and the thesis should not assert a magnitude without measuring it. But this is
worth a paragraph, because it is a case where FL's data-locality argument is weakest and
it is specific to URL/text models rather than a generic hand-wave.

If there is time — and there probably is not — a small demonstration (does the update
reveal which domains a client held?) would be a strong addition. Log it as future work.

---

## 6. Consent and deployment note

The simulated system has no users and therefore no consent requirement. Any real
deployment of the browser extension would require, at minimum: explicit opt-in for
training participation separate from opt-in for the extension itself; a plain-language
data statement; a mechanism to withdraw and delete local data; and institutional ethics
review. None of this is implemented. It is documented here so the thesis's deployment
discussion is not naive.

---

## 7. Privacy validation tests (to write in Week 6, if the extension PoC is built)

- Network inspection: confirm no request contains a raw URL, query string, or cookie.
- Storage inspection: confirm nothing is persisted beyond declared local features.
- Log inspection: confirm no URL appears in any log at any level.
- Negative test: deliberately construct a URL with a fake token in the query string and
  assert it appears nowhere in transmitted or stored data.

If these tests are not written, the data-minimisation claim is `PLANNED`, not
`IMPLEMENTED`, and must be described that way.
