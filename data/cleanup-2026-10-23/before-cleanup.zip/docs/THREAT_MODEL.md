# BAIZE — Threat Model (Phase 0)

**Status:** DRAFT
**Purpose:** Define precisely what BAIZE defends against, what it does not, and under
what assumptions. No component may be described as "robust" without pointing to a
specific row in this document.

---

## 1. Three distinct dimensions — do not conflate

The master spec is right to insist on this separation. These are different threats with
different actors, different mechanisms, and different defences. Conflating them is the
most common error in this literature.

| Dimension | Space | Adversarial? | Actor | BAIZE's position |
|---|---|---|---|---|
| **A — Label noise** | Label space | No — accidental | Well-meaning client with wrong labels | Primary study (RQ3) |
| **B — Update poisoning** | Model / parameter space | Yes | Malicious federated client | Secondary study (RQ4, limited) |
| **C — URL evasion** | Input space | Yes | Adult-site operator evading a filter | **Out of scope**, deferred |

Robust aggregation is a defence against A and B. It does nothing about C. A result
showing trimmed mean helps under 30% label noise says nothing whatsoever about whether
the deployed classifier can be evaded.

---

## 2. System actors and trust assumptions

| Actor | Trusted? | Assumed capability |
|---|---|---|
| Federated client (honest) | Trusted to follow protocol | Holds local data, trains locally, sends updates |
| Federated client (noisy) | Follows protocol | Same, but a fraction of its labels are wrong; **not** trying to cause harm |
| Federated client (malicious) | Not trusted | Can send arbitrary parameter vectors; knows the model architecture |
| Central server | **Honest-but-curious — assumed** | Sees all updates; follows the protocol; may attempt inference from updates |
| Network adversary | Not trusted | Passive observation; TLS assumed |
| Site operator | Adversarial to the classifier | Controls own domain, subdomains, paths, queries |

**The honest-but-curious server assumption is load-bearing and is not defended against.**
BAIZE does not implement secure aggregation, so the server sees individual client updates
in the clear. This is stated in `PRIVACY.md` as a known, undefended exposure.

---

## 3. Dimension A — Label noise (in scope, primary)

**Not an attack.** Clients hold incorrect labels because labelling adult content is
genuinely ambiguous (see `LABELING_POLICY.md`), because automated labelling pipelines
err, or because the source corpus was noisy to begin with.

### Modelled noise processes
| Process | Description | Realism |
|---|---|---|
| Symmetric flipping | Each label flipped with probability p, independent of class | Least realistic; standard benchmark |
| Class-conditional | P(flip \| adult) ≠ P(flip \| non-adult) | More realistic — borderline non-adult sites are likelier to be mislabelled adult than the reverse |
| Client-heterogeneous | Different clients have different noise rates | Most realistic for federated setting |

### What is assumed
- Noise is **label-only**; features (URLs) are correct.
- Noise is applied independently per sample given the process.
- The clean test set is uncontaminated.
- The server's validation set is clean (see `RESEARCH.md` §4.3 — strong assumption).

### Known limitation
Real label noise is likely **instance-dependent** — mislabelling correlates with URL
ambiguity, not randomness. None of the three modelled processes captures this. State
this as a limitation; do not claim results generalise to instance-dependent noise.

---

## 4. Dimension B — Update poisoning (in scope, limited)

**Adversary goal:** degrade global model performance (untargeted).
**Adversary knowledge:** model architecture, current global parameters (distributed each
round), own local data.
**Adversary capability:** submit arbitrary parameter vectors. Controls a fraction f of
participating clients.

### Simulated attacks (Tier 1, minimal)
- **Sign flipping** — submit the negation of an honest update.
- **Scaled update** — submit an honest-direction update multiplied by a large constant.
- **Random / Gaussian noise update.**

These are cheap to implement and are the standard sanity checks that a robust aggregator
actually does something. They are not sophisticated adversaries.

### Explicitly out of scope
Backdoor / targeted poisoning, Sybil attacks (adversary creating many identities),
adaptive attacks tuned against the specific aggregator, model extraction, gradient
inversion attacks by the server, server compromise, model file tampering in distribution.

**Do not claim BAIZE resists any of these.** They are listed here so the thesis can state
what was not tested.

### Assumptions of each robust aggregator — state these when reporting

| Aggregator | Assumes | Fails when |
|---|---|---|
| Coordinate-wise median | < 50% of clients corrupted per coordinate; honest updates concentrated | Honest updates are multimodal (non-IID); majority corrupted |
| Trimmed mean (fraction β) | Corrupted fraction < β; β not so large it discards honest tails | β mis-specified; non-IID honest clients occupy the trimmed tails |
| Norm clipping / filtering | Malicious updates have anomalous norm | Attacker constrains its update norm to look normal |

The shared failure mode across all three is the one RQ5 targets: **under non-IID data, a
legitimate minority client is statistically indistinguishable from a corrupted one.**
Robust aggregation cannot tell "wrong" from "different." This should be stated as a
structural limitation, not discovered as a surprise.

---

## 5. Dimension C — URL evasion (deferred, but define it properly)

Deferred from this thesis. Documented here so the future-work section is concrete.

**Adversary:** an adult-site operator who wants the site reachable by its users but
misclassified by BAIZE.

**The validity constraint that makes this hard.** Arbitrary character perturbation of a
URL is trivial and meaningless — a mutated URL that no longer resolves is not an evasion,
it is a broken link. A valid adversarial URL must satisfy:

1. It resolves to the adversary's actual content.
2. The adversary can register or control it.
3. It remains discoverable by the intended audience (linkable, memorable, or reachable
   via search / referral).

Only transformations preserving all three count. That rules out most naive character-level
perturbations and admits: neutral or misleading domain registration, subdomain
proliferation, path obfuscation, encoding tricks, homoglyph domains, and content served
from generic hosting or CDN paths.

Note that constraint (1) means the strongest evasion — registering a completely innocuous
domain — is not an *attack on the model* at all. It is the fundamental ceiling of
URL-only classification: a URL string carries no guaranteed information about page
content. Any adversarial-robustness result must be framed against that ceiling.

**A thesis result generated by randomly perturbing characters and reporting a drop in
accuracy would be measuring noise sensitivity, not adversarial robustness.** This is
precisely why it is deferred rather than done cheaply.

---

## 6. Non-goals

BAIZE does not attempt to:
- Detect adult content from page content, images, or text — URL only.
- Provide a production-grade content filter.
- Defend the server against compromise.
- Defend against a malicious model distribution channel.
- Provide any formal security or privacy guarantee.

---

## 7. Claim discipline

Before writing "robust" in the thesis, complete this sentence:

> Robust against **[dimension A / B]**, under **[specific noise process or attack]**,
> at **[rate / fraction]**, assuming **[aggregator assumption from §4]**,
> as measured by **[metric]** in **[experiment ID]**.

If any bracket cannot be filled, the word "robust" does not go in the sentence.
