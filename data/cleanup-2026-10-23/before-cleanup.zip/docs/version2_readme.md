# Completed work and current project status

## Numerical classifier removal (23 October 2026)

The user removed the engineered-feature logistic classifiers. Their model,
numerical ensemble/fit helpers, local experiment runner and training CLI have
been deleted. `config/balancing/` now contains model-independent balancing settings
only. Active research models are Character CNN and DeBERTa-v3-base through
`scripts/federated.py`. Keep the existing legacy demo/simulator under `baize/`
separate; it was not part of this numerical-classifier removal.

Preserve immutable historical numerical reports and ignored reproduction
snapshots, and allow report exporters to read those completed results. They do
not represent a currently available classifier. SMOTE and train-only numerical
scaling remain reusable preprocessing utilities, with no numerical classifier
experiment runner. Never substitute SMOTE on CNN/DeBERTa tokens. Earlier sections
that describe the numerical training runner are historical and superseded here.

Verification after removal: **242 tests passed**, one opt-in network test
skipped and three existing localhost UI tests deselected. Retained neural
training/evaluation, partitioning, train-only balancing, SMOTE/scaling utilities
and historical report readers passed. Historical source-summary and final-report
SHA-256 hashes remain unchanged.


Updated: 23 October 2026 (Asia/Dhaka).

This is the handover record for work completed in this chat. It distinguishes
implemented preprocessing from existing legacy research code and future work.

Architectural preference saved on 18 October 2026: future work should follow
`docs/PROJECT_STRUCTURE.md` (`config/`, `src/data/`, model-named implementations,
Flower `src/client/` and `src/server/`, `src/evaluation/`, `scripts/`, `results/`,
`tests/`, and setup/reproduction instructions in `README.md`). The preference is
also recorded in `AGENTS.md` for future sessions. The existing repository has not
been reorganized merely to save this plan.

## Evaluation and reporting, 23 October 2026

Implemented a shared both-class confusion-count calculator with Adult and
Non-adult precision/recall/F1, macro-F1, balanced accuracy, confusion matrix,
overall accuracy, class supports and prevalence. Independent tests compare the
formulas with scikit-learn, including a 97.63%-accuracy majority-only case whose
Adult recall/F1 are zero. No accuracy-only or automatic best-method selection.

The Flower path now evaluates the updated global model locally on original
training and validation splits after each aggregation, with no optimization or
preprocessing fitting during evaluation. Balanced-view optimization loss remains
separate. Added client training/fit times, server phase/round wall times, coarse
device/thread metadata, and exact serialized Flower Fit/Evaluate protobuf payload
bytes in both directions. Payloads exclude gRPC/TLS/control/retry overhead;
optional final-test traffic is included in the last round. Raw URLs, labels and
predictions remain client-local. Primary original-training-count FedAvg is unchanged.

Added `scripts/report_evaluation.py`, `src/evaluation/reporting.py`, `plots.py`,
`classification.py`, `config/reporting/comparison.json` and a `reporting`
dependency extra (Matplotlib 3.10.3). Exports use JSON, Markdown tables, PNG/SVG,
exact configs, input/code hashes and runtime provenance. Comparison checks reject
incompatible contracts, policies and duplicate cells. Historical missing timing
stays null; negative-class metrics are derived from saved confusion matrices.
New numerical runs record separate training/evaluation timing without rewriting
historical 1:1 or 1:5 results.

Final report: **`results/evaluation_reporting_v4/`**. It contains all requested
comparison tables and six figures (12 PNG/SVG files): IID/non-IID, balancing under
IID, balancing under both non-IID scenarios, Adult recall/F1, FL convergence and
measured training/communication costs. There are **29 measured metric rows**:
24 real local-numerical validation/test groups plus five synthetic CNN training,
validation and final-test rows. Coverage explicitly marks real CNN/DeBERTa
experiments not measured, and unsupported neural SMOTE/multi-DeBERTa transport
not applicable. No winner is declared. The 74 numerical fit warnings are retained.

Synthetic source run: `data/federated-cnn-evaluation-v4/`, two rounds with the
actual user CNN and five clients, plus one optional final test evaluation. All
15 synthetic split hashes remain unchanged. No real URL dataset was read by the
report exporter or rewritten. Full-corpus neural performance is still unmeasured.

Validation: **248 regression tests passed; 1 opt-in network test skipped in that
run; 3 existing localhost UI tests deselected** under the sandbox restriction.
The five-client gRPC test passed separately. `verification.json` independently
checks all 29 rows against confusion counts and original source aggregation,
timing/byte accounting, unchanged numerical summary, source/image hashes,
PNG/SVG integrity and missing-neural coverage. All six final PNG figures were
visually inspected; SVG syntax was parsed. No browser/mobile or formal
accessibility certification is claimed. Audit: `data/verify_evaluation_reporting_v4.py`.

Also removed a stray leading `c` that prevented the DeBERTa module importing;
it was the only difference from its archived tested source. Architecture is unchanged.
Usage/definitions: `docs/EVALUATION_REPORTING.md`. README, project structure and
AGENTS.md now link the current reporting workflow and final export.

## Five-client Flower FedAvg, 23 October 2026

Added a separate Flower 1.22.0 neural federated path while preserving the legacy
linear simulator. The server distributes a common state, deterministically
samples 1-5 of the five clients without replacement, accepts compatible locally
trained states/statistics, aggregates them and collects local validation counts
from all five clients on the updated global model. Server modules have no client
dataset loader and do not receive URLs, raw labels, token IDs or predictions.

Primary FedAvg weights are ORIGINAL local training counts before balancing.
Both original/resampled counts and actual aggregation weights are logged.
Oversampling does not manufacture extra client ownership. An explicit secondary
resampled-count policy is available and recorded, without epoch/member inflation.
Floating BatchNorm buffers are weighted; integer counters retain global values.
Model schema, contract, global-state hashes, IDs and count consistency are checked;
failed, stale, duplicate or nonfinite updates fail the round instead of producing
a partial result. Validation uses summed confusion counts/loss sums; there is no
central validation dataset, automatic tuning or best-round selection.

Implemented fixed character encoding, DeBERTa batch/tokenizer integration and a
plain-SGD local trainer. Training-only under/oversampling reuse existing samplers;
a separate CNN ensemble aggregates aligned member states and averages member
probabilities. Standard SMOTE remains numerical-only. A multi-DeBERTa ensemble
is explicitly unsupported until chunked/member transport is implemented.
The fixed final model can optionally evaluate local test sets once, off by default.

Configs: `config/federated/character_cnn.json` and `deberta_v3_base.json`.
Configurable participation count, rounds, local epochs, batch size, learning
rate, seeds, balancing and threshold. CLI: `scripts/federated.py` with separate
`server`, `client`, `local`, `smoke` modes. The same local command accepts existing
IID, label-skew or category-skew roots. The network mode supports independently
running clients, loopback defaults and TLS requirements for remote addresses.
No Ray is required. Optional dependency extra: `federated` (plus `deberta` for
the transformer). Guide: `docs/FEDERATED_TRAINING.md`.

Verification completed:

- **239 regression tests passed, 1 opt-in network test skipped, 3 existing
  localhost UI tests deselected** because those sockets are sandbox-restricted.
  Fourteen of the passing tests cover the new Flower path, including a tiny
  actual DeBERTa encoder, reproducible sampling/updates, both weighting policies,
  under/oversampling/ensembles, untouched holdouts and rejected invalid payloads.
- The opt-in **real gRPC server/five-client test passed separately** with local
  network access. Its threaded test bypasses Flower's main-thread signal setup;
  the production CLI keeps Flower's normal signal handling.
- Actual user CNN smoke completed two Flower rounds: 10 local fits and 10
  validation calls, with all five clients in each round. The audited final run
  is `data/federated-cnn-smoke-v2/`: round reports, checkpoints, config, code and
  runtime snapshots. Independent `verification.json` confirms parameter hash
  chaining, final checkpoint/schema, equal training class counts, original-count
  weights, no test evaluation and unchanged hashes for all 15 synthetic splits.
  Audit source: `data/verify_federated_smoke_v2.py`.

These are synthetic implementation checks, not full-corpus neural accuracy
results. The complete pretrained DeBERTa files are still absent, and no real-data
neural FL study has run. Privacy is data minimization/local evaluation, not DP or
secure aggregation; the server sees per-client model updates/coarse statistics.
Existing real partitions, split files and earlier numerical results were not
rewritten or uploaded.

## DeBERTa-v3-base implementation, 23 October 2026

The user selected Microsoft's published DeBERTa-v3-base checkpoint. Replaced the
reserved file with a DebertaV2ForSequenceClassification-based binary classifier
in `src/models/deberta_v3_base/model.py`. It loads the official pretrained base
encoder, initializes the Adult/Non-adult head with an explicit seed and checks
for missing encoder weights. Offline loading is the default; no random-backbone
fallback or download runs on import. The published base uses DebertaV2's
implementation; it is not a substitute for DeBERTa-v3.

Added original SentencePiece tokenizer loading and explicit padding/truncation
with attention masks. The fixed vocabulary is never fitted on client data.
0=Non-adult and 1=Adult are shared across models. The classifier exposes logits
and optional unweighted cross-entropy loss. No SMOTE is applied to token IDs.

Pinned Hub revision `8ccc9b6f36199bec6961081d44eb72fb3f7353f3` and added
`config/models/deberta_v3_base.json` plus optional dependencies in the `deberta`
extra. The four local files needed are config.json, pytorch_model.bin, spm.model
and tokenizer_config.json in ignored `data/pretrained/deberta-v3-base/`.
TensorFlow and Rust weights are unnecessary. Full pretrained weights were not
downloaded; actual base-checkpoint loading and fine-tuning remain to be run.

Details, source links, offline usage and optional four-file download instructions
are in `docs/NEURAL_MODELS.md`. Numerical experiments, their results, client
partitions and original train/validation/test records remain unchanged. The new
head is untrained for Adult detection. Neural trainers and FL wiring are pending.

Validation: **10 tests passed** across both neural modules (6 DeBERTa and 4 CNN).
DeBERTa tests used a tiny actual DebertaV2 encoder with random test weights and
a local synthetic SentencePiece model: forward/backward, label mapping, masked
padding, checkpoint roundtrip, tokenizer truncation and missing/incompatible
file failures passed. Full-size pretrained loading was not exercised; these
checks are implementation verification, not real-data detection performance.

## Two separate neural model files, 22 October 2026

Added the user-supplied `CharacterLevelCNN` in
`src/models/character_cnn/model.py`, with package exports and an explicit
`CharacterCNNConfig`. The eight convolution blocks, four residual additions,
adaptive pooling, classifier dimensions/dropout and initialization follow the
supplied architecture. Input dropout now runs after the channel transpose so
Dropout1d acts on character channels. Input shape/type guards fail clearly.
The module accepts configuration explicitly instead of reading `config.json`
on import. Binary classification uses two logits with 0=Non-adult, 1=Adult.

Reserved `src/models/deberta_v3_base/model.py` separately, awaiting the user's
full architecture. Its factory raises NotImplementedError instead of returning
a substitute. Neither neural model has been trained on the corpus; a character
encoder, padding/truncation settings, neural trainer and FL wiring are pending.
Existing numerical models, results, client partitions and balancing data remain
unchanged. SMOTE continues to be restricted to numerical features.

Added optional `neural` dependency (`torch==2.8.0`) in `pyproject.toml`.
Usage and architecture details: `docs/NEURAL_MODELS.md`. Updated README,
project structure and saved model instructions in AGENTS.md.

Validation: **5 focused tests passed** under PyTorch 2.8.0+cpu, covering variable
length forward passes, deterministic evaluation, finite gradients through all
eight convolution blocks, channel-dropout layout, invalid inputs and the explicit
pending-DeBERTa failure. Tests used synthetic tensors only; no accuracy or
federated-training result is claimed.

## Equal-class correction, 21 October 2026

The user clarified that balancing means equal Adult and Non-adult counts.
All four `config/balancing/` presets and `BalanceConfig` now default to **1:1**.
Undersampling and every ensemble member retain all Adult examples and reduce
Non-adult examples to the same count. Oversampling duplicates Adult training
examples to the original Non-adult count. SMOTE reaches that count using
synthetic scaled numerical features only. No new genuine Adult URLs are created.
All operations remain client-local and training-only. Original partitions,
validation and test files remain immutable. The historical 1:5 run below is
preserved as a historical experiment rather than relabelled as equal balancing.

Focused validation: **32 balancing, experiment and metric tests passed**,
including a new check that all four shipped presets produce equal class counts.

## Completed equal-class run, 21 October 2026

Re-ran all four methods independently for all five clients in each of IID,
label-skew non-IID and category-skew non-IID: **60 successful method runs and
120 independently fitted numerical classifiers**. Every resulting training view
has equal Adult and Non-adult counts; all five members of each undersampling
ensemble satisfy the same equality. Oversampling and SMOTE retain the original
Non-adult count; undersampling and ensembles retain the original Adult count.

Example IID Client 1, originally 5,102 Adult / 206,064 Non-adult:

| Method | Adult | Non-adult | Added Adult examples |
|---|---:|---:|---|
| Random undersampling | 5,102 | 5,102 | None |
| Random oversampling | 206,064 | 206,064 | 200,962 duplicate selections |
| Numerical SMOTE | 206,064 | 206,064 | 200,962 synthetic feature vectors |
| Ensemble, each member | 5,102 | 5,102 | None |

The independent audit verified all 15 original client dataset hashes and all
45 train/validation/test file hashes, holdout class supports, training-only scaler
fits, exact duplicate/synthetic counts, and distinct ensemble seeds/selections.
Results are in `data/balancing-four-methods-equal-v2/summary.json`, `run.log`,
per-client reports and `verification.json`. The audit script is
`data/verify_balancing_equal_v2.py`. Sanitized evaluation metrics are in
`results/balancing_numerical_equal_v2.md` and `.json`.

These remain numerical-feature experiments, not DeBERTa, character CNN or a
federated aggregated model. There were **74 recorded ConvergenceWarnings** at
the unchanged 30-epoch cap. Equal class counts do not establish model quality;
no method or settings were selected or changed based on these holdout results.
The earlier 1:5 run remains intact. Focused verification: **32 tests passed**.

### Exact equal-class counts per client

Each cell below is the count **in each class**, not their combined total.
Undersampling ensemble counts apply separately to every member.

| Partition | Client | Undersampling / each ensemble member | Oversampling / SMOTE |
|---|---:|---:|---:|
| client-iid-v1 | 1 | 5,102 | 206,064 |
| client-iid-v1 | 2 | 4,972 | 206,277 |
| client-iid-v1 | 3 | 5,026 | 206,351 |
| client-iid-v1 | 4 | 5,011 | 206,978 |
| client-iid-v1 | 5 | 5,026 | 205,902 |
| client-label-skew-v1 | 1 | 8,679 | 202,551 |
| client-label-skew-v1 | 2 | 6,124 | 205,354 |
| client-label-skew-v1 | 3 | 4,701 | 206,643 |
| client-label-skew-v1 | 4 | 3,220 | 208,282 |
| client-label-skew-v1 | 5 | 2,413 | 208,742 |
| client-category-skew-v1 | 1 | 5,025 | 207,708 |
| client-category-skew-v1 | 2 | 5,016 | 207,630 |
| client-category-skew-v1 | 3 | 5,036 | 204,043 |
| client-category-skew-v1 | 4 | 5,032 | 208,928 |
| client-category-skew-v1 | 5 | 5,028 | 203,263 |

## Four original balancing methods, 19 October 2026

Implemented all four required methods locally on TRAINING ONLY. No class-weighted
loss or focal loss was substituted. All original partitions and all original
train/validation/test files remain immutable. Normal runs select one method
through `config/balancing/`; explicit comparison mode runs the methods separately
from the same original training data.

- Random undersampling retains all Adult training indices and selects Non-adult
  indices without replacement for the configured Adult:Non-adult ratio.
- Random oversampling retains every original training row and samples additional
  Adult training indices with replacement, logging the exact duplicate count.
- SMOTE uses only scaled engineered numerical URL features. The local scaler is
  fitted on original training records, then frozen for evaluation transforms.
  Standard minority-neighbor interpolation creates numerical vectors, never raw
  URLs, character IDs or DeBERTa tokenizer IDs. The configured neighbor count is
  checked against training minority support; adjustments/skips are explicit.
- The undersampling ensemble fits independent base models on independently
  sampled training subsets and averages Adult probabilities. Each member keeps
  every available Adult training example. Member seeds, selections, counts,
  fitting diagnostics and individual/ensemble metrics are recorded.

Implemented reusable modules under `src/data/`, `src/client/`, `src/models/` and
`src/evaluation/`. Row-index sampling and sequence-style dataset views are usable
by future DeBERTa-v3-base or character-CNN trainers. Their models were not trained
here. Neural ensembles must remain separately identified experiments. Current
runnable experiments use explicitly labelled engineered numerical features with
unweighted SGD logistic classifiers; logistic regression is also configurable.

Entry point: `scripts/run_balancing.py`. Four presets are in `config/balancing/`.
Each prints before/after counts, duplicates, synthetic examples, seeds and
evaluation metrics. With no `--methods` argument, ONLY the configured method
runs. `--methods all` explicitly compares the four original methods. Ratios 1:1
and 1:5 are supported (always Adult:Non-adult). See `docs/CLASS_BALANCING.md`.

Completed the declared real-data numerical comparison on all 15 clients across
IID, label skew and category skew: **60 method runs, 120 independently fitted
classifiers**, including 75 ensemble-member models. Settings were fixed before
evaluation: ratio 1:5, base seed 42 plus client storage ID, five ensemble members,
k=5, maximum 30 SGD epochs, threshold 0.5. No best method was preselected or
automatically selected from evaluation results.

Example, IID Client 1 training: originally Adult=5,102, Non-adult=206,064.
Undersampling uses 5,102 / 25,510; oversampling uses 41,213 / 206,064 (36,111
duplicates); SMOTE uses the same resulting counts (36,111 synthetic numerical
vectors); each of five ensemble members uses 5,102 / 25,510 independently.

All methods report Adult precision, recall, F1, confusion matrices, macro-F1,
balanced accuracy, overall accuracy and average precision on unchanged original
holdouts. Full count/metric output is in `data/balancing-four-methods-v1/run.log`;
all per-client results, transform statistics, parameters, runtime versions and
code snapshots are in that run's `summary.json` and client reports. Sanitized
aggregate comparisons are `results/balancing_numerical_comparison_v1.md` and
`.json`. They pool independent local predictions, not a global federated model.

Independent verification passed: all 15 original client datasets and all 45
original split files are unchanged; target, duplicate and synthetic counts match;
holdout class supports are preserved; member selections/seeds are distinct;
all transforms fit training only; archived code checksums match. The private
verification is `data/balancing-four-methods-v1/verification.json` (audit source:
`data/verify_balancing_runs.py`). Eleven fits reached the predeclared iteration
limit (ten ensemble members and one standalone undersampled model); warnings
are retained in reports. This is a single-seed initial numerical experiment,
not a robust winner declaration or DeBERTa/CNN performance result. No checkpoint,
raw record or dataset was uploaded or placed in versionable results.

Validation: **214 tests passed, 3 existing localhost HTTP tests deselected**.
Tests cover both 1:1 and 1:5 ratios, original-minority retention, duplication
accounting, repeatable seeds, holdout refusal, numerical-only SMOTE, adjusted or
skipped neighbor cases, training-only scaler statistics, independent ensembles,
probability averaging, fixed confusion-matrix metrics, single-method defaults,
CLI logging/no-overwrite and numerical-vs-neural model-family guards. The runtime
also emitted one benign CPU-core detection warning. Data/model results were not
changed in response to either runtime or convergence warnings.

## Client-local splits completed, 18 October 2026

IID was also confirmed locally split on all five clients. The existing IID split
files were preserved and rechecked: all 15 split-file hashes, all five owned-data
hashes, preprocessing configuration hashes, counts and minimum class coverage
match the prior full-record verification. The new check is saved at
`data/client-iid-v1/local_split_verification.json`. The prior cross-scenario
audit established identical global split membership and zero domain-role conflicts.

IID local counts:

| Client | Training | Validation | Test | Total |
|---|---:|---:|---:|---:|
| 1 | 211,166 | 38,987 | 43,495 | 293,648 |
| 2 | 211,249 | 39,109 | 43,290 | 293,648 |
| 3 | 211,377 | 38,992 | 43,280 | 293,649 |
| 4 | 211,989 | 38,460 | 43,200 | 293,649 |
| 5 | 210,928 | 39,092 | 43,629 | 293,649 |

Configured IID fractions are 70/15/15 under the same shared domain rule. Actual
global fractions are 71.9710%/13.2567%/14.7724%; domain grouping makes row quotas
approximate. IID totals match the non-IID split totals below. No repartitioning,
data replacement, balancing or model training was needed for this confirmation.

Ran `scripts/split_client.py` independently for every client in both non-IID
scenarios. Each invocation reads only that client's owned records and settings;
it does not require the central source, provisioning report or other clients.
Files are under each client's `splits/train.jsonl`, `splits/val.jsonl` and
`splits/test.jsonl`, alongside its local manifest and preprocessing configuration.

The configured fractions are **70% training, 15% validation, 15% test**. The
previously agreed shared domain rule remains unchanged: a domain receives the
same role on every client. Therefore these are probability targets over domains,
not exact row quotas. No domains were divided across roles to change the ratios.

Label-skew local counts:

| Client | Training | Validation | Test | Total |
|---|---:|---:|---:|---:|
| 1 | 211,230 | 39,032 | 43,387 | 293,649 |
| 2 | 211,478 | 38,919 | 43,252 | 293,649 |
| 3 | 211,344 | 38,922 | 43,383 | 293,649 |
| 4 | 211,502 | 38,521 | 43,625 | 293,648 |
| 5 | 211,155 | 39,246 | 43,247 | 293,648 |

Category-skew local counts:

| Client | Training | Validation | Test | Total |
|---|---:|---:|---:|---:|
| 1 | 212,733 | 35,792 | 45,124 | 293,649 |
| 2 | 212,646 | 39,027 | 41,976 | 293,649 |
| 3 | 209,079 | 41,838 | 42,732 | 293,649 |
| 4 | 213,960 | 36,165 | 43,523 | 293,648 |
| 5 | 208,291 | 41,818 | 43,539 | 293,648 |

Each scenario totals **1,056,709 train, 194,640 validation, 216,894 test**,
retaining all 1,468,243 records. Actual global row percentages are 71.9710%,
13.2567% and 14.7724%. Class/category counts and actual fractions per client
are recorded in local manifests and the split summary. No sampling ratios,
class weights, thresholds or model settings were tuned using these outcomes.
No training-set balancing or model training was performed.

Independent full-record verification passed for all 30 new split files and the
15 historical IID split files. Every client's three files reconstruct its owned
unsplit dataset byte-for-byte, with no duplicate source rows or missing records.
Actual class/category/domain counts, configuration/file hashes and minimum class
coverage match the manifests. Across all 864,157 domains there are **zero domain
role conflicts**. The global train/validation/test source-row memberships are
identical across label skew, category skew and historical IID; ownership differs.

Saved current checks in each non-IID root's `local_split_verification.json` and
the aggregate `results/client_local_split_summary_v1.json`. Historical
provisioning reports and their verification files were preserved. The private
audit source is `data/verify_non_iid_local_splits.py`. The audit also checked local
validation loading for Client 1 in each new scenario: label skew shape
(39,032, 65,536), category skew shape (35,792, 65,536), per-record L2 normalization
and protected evaluation labels. Features are still computed on demand after
splitting; no learned scaler was fitted.

## Earlier full-corpus independent non-IID scenarios, 18 October 2026

The exact user-specified label-skew targets were validated against the audited
source before generation: 34,811 Adult, 1,433,432 Non-adult, total 1,468,243.

| Human client | Adult | Non-adult | Total | Storage directory |
|---|---:|---:|---:|---|
| 1 | 12,000 | 281,649 | 293,649 | `client_000` |
| 2 | 8,500 | 285,149 | 293,649 | `client_001` |
| 3 | 6,500 | 287,149 | 293,649 | `client_002` |
| 4 | 4,500 | 289,148 | 293,648 | `client_003` |
| 5 | 3,311 | 290,337 | 293,648 | `client_004` |

Generated and independently verified **two separate** full-corpus outputs:

- Label skew: `config/five_client_label_skew.json` →
  `data/client-label-skew-v1/`. The default `five_client_non_iid.json` is now
  an exact alias of this initial label-skew scenario. Original Non-adult
  categories are randomly sampled within the binary pool, without a second
  category-skew control.
- Category skew: `config/five_client_category_skew.json` →
  `data/client-category-skew-v1/`. Adult counts are [6963,6962,6962,6962,6962];
  Non-adult counts are [286686,286687,286687,286686,286686]. Each binary margin
  and total size differs by at most one. A seed-0 category order fills equal
  Non-adult capacities using whole categories, splitting only at capacity
  boundaries. This creates strong original-category skew while controlling
  binary prevalence. The complete exact table is saved in the configuration.
- Optional Dirichlet preset remains separate as `five_client_dirichlet.json`.

Added `src/data/allocation_plans.py` and
`scripts/create_category_skew_config.py` for reproducible category-only plan
generation from eligible population counts. Added `src/data/verification.py`
and `scripts/verify_partitions.py` for independent full-record checks.

**Both full-corpus verification reports passed.** Each `verification.json`
confirms all 1,468,243 eligible records appear exactly once, canonical URLs are
unique, clients are disjoint, complete original record bytes (including IDs and
category text) are unchanged, reported counts match actual records, source audit
ledgers and archived code hashes match, and seed replay reproduces membership.
At the end of this provisioning stage, all ten scenario client datasets were
unsplit; the subsequent local splitting is recorded above. Balancing and
training remain separate stages. The source audit and existing
historical IID report/five dataset hashes remain unchanged.

Saved the aggregate preparation comparison at
`results/non_iid_partition_comparison_v1.json`. Its shared data/evaluation
contract check passed. This is a distribution comparison, not trained model
performance evidence. No new model training or model-quality claims were made.

The first label-skew publication hit a transient Windows rename lock. Added
bounded retry for Windows sharing/access errors at atomic publication, with no
overwrite or copying fallback; permanent errors still fail. The rerun published
successfully. Tests: **183 passed, 3 existing localhost HTTP tests deselected**.
All record-level outputs remain ignored local data; no GitHub upload occurred.
See `docs/NON_IID_PARTITIONING.md` for commands and full details.

## Earlier shared sampling rule and declared skew plans, 18 October 2026

Saved the user's required rule in `AGENTS.md` and `docs/PARTITION_SAMPLING.md`.
All implemented strategies now start with separate seeded shuffled Adult and
Non-adult pools and consume client quotas sequentially without replacement.
Category pools are filtered from those random binary pools. A shared guard
checks that the union contains every eligible original row exactly once.

Added `label_skew` and `category_skew` strategies accepting exact per-client
allocation plans. Plans must exhaust all eligible records; incorrect totals,
unknown categories, negative/non-integer counts and invalid plans fail instead
of being silently adjusted. No actual non-IID target counts were supplied, so
no full-corpus planned allocation was invented or generated.

Reports now record sampling-policy version and client order. The policy version
is included in preparation comparison contracts. Existing full-corpus IID data
and historical reports remain untouched; random memberships from the revised
sampler can differ for the same numeric seed. Replay older runs with archived
code, and use new output paths for future runs. Partitioning still produces
unsplit client datasets; local splitting and training-only balancing stay separate.

Verification for this revision: **165 tests passed, 3 existing localhost HTTP
tests deselected**. New tests check shuffled binary pools, sequential consumption,
exact label/category targets, fixed-seed replay, seed-dependent membership,
invalid plans and overlap/omission rejection. Both planned strategies were run
through the shared preparation engine on a synthetic corpus, retaining all IDs
and leaving client data unsplit. IID quotas additionally passed 200 randomized
balance/coverage scenarios under the revised sampler.

## Configurable partition strategies, 18 October 2026

Implemented the plug-and-play data-preparation foundation requested after IID:

- Common entry point: `scripts/partition_clients.py --config <preset>`.
- Presets: `config/five_client_iid.json` and `config/five_client_non_iid.json`.
- Strategy registry: `src/data/strategies.py`; shared audited output engine:
  `src/data/partitioning.py`. The original IID function and script remain usable.
- Non-IID: reproducible Dirichlet category/label skew with configurable positive
  alpha and allocation seed, no replacement, retries, dropped rows or balancing.
  Empty/single-class client allocations fail explicitly. Strong skew may also
  fail existing local split coverage requirements.
- Shared local splitting, loader, hashes and normalization for both strategies.
- New reports record a population fingerprint and data/evaluation comparison
  contract. `scripts/compare_partitions.py` checks matching contracts and exports
  aggregate distributions; it does not compare trained model quality.
- Full synthetic integration checks establish identical global train/validation/
  test populations across methods, despite different ownership. Existing full
  corpus IID outputs remain untouched. No full-corpus non-IID preparation or
  new training/model-performance comparison has been run in this revision.

See `docs/EXPERIMENT_CONFIGURATION.md` for customization, commands and future
stage-interface requirements. The saved architecture preference in `AGENTS.md`
now includes this configuration-first approach.

Validation: **152 tests passed, 3 existing HTTP tests deselected** because of
localhost restrictions. The first full attempt encountered transient Windows
file locks during snapshot publication; a fresh-directory rerun passed. The
existing full-corpus IID report and all five dataset hashes were rechecked and
remain unchanged. The synthetic comparison CLI also passed. Tests cover non-IID
coverage, repeatability, configurable skew, unchanged global evaluation pools,
shared feature loading, incompatible comparison contracts and no overwrite.

## Latest full-corpus baseline: five-client URL-level IID, 18 October 2026

The current IID output is **`data/client-iid-v1/`**, built from the unchanged
audited v3 cleaned source. Earlier outputs remain preserved. The user selected
URL-level IID with a shared domain split rule. Consequently the older
domain-exclusive allocation and exact local split counts below are historical.

Implemented `src/data/iid_partitioning.py`, `src/data/split_policy.py`,
`scripts/partition_iid.py` and `config/five_client_iid.json`. Every retained row
is assigned once without replacement using seeded binary/category permutations.
Allocation seed 0 gives the following exact counts:

| Client | Adult | Non-adult | Total | Train | Validation | Test |
|---|---:|---:|---:|---:|---:|---:|
| 0 | 6,962 | 286,686 | 293,648 | 211,166 | 38,987 | 43,495 |
| 1 | 6,962 | 286,686 | 293,648 | 211,249 | 39,109 | 43,290 |
| 2 | 6,962 | 286,687 | 293,649 | 211,377 | 38,992 | 43,280 |
| 3 | 6,963 | 286,686 | 293,649 | 211,989 | 38,460 | 43,200 |
| 4 | 6,962 | 286,687 | 293,649 | 210,928 | 39,092 | 43,629 |
| Total | 34,811 | 1,433,432 | 1,468,243 | 1,056,709 | 194,640 | 216,894 |

Total sizes, Adult/Non-adult counts and every normalized source-category count
differ by at most one between clients. The allocation report contains exact
per-client category counts. Original IDs, categories, URLs and the full cleaning
audit are preserved; no additional exclusion or balancing changes totals.

Each of five local split commands has completed. All clients use the same
SHA-256 domain role rule, with split seed 0. Domains may span clients but must
remain in one split role across the federation. The rule uses no labels or
evaluation results. Domain sizes make local 70/15/15 fractions approximate;
they are not exact row quotas. Local settings are checksum-bound to manifests.
Feature extraction remains stateless hashing plus per-record L2 normalization
after local splitting. No learned scaling or new model training was performed.

Verification: 136 tests passed, 3 existing localhost HTTP tests deselected due
to environment restrictions. Allocation quotas also passed 200 randomized
coverage/balance scenarios. See `docs/IID_PARTITIONING.md` for reproduction;
ignored local `report.json` and `cleaning_report.json` preserve allocation and
source audit details. Full-corpus independent verification passed and is saved
in `data/client-iid-v1/verification.json`. It checked every canonical URL,
source row and exact record byte against the cleaned source; verified all 15
split files, hashes and counts; and replayed the seed to reproduce membership.
There are 864,157 unique domains, including 53,398 present on multiple clients,
with **zero domain-role conflicts** across all clients and splits. Client 0's
validation feature matrix was (38,987, 65,536), with L2 normalization checked and
evaluation labels protected. The independent private check is reproducible with
`python data/verify_iid_run.py` while these local artifacts are available.

The corpus remains imbalanced. Similar distributions across clients do not
remove model bias; class weighting or sampling belongs in a future training-only
experiment. Existing training entry points still use the legacy simulation.

## Earlier audit hardening: 18 October 2026, schema v3

The audited clean source is **`data/client-datasets-v3/`**. Older `data/client-datasets/`
and `data/clients/` artifacts were preserved. Cleaned totals and client/split
assignments remain unchanged; record schemas and checksums changed to retain identity.

Completed in the latest revision:

- Preserve exact original `record_id` and `original_category` on retained records
  and exclusions; keep normalized `category` plus numeric `label` and explicit
  human-readable `target` (Adult / Non-adult). IDs/category text are not features.
- Validate required `id,url,label` schema, including reordered named headers and
  failure on missing/duplicate/extra named columns. The real headerless CSV was
  explicitly processed using `--header absent`. Reject blank IDs; do not assume
  IDs are globally unique. `source_row` uniquely identifies each source record.
- Independent missing counts: **id 0, url 3, label 0** in the uploaded corpus.
- A complete private `exclusions.jsonl`: **94,735 individual source records**,
  with original IDs/categories, primary and all applicable reasons. Duplicates
  reference the retained source row/ID; all 4,303 conflicting-label occurrences
  are represented individually. Invalid original URLs are not echoed.
- Audit report now distinguishes raw original category totals, accepted totals
  before deduplication, retained client/category/class totals, primary exclusion
  counts and potentially overlapping missing/secondary reason counts.
- Archive 36 source/configuration files with checksums and a source-tree fingerprint;
  record the actual installed runtime dependency closure in `runtime-requirements.txt`
  (24 entries for this run). This does not assert that a fresh installation has
  been tested or that the environment matches the original repository pins.
- Add direct `packaging==24.2` dependency for parsing installed dependency markers.
- Expand `.gitignore` for datasets/exports, client folders, model/checkpoint files,
  archives, credentials and private keys. Preserve narrow pre-existing aggregate
  metric JSONL exceptions, validated as numeric-only metric records by the guard.
- Add a read-only Git-index safety guard, including force-added ignored files,
  private-key headers, common credential-like tokens and large artifacts. Error
  output contains paths/reasons rather than secret values. CI runs the same guard.
- Latest tests: **127 passed, 3 deselected**; localhost HTTP tests remain excluded.
- Full real-data rebuild and all five separate local split commands completed.
  The independent `verification.json` records source-ID/category coverage,
  exclusion accounting, snapshot checksums and domain leakage checks.

Run the safety guard before committing/pushing in an actual Git checkout:

```powershell
python scripts/check_repository_safety.py
```

This exported checkout has no Git index, so the guard correctly reports
**NOT VERIFIED**, rather than PASS. Temporary synthetic Git-index tests passed,
including force-added dataset/credential scenarios. No dataset, credential or
artifact was uploaded to GitHub. Ignore rules do not erase prior remote history;
CI runs after a push and is not a substitute for the local guard. Pattern checks
cannot guarantee detection of every possible secret format.

Preprocessing still performs no resampling, class-weight estimation, threshold
selection or model training. The legacy training code's validation-based checkpoint
selection remains separate; it was not silently changed or rerun on the corpus.
Cold-environment reproduction, label correctness, FL training, enrichment and LLM
integration remain future work.

## 1. Thesis goal and agreed workflow

The current task is binary adult/non-adult URL classification using federated
learning. The other 14 source categories map to non-adult, while their category
names are retained for auditing. We have not changed the task to 15-class prediction.

The agreed order is:

```text
Global offline cleaning and deduplication
  -> allocate unique, unsplit datasets to clients
  -> each client splits only its own data into train/validation/test
  -> each client extracts features and normalizes them after splitting
  -> future: local training, global model aggregation and local evaluation
```

The actual run uses FIVE clients, seed 0, and 70/15/15 target split fractions.
The earlier 600,000-record / six-client / 100,000-per-client discussion was an
illustration. The actual corpus was not reduced to 600,000 records.

## 2. Uploaded dataset located and placed correctly

The uploaded file was found at `baize/data/url.csv` and moved to:

```text
D:/baize_thesis-main/baize_thesis-main/data/raw/url.csv
```

The move was verified by SHA-256; the file contents were unchanged.

- File size: 82,721,050 bytes.
- Format: headerless CSV, three fields: `id,url,label`.
- Original rows: 1,562,978.
- Original Adult category records: 35,325, before URL validation/deduplication.
- Three original records had a missing URL.
- No submitted URL or website was fetched.
- `/data/` is excluded from Git by the existing `.gitignore`.

Source SHA-256:

```text
79e32aeafc74a5c875add374d1ea5d163f867ee9109a47907c99271bb76002a4
```

The repository documents unknown dataset licence/provenance and an outstanding
label audit. Cleaning does not resolve those issues or prove that labels are correct.

## 3. Preprocessing implemented

- Strict CSV row accounting: every input record is retained, rejected, counted as
  a duplicate, or counted among excluded conflicting-label occurrences.
- Reject malformed columns, missing URLs, invalid URLs and unsupported schemes.
- Separate missing labels and unknown categories into quarantine; never infer
  their labels or silently turn them into non-adult records.
- Normalize URLs offline; retain minimized host/path evidence and strip query,
  fragment, credentials and ports. Reject oversized URLs and embedded controls.
- Fix credential scrubbing for malformed URLs with multiple `@` characters.
- Strictly validate binary labels before conversion: reject fractional labels,
  out-of-range values, invalid dataset objects and mismatched URL/label lengths.
- Globally deduplicate canonical URLs and exclude all occurrences of conflicting
  binary labels. Same-label duplicates preserve the first source row/category.
- Assign each registrable domain to only one client. Each client then assigns
  its own whole domains to only one local split. No retained URL/domain overlaps
  across clients or train/validation/test partitions.
- Require both classes in each local split; the actual CLI configuration requires
  at least 10 records of each class per split.
- Add both-class checking to the legacy split integrity gate and revalidation
  after legacy deduplication. Move invalid configuration checks before training.
- Seeded allocation, source/file checksums, class/category counts, environment
  records, immutable source data and refusal to overwrite existing outputs.
- Atomic publication: failed preparation/splitting does not publish partial data.
- Disable tldextract disk caching and use equivalent domain/suffix extraction
  compatible with the available older offline tldextract installation.

Whole-domain isolation takes priority over exact record counts, so allocations
and local fractions are targets rather than unconditional exact-size guarantees.
The present allocation is very close to those targets.

## 4. Exact cleaned dataset counts

| Binary group | Retained records |
|---|---:|
| Adult | 34,811 |
| Non-adult | 1,433,432 |
| **Total** | **1,468,243** |

Adult records are approximately 2.37% of the cleaned corpus. All valid unique
labelled records were retained: no class balancing, undersampling, oversampling
or LLM-generated labels were applied.

Source-row accounting:

| Outcome | Source records |
|---|---:|
| Retained | 1,468,243 |
| Missing or invalid records rejected | 1,047 |
| Repeated records removed from non-conflicting URLs | 89,385 |
| All records belonging to conflicting-label URLs | 4,303 |
| **Original total** | **1,562,978** |

The 4,303 excluded conflicting-label records belong to 148 distinct canonical URLs.
They include repeated occurrences, so do not add those occurrences again to the
89,385 duplicate count. The categories below use the retained first category for
same-binary-label duplicates; the raw source category totals differ.

### Cleaned counts by original category

| Source category | Binary group | Retained records |
|---|---|---:|
| Adult | Adult | 34,811 |
| Arts | Non-adult | 237,804 |
| Business | Non-adult | 235,405 |
| Computers | Non-adult | 111,101 |
| Games | Non-adult | 52,546 |
| Health | Non-adult | 58,023 |
| Home | Non-adult | 26,886 |
| Kids | Non-adult | 37,077 |
| News | Non-adult | 8,373 |
| Recreation | Non-adult | 102,423 |
| Reference | Non-adult | 53,654 |
| Science | Non-adult | 97,763 |
| Shopping | Non-adult | 93,233 |
| Society | Non-adult | 226,372 |
| Sports | Non-adult | 92,772 |
| **Total** | | **1,468,243** |

## 5. Distribution and client-local splits completed

| Client | Adult | Non-adult | Total owned | Train | Validation | Test |
|---|---:|---:|---:|---:|---:|---:|
| 0 | 6,963 | 286,687 | 293,650 | 205,555 | 44,048 | 44,047 |
| 1 | 6,962 | 286,687 | 293,649 | 205,555 | 44,047 | 44,047 |
| 2 | 6,962 | 286,686 | 293,648 | 205,554 | 44,047 | 44,047 |
| 3 | 6,962 | 286,686 | 293,648 | 205,554 | 44,047 | 44,047 |
| 4 | 6,962 | 286,686 | 293,648 | 205,554 | 44,047 | 44,047 |

Across all clients:

| Split | Adult | Non-adult | Total |
|---|---:|---:|---:|
| train | 24,370 | 1,003,402 | 1,027,772 |
| val | 5,221 | 215,015 | 220,236 |
| test | 5,220 | 215,015 | 220,235 |

Exact local class counts:

| Client | Local split | Adult | Non-adult | Total |
|---|---|---:|---:|---:|
| 0 | train | 4,874 | 200,681 | 205,555 |
| 0 | val | 1,045 | 43,003 | 44,048 |
| 0 | test | 1,044 | 43,003 | 44,047 |
| 1 | train | 4,874 | 200,681 | 205,555 |
| 1 | val | 1,044 | 43,003 | 44,047 |
| 1 | test | 1,044 | 43,003 | 44,047 |
| 2 | train | 4,874 | 200,680 | 205,554 |
| 2 | val | 1,044 | 43,003 | 44,047 |
| 2 | test | 1,044 | 43,003 | 44,047 |
| 3 | train | 4,874 | 200,680 | 205,554 |
| 3 | val | 1,044 | 43,003 | 44,047 |
| 3 | test | 1,044 | 43,003 | 44,047 |
| 4 | train | 4,874 | 200,680 | 205,554 |
| 4 | val | 1,044 | 43,003 | 44,047 |
| 4 | test | 1,044 | 43,003 | 44,047 |

Global allocation creates an unsplit `data.jsonl` for each client. Each client's
split command was subsequently executed separately. The root report and original
client manifest still say `allocated_unsplit` because they describe provisioning;
the completed local `splits/manifest.json` says `split_locally`.

## 6. Active output layout

```text
data/
  raw/url.csv
  client-datasets-v3/              ACTIVE two-stage workflow
    preprocessing.json            shared rules, features and default split policy
    report.json                   global provisioning counts and provenance
    quarantine.jsonl              invalid/unlabelled/conflicting records
    exclusions.jsonl              every excluded source row and all reasons
    runtime-requirements.txt       installed dependency closure
    code_snapshot/                 exact preparation sources and checksums
    verification.json              independent source-identity/leakage verification
    client_000/
      data.jsonl                  unique cleaned, unsplit client-owned records
      manifest.json               allocation counts and dataset checksum
      preprocessing.json          client's own copy of shared settings
      splits/
        train.jsonl
        val.jsonl
        test.jsonl
        manifest.json             local counts and checksums
        preprocessing.json
    client_001/ ... client_004/
  client-datasets/                previous v2 two-stage output, preserved
  clients/                        older centrally presplit output, preserved
```

Use `data/client-datasets-v3/` for the current workflow. `data/clients/` is a previous
verified allocation, not the current command's output. Raw data and generated
artifacts are local files; they are not committed by this work.

Global preparation is offline simulation setup. The training server does not
need these raw records, client files or quarantine. Separate client storage or
OS/process permissions will be needed for actual access isolation; allocating
folders on one computer does not itself enforce a security boundary.

## 7. Feature encoding and scaling

The current feature branch uses host/path character 3-5-gram hashing:

- 65,536 features in the actual preprocessing configuration.
- Shared `char_wb` analyzer and lowercasing on every client.
- Non-negative hashed features, with per-record L2 normalization.
- Features are computed when a client loads an already-created local split.
- No fitted vocabulary, mean, variance or min/max is learned from the corpus.
- Consequently no evaluation statistics are used for this normalization.
- Validation/test labels are read-only and protected against artificial noise injection.
- CSV ID, source row position and original category are audit fields, not predictors.

StandardScaler and MinMaxScaler have NOT been implemented for a numeric metadata
branch. If numeric features are added, learn any required imputer/scaler from
training records only, freeze it for validation/test, and preserve compatible
feature coordinates across clients before averaging model parameters.

## 8. Files added or changed during this work

| File | Purpose |
|---|---|
| `baize/data/preprocessing.py` | Global cleaning/allocation, local splitting and client feature loaders |
| `scripts/prepare_clients.py` | Global preparation CLI; outputs unsplit client datasets |
| `scripts/split_client.py` | One-client-only split command |
| `scripts/check_repository_safety.py` | Read-only tracked-file and common credential-pattern guard |
| `tests/test_repository_safety.py` | Force-added sensitive files, source-file exceptions and token/key detection tests |
| `.github/workflows/repository-safety.yml` | Run the repository safety guard for pushes and pull requests |
| `.gitignore` | Expanded data, export, checkpoint and credential exclusions |
| `tests/test_preprocessing.py` | Integrity, isolation, determinism, label, checksum and failure-path tests |
| `baize/data/url.py` | Credential scrubbing, input checks and offline extractor compatibility |
| `baize/data/dataset.py` | Strict binary labels, length validation and dataset invariants |
| `baize/data/splits.py` | Reject single-class partitions |
| `baize/experiments/runner.py` | Revalidate deduplicated data and validate configuration earlier |
| `docs/PREPROCESSING.md` | Detailed current workflow and usage |
| `README.md` | Links and commands for the new two-stage preparation workflow |
| `docs/version2_readme.md` | This completed-work and handover record |

These paths are relative to `D:/baize_thesis-main/baize_thesis-main/`.

## 9. Commands and client-side use

Run commands from the project root. The available working environment for the
completed runs was `C:/Users/hossa/anaconda3/python.exe`. The plain `python`
command points to a different environment lacking the required test/runtime packages.

Do not rerun preparation into the existing output: it deliberately refuses to
overwrite. For a new allocation, choose a new output directory:

```powershell
& 'C:/Users/hossa/anaconda3/python.exe' scripts/prepare_clients.py --clients 5 --seed 0 --output data/new-client-datasets
```

On each client, supply only its own allocated directory. For example:

```powershell
& 'C:/Users/hossa/anaconda3/python.exe' scripts/split_client.py --client-dir data/new-client-datasets/client_000
```

Repeat on the other client owners with their local directory. Existing `splits/`
outputs are also protected against overwrite. All five current local splits have
already been created; no rerun is needed to use them.

Load features locally after splitting:

```python
from baize.data.preprocessing import load_local_split

client_dir = 'data/client-datasets-v3/client_000'
X_train, y_train = load_local_split(client_dir, 'train')
X_val, y_val = load_local_split(client_dir, 'val')
X_test, y_test = load_local_split(client_dir, 'test')
```

The local splitter/loader needs no other client's files or the original CSV.
Feature matrices are computed on demand; persistent feature-matrix caching was
not added.

## 10. Verification completed

- Latest relevant suite: **127 passed, 3 deselected**.
- The three excluded existing HTTP tests need localhost connections blocked by
  this environment. The full suite therefore has not been confirmed passing.
- The synthetic centralized + FedAvg smoke run passed after the first round of
  preprocessing hardening. It exercises legacy training, not the new local FL loop.
- All 1,468,243 written records were independently checked in the first allocation:
  15 split files verified, with zero cross-client/cross-split domain overlap.
- The revised workflow was run against the full real CSV, creating five unsplit
  datasets and then executing each client's split command separately.
- Checksums of all five unsplit datasets and all 15 revised local split files
  were verified. Their URL/label/domain content and split assignments match v2; the JSONL checksums
  differ because v3 also preserves IDs and original category text.
- An isolated-client test confirmed local splitting/loading works without the
  root provisioning files, source CSV or other clients' data.
- Real Client 0 validation feature loading succeeded: shape (44,048, 65,536),
  L2 normalization checked and labels protected.
- The original CSV checksum was preserved.

Reproducibility limits: these runs used the available Anaconda dependency versions,
not the versions pinned in `requirements.txt`. The output report records Python
3.13.5, NumPy 2.2.3, SciPy 1.15.3, scikit-learn 1.7.0 and tldextract 5.1.2.
The checkout has no Git metadata; the report explicitly records `NO_GIT_REPO`.
Network restrictions previously prevented installing the pinned dependencies.

## 11. Remaining work: not completed by this preprocessing stage

1. Integrate the new client datasets/loaders with a client-owned FL training loop.
   Existing `run_experiment`, `scripts/prepare_cache.py` and result-reproduction
   scripts still use the legacy centrally prepared simulation.
2. Implement client-side validation/test evaluation and appropriate aggregation
   of metrics without collecting raw evaluation records at the training server.
3. Extend the four original training-only balancing methods across repeated seeds
   and future neural models, and integrate them with client-owned FL training.
   Preserve the unbalanced baseline. Class-weighted/focal loss do not replace
   the four methods. FedAvg client-size weights are not class-balancing methods.
4. Add bounded sitemap.xml, robots.txt and metadata acquisition/parsing with
   timestamps, missing-evidence states and an updated collection protocol.
5. Add auditable LLM training-label suggestions/noise review. Preserve original
   labels and evidence, and keep evaluation labels independently reviewed.
6. Add advisory LLM model-quality summaries grounded in measured metrics.
   No LLM calls or automatic approval of model quality have been implemented.
7. Complete the label audit and resolve dataset licence/provenance. Preprocessing
   integrity does not demonstrate correct labels or modern-web generalization.
8. Review and fix outstanding earlier audit issues: checkpoint resume does not
   validate the original experiment configuration; cached demo models can override
   `--force-synthetic`; non-object JSON bodies can crash the demo request handler.
9. Establish deployable client storage/access isolation and verify a fresh
   environment using the saved runtime dependency lock. Formal differential privacy/secure aggregation were not added.

At that earlier preprocessing stage, no new full-corpus training, model-quality
result, deployment or publication was performed. The subsequent numerical balancing
experiments are recorded above. Existing committed experiment results predate these changes
and must not be described as results of the new client-local workflow.
