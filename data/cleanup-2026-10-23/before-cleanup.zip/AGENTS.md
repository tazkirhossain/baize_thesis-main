# AGENTS.md

## Numerical classifier removal (23 October 2026)

The user removed the engineered-feature logistic classifiers. Their model,
numerical ensemble/fit helpers, local experiment runner and training CLI have
been deleted. `config/balancing/` now contains model-independent balancing settings
only. Active research models are Character CNN and DeBERTa-v3-base through
`scripts/federated.py`. Keep the existing legacy demo/simulator under `baize/`
separate; it was not part of this numerical-classifier removal.

Preserve immutable historical numerical reports and ignored reproduction
snapshots, and allow report exporters to read those completed results. They do
not represent a currently available classifier. SMOTE and train-only numerical
scaling remain reusable preprocessing utilities, with no numerical classifier
experiment runner. Never substitute SMOTE on CNN/DeBERTa tokens. Earlier sections
that describe the numerical training runner are historical and superseded here.


## Evaluation and reporting (23 October 2026)

Read `docs/EVALUATION_REPORTING.md`. Report both classes' precision/recall/F1,
macro-F1, balanced accuracy, confusion matrices, overall accuracy and class
supports/prevalence. Never use accuracy alone or automatically declare a winner.
The shared confusion-count calculator is `src/evaluation/classification.py`.
After each FL aggregation, default evaluation covers original local training
and validation data on all five clients, distinct from balanced-view optimization
loss. Keep local timing and exact serialized Flower payload accounting explicit;
missing historical measurements are null, not zero or reconstructed estimates.
Use `scripts/report_evaluation.py` for JSON/Markdown/PNG/SVG exports with source,
config and runtime metadata. Separate model families, local/FL, real/synthetic,
seeds and weighting policies; reject incompatible or duplicate comparison cells.
Neural real-data results remain unmeasured. Current final aggregate export is
`results/evaluation_reporting_v4/`; source summaries and partitions are immutable.

## Five-client neural Flower path (23 October 2026)

Read `docs/FEDERATED_TRAINING.md`. Preserve the legacy linear simulator; the new
path uses Flower 1.22.0 with `scripts/federated.py` server/client/local/smoke modes.
Server modules must never load client data. Client endpoints own URL encoding,
training-only balancing and local validation/test; only model tensors and agreed
aggregate scalars cross the API. Use ORIGINAL local training counts for primary
FedAvg weights; resampled weighting is a separately declared experiment, never
silently mixed. All five clients validate the updated global model each round.
No central validation set, holdout-driven tuning or automatic best-round choice.
Optional test evaluation happens once at the fixed final round. Preserve exact
shared model/schema/config checks, deterministic sampling and fail-closed rounds.
Neural methods: under/oversampling, none, separate CNN ensemble. SMOTE stays
numerical only; multi-DeBERTa transport is not implemented. Store checkpoints and
run snapshots only under ignored data/. The localhost network test is opt-in.

## Two neural model files (updated 23 October 2026)

Read `docs/NEURAL_MODELS.md`. The user supplied the character CNN architecture;
maintain it in `src/models/character_cnn/model.py`. On 23 October the user selected
Microsoft's published DeBERTa-v3-base checkpoint. Its binary classifier and
original SentencePiece tokenizer loading helpers are implemented separately in
`src/models/deberta_v3_base/model.py` using the official DebertaV2 implementation.
Use the pinned revision, shared 0=Non-adult/1=Adult labels and ignored local
checkpoint storage. Pretrained loading defaults to offline; never substitute a
random encoder when files are missing. The Adult classifier head needs training.
CNN encoding and the Flower neural trainer are implemented; full-corpus studies
are pending. DeBERTa full-checkpoint loading/fine-tuning requires its model files.
Keep historical numerical
experiments separate and preserve training-only balancing constraints. CNN input
is floating character features, not hashed features or SMOTE token sequences.

## Equal-class balancing correction (21 October 2026)

All four balancing presets and the API default must use Adult:Non-adult **1:1**.
Random undersampling and each ensemble member reduce Non-adult to Adult counts;
oversampling and numerical SMOTE increase Adult to Non-adult counts. Preserve
historical 1:5 reports. Apply only to training; keep holdouts unchanged.

## Original balancing methods (19 October 2026)

Read `docs/CLASS_BALANCING.md`. The required methods are undersampling,
oversampling, numerical-feature SMOTE, and independent undersampling ensembles.
Do not replace them with class-weighted or focal loss. Apply balancing only to
the client's existing training split; keep all source partitions and holdouts
immutable. Normal runs select ONE method through `config/balancing/`; explicit
comparison runs evaluate methods independently from the same original training
data. Preserve printed/saved counts, seeds, duplicate/synthetic counts and metrics.
Row-index samplers must remain reusable with future DeBERTa-v3-base and character
CNN datasets. SMOTE is restricted to scaled engineered numerical URL features,
never raw strings or tokens. Numerical models/ensembles must be identified
separately from neural-model experiments. No best method is preselected.

## User-agreed project structure (18 October 2026)

Read `docs/PROJECT_STRUCTURE.md` before adding or reorganizing project code.
The agreed target is `config/`, ignored `data/`, `src/data/`, `src/models/`,
`src/client/` (Flower clients), `src/server/` (Flower server/aggregation),
`src/evaluation/`, `scripts/`, `results/`, `tests/`, and `README.md`.
Give each model a descriptive model-specific module/directory when adding models.
Adapt the existing repository incrementally; preserve working imports, entry
points, tests, historical results and reproducibility artifacts during migration.
This is a saved architectural preference, not a claim that the migration or
Flower implementation has already been completed. Current code still lives in
`baize/`, with new IID data modules in `src/data/` and historical metrics in
`experiments/results/`.

Maintain the agreed workflow: global offline cleaning/deduplication, unique
client allocation, client-local train/validation/test splitting, then local
feature extraction/normalization. For the five-client IID baseline the user
explicitly selected URL-level sampling: domains may span clients but must use
the same shared train/validation/test role everywhere. See
`docs/IID_PARTITIONING.md`. The audited clean source is
`data/client-datasets-v3/`; the IID output is `data/client-iid-v1/`.
All five existing IID clients have verified local train/validation/test files
using the shared 70/15/15 domain-role policy. Their actual row counts are
approximate; see `data/client-iid-v1/local_split_verification.json` and the tables
in `docs/version2_readme.md`. Reuse existing verified splits without overwriting.
Keep raw records, IDs, private exclusions, credentials,
checkpoints and other sensitive artifacts out of version control. Only sanitized
aggregate metrics/plots belong in versionable results.

## Configurable experiment preference (18 October 2026)

The user wants plug-and-play experiment stages: choose methods with configuration
instead of modifying training code or duplicating pipelines. Read
`docs/EXPERIMENT_CONFIGURATION.md`. Data partitioning now has IID and configurable
Dirichlet non-IID strategies via `scripts/partition_clients.py`. Preserve the
common artifacts and client-local loader. Future model, balancing, aggregation
and LLM stages should follow this interface/configuration pattern. Record exact
run settings and separate outputs. Compare under matching data/evaluation rules;
do not claim performance comparisons from partition distributions alone.

## Required record assignment policy (18 October 2026)

For every strategy, first independently shuffle eligible Adult and Non-adult
record pools with the fixed allocation seed. Assign the first client's required
counts from those random pools, remove selected records from availability and
continue sequentially through five clients. Sequential consumption of a random
permutation implements random sampling without replacement. Never reuse or drop
records; verify the complete union equals every eligible original row exactly
once. IID uses proportional binary quotas, with category stratification where
practical. Label-skew uses declared per-client Adult/Non-adult target counts;
category-skew uses declared category quotas and randomly samples within original
categories. Reject inconsistent plans instead of adjusting totals. Keep client
assignment, client-local splitting and training-only balancing separate. Human
Clients 1–5 map to existing storage IDs 0–4. See `docs/PARTITION_SAMPLING.md`.

## Independent non-IID scenarios (18 October 2026)

Initial non-IID experiment is label skew with exact user targets in
`config/five_client_label_skew.json`; `five_client_non_iid.json` is its alias.
Keep category skew as a separate configuration/output, with balanced binary
counts to isolate the original-category effect. See `docs/NON_IID_PARTITIONING.md`.
Do not mix both skew controls in the initial experiment. Dirichlet remains a
separate optional preset. Prepare unsplit client data; local splitting and
training-only balancing remain independent stages.
Both full-corpus non-IID outputs have been generated and verified:
`data/client-label-skew-v1/` and `data/client-category-skew-v1/`. Each has five
client datasets, exact record coverage and its own provisioning verification report.
Each client has now independently created local `splits/train.jsonl`, `val.jsonl`
and `test.jsonl` using the shared domain rule and configured 70/15/15 fractions.
Fractions are approximate at row level; preserve domains in one shared role.
Current split verification is recorded separately in `local_split_verification.json`;
do not rewrite historical provisioning manifests or their verification reports.
Historical IID outputs remain unchanged. Do not claim trained-model comparisons
from the aggregate preparation report in `results/`.

## Cursor Cloud specific instructions

BAIZE is a self-contained Python (3.12) research project for privacy-conscious
adult-URL detection under federated learning with noisy labels. There are no
external services, databases, or network dependencies to run the tests or the
demo pipeline.

### Environment

- The system Python is externally managed (PEP 668), so dependencies live in a
  local virtualenv at `.venv/` (created by the startup update script). Use
  `.venv/bin/python` / `.venv/bin/pytest`, or `source .venv/bin/activate`.
- Run everything from the repository root. `conftest.py` inserts the repo root
  onto `sys.path`, so `baize` imports resolve without an editable install.

### Test / run

- Tests (82 cases): `.venv/bin/python -m pytest tests/ -q`. Coverage emphasizes
  the leakage/noise/validation gates rather than model quality. Frontend tests
  cover inference privacy (query/userinfo never returned) and the local HTTP API.
- End-to-end demo (the runnable "application"): `.venv/bin/python scripts/smoke.py`.
  This runs the full pipeline (centralized + FedAvg) on generated synthetic data
  and prints split reports, metrics, and provenance. It needs no external data.
- Local visualisation UI: `.venv/bin/python scripts/serve.py --force-synthetic`
  then open `http://127.0.0.1:8765/`. Stdlib `http.server` only; the submitted
  URL is classified from host+path and is never fetched. If `data/raw/url.csv`
  exists, omit `--force-synthetic` to train a cached corpus-sample model under
  `data/models/` (gitignored).
- There is no configured linter (no ruff/flake8/pylint/pre-commit); the defined
  workflows are pytest, `scripts/smoke.py`, and `scripts/serve.py` (see `README.md`).

### What cannot run here

- The experiment scripts that reproduce reported results (`scripts/prepare_cache.py`,
  `scripts/e1_*`, `scripts/e2_*`, `scripts/fedavg_run.py`, `scripts/phase*`)
  require the real corpus at `data/raw/url.csv`, which is deliberately excluded
  and provenance-blocked (see `PUSH.md` and `docs/DECISIONS.md` D-014). Without
  that file they will fail; use synthetic data via `scripts/smoke.py` instead.
