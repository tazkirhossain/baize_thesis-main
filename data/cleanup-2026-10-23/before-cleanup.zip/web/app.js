const EXAMPLES = [
  { label: "synthetic adult marker", url: "https://zqvx412.com/krellon" },
  { label: "synthetic non-adult marker", url: "https://harbour88.org/about" },
  { label: "query is stripped", url: "https://ledger12.com/index?token=SECRET" },
];

const form = document.getElementById("check-form");
const input = document.getElementById("url-input");
const chips = document.getElementById("chips");
const stamp = document.getElementById("model-stamp");
const stampNote = document.getElementById("model-note");
const footerMeta = document.getElementById("footer-meta");

EXAMPLES.forEach((ex) => {
  const b = document.createElement("button");
  b.type = "button";
  b.className = "chip";
  b.textContent = ex.label;
  b.addEventListener("click", () => {
    input.value = ex.url;
    input.focus();
  });
  chips.appendChild(b);
});

form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  const url = input.value.trim();
  if (!url) return;
  setBusy(true);
  try {
    const res = await fetch("/api/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });
    const data = await res.json();
    renderVerdict(data);
  } catch (err) {
    renderVerdict({
      ok: false,
      verdict: "invalid",
      reason: "network_error",
      p_adult: null,
    });
  } finally {
    setBusy(false);
  }
});

function setBusy(on) {
  document.getElementById("check-btn").disabled = on;
  document.getElementById("check-btn").textContent = on ? "…" : "Check";
}

function renderVerdict(d) {
  const wait = document.getElementById("verdict-wait");
  const vstamp = document.getElementById("verdict-stamp");
  const vp = document.getElementById("verdict-p");
  const gauge = document.getElementById("gauge");
  const help = document.getElementById("verdict-help");
  wait.hidden = true;
  vstamp.hidden = false;

  const labels = {
    adult: "Adult",
    non_adult: "Non-adult",
    uncertain: "Uncertain",
    invalid: "Invalid URL",
  };
  vstamp.textContent = labels[d.verdict] || d.verdict;
  vstamp.className = "verdict-stamp " + (d.verdict || "");

  if (d.p_adult == null) {
    vp.hidden = true;
    gauge.hidden = true;
    help.textContent = d.reason ? "Rejected: " + d.reason + "." : "Could not parse that input.";
  } else {
    vp.hidden = false;
    gauge.hidden = false;
    vp.textContent = "p(adult) = " + d.p_adult.toFixed(4) + "   logit = " + Number(d.logit).toFixed(3);
    const pct = Math.max(0, Math.min(1, d.p_adult)) * 100;
    document.getElementById("needle").style.left = "calc(" + pct + "% - 1px)";
    if (d.verdict === "uncertain") {
      help.textContent = "Inside the abstention band (0.40, 0.60). The research design prefers no answer here to a forced 0/1.";
    } else if (d.model_source === "synthetic") {
      help.textContent = "Demo model: this score reflects abstract markers, not the live web.";
    } else {
      help.textContent = "Host+path only. The page was not downloaded.";
    }
  }

  document.querySelectorAll(".steps li").forEach((li) => {
    li.classList.toggle("on", Boolean(d.ok) || d.verdict === "invalid");
  });

  const trace = document.getElementById("trace");
  trace.innerHTML = "";
  const rows = [];
  if (d.scrubbed_url) rows.push(["scrubbed", d.scrubbed_url]);
  if (d.host) rows.push(["host", d.host]);
  if (d.registrable_domain) rows.push(["eTLD+1", d.registrable_domain]);
  if (d.path) rows.push(["path", d.path || "/"]);
  if (d.feature_text) rows.push(["features", d.feature_text]);
  rows.push(["stripped", d.query_or_userinfo_stripped ? "yes (secrets dropped)" : "no extra fields"]);
  if (d.nnz) rows.push(["nnz", String(d.nnz) + " / " + String(d.n_features) + " hashed bins"]);
  rows.forEach(([k, v]) => {
    const dt = document.createElement("dt");
    dt.textContent = k;
    const dd = document.createElement("dd");
    dd.textContent = v;
    trace.appendChild(dt);
    trace.appendChild(dd);
  });
}

function fmt(x) {
  if (x == null || Number.isNaN(x)) return "—";
  const n = Number(x);
  if (Math.abs(n) >= 0.01) return n.toFixed(3);
  return n.toExponential(2);
}

function decisionClass(d) {
  const s = String(d || "").toLowerCase();
  if (s === "supported") return "supported";
  if (s === "not supported" || s === "not_supported") return "not_supported";
  return "measured";
}

async function loadMeta() {
  const [meta, exp] = await Promise.all([
    fetch("/api/meta").then((r) => r.json()),
    fetch("/api/experiments").then((r) => r.json()),
  ]);

  const source = meta.source || "unknown";
  stamp.textContent = source === "corpus-sample" ? "corpus sample" : "synthetic demo";
  stamp.classList.toggle("corpus", source === "corpus-sample");
  stampNote.textContent = meta.limitations || "";
  footerMeta.textContent =
    "n_train=" + (meta.n_train ?? "—") +
    "  ·  features=" + (meta.n_features ?? "—") +
    "  ·  pos_rate=" + (meta.positive_rate != null ? Number(meta.positive_rate).toFixed(4) : "—") +
    "  ·  commit=" + (meta.git_commit || "—");

  const sys = document.getElementById("sys-list");
  (exp.pipeline || []).forEach((s) => {
    const li = document.createElement("li");
    li.innerHTML = "";
    const h = document.createElement("h3");
    h.textContent = s.title;
    const p = document.createElement("p");
    p.textContent = s.module + " · keeps " + s.keeps + " · drops " + s.drops;
    li.appendChild(h);
    li.appendChild(p);
    sys.appendChild(li);
  });
  const gates = document.getElementById("gates");
  (exp.gates || []).forEach((g) => {
    const li = document.createElement("li");
    li.textContent = g;
    gates.appendChild(li);
  });

  const root = document.getElementById("hypotheses");
  const maxBar = 0.85;
  (exp.hypotheses || []).forEach((h) => {
    const art = document.createElement("article");
    art.className = "hyp";
    const head = document.createElement("div");
    head.className = "hyp-head";
    const title = document.createElement("h3");
    title.textContent = h.id + " — " + h.title;
    const dec = document.createElement("span");
    dec.className = "decision " + decisionClass(h.decision);
    dec.textContent = h.decision || "";
    head.appendChild(title);
    head.appendChild(dec);
    art.appendChild(head);
    const note = document.createElement("p");
    note.className = "hyp-note";
    const extra = [];
    if (h.delta != null) extra.push("Δ " + fmt(h.delta));
    if (h.sigma != null) extra.push(fmt(h.sigma) + " σc");
    if (h.n_seeds) extra.push(h.n_seeds + " seeds");
    note.textContent = (extra.join(" · ") + (h.note ? " · " + h.note : "")).replace(/^ · /, "");
    art.appendChild(note);
    (h.bars || []).forEach((b, i) => {
      const row = document.createElement("div");
      row.className = "bar-row";
      const lab = document.createElement("span");
      lab.textContent = b.label;
      const track = document.createElement("div");
      track.className = "bar-track";
      const fill = document.createElement("div");
      fill.className = "bar-fill" + (i ? " alt" : "");
      const v = Number(b.value) || 0;
      fill.style.width = Math.max(0, Math.min(100, (v / maxBar) * 100)) + "%";
      track.appendChild(fill);
      const num = document.createElement("span");
      num.textContent = fmt(b.value);
      row.appendChild(lab);
      row.appendChild(track);
      row.appendChild(num);
      art.appendChild(row);
    });
    root.appendChild(art);
  });
}

loadMeta().catch(() => {
  stamp.textContent = "offline";
  stampNote.textContent = "Could not load /api/meta. Is the demo server running?";
});
