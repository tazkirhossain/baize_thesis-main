# Pushing this to GitHub

This archive contains a complete git repository with full history on branch
`main`. You do NOT need `git init` or `git add .` — everything is already
committed.

```bash
cd BAIZE_thesis
git remote add origin https://github.com/rafinulhuq/BAIZE_thesis.git
git push -u origin main
```

If the remote already exists, use `git remote set-url origin <url>` instead.
If the remote has commits (e.g. an auto-created README) the push is rejected;
either `git pull --rebase origin main` or, if the remote is otherwise empty,
`git push -f -u origin main`.

## Do not run `git add .` with the corpus present

`.gitignore` excludes `/data/` (root-anchored). The rule must stay anchored:
a bare `data/` would also match `baize/data/` and silently drop the entire
data-processing package from the commit.

Before any future commit, sanity-check:

```bash
git add . --dry-run | grep -E "url\.csv|\.pkl$" || echo "CLEAN"
```

## The corpus is deliberately not included

`data/raw/url.csv` (~81 MB) is excluded. Its licence and provenance are
unverified — see `docs/DECISIONS.md` D-014, which is open and blocks
publication. `LICENSE` (MIT) covers this source code only, not the data.

To reproduce, place the corpus at `data/raw/url.csv` and run:

```bash
pip install -r requirements.txt
python scripts/prepare_cache.py data/raw/url.csv
python -m pytest tests/ -q
```
