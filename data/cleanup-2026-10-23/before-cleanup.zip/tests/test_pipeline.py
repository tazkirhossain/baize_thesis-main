"""Tests for the BAIZE data and federated pipeline.

Emphasis is on the GATES, not on model quality. A silently leaking split or a
mis-stated noise rate invalidates every downstream number while looking like a
good result, so those paths get the most coverage.
"""

from __future__ import annotations

import numpy as np
import pytest

from baize.data.dataset import make_synthetic_dataset, URLDataset
from baize.data.noise import (
    NoiseReport,
    NoiseValidationError,
    apply_client_noise,
    apply_noise,
    assert_noise_valid,
)
from baize.data.partition import partition
from baize.data.splits import LeakageError, assert_no_leakage, make_splits
from baize.data.url import normalize_url
from baize.data.validation import deduplicate, validate_dataset
from baize.evaluation.metrics import classification_metrics, precision_at_base_rate
from baize.federated.aggregation import coordinate_median, fedavg, trimmed_mean, norm_clip_fedavg
from baize.models.linear import LogisticSGD, init_params


# --------------------------------------------------------------------------- #
# URL normalisation / privacy minimisation
# --------------------------------------------------------------------------- #

class TestURLPrivacy:
    def test_query_and_fragment_are_destroyed(self):
        """PRIVACY.md §7 negative test: a token in the query must vanish."""
        n = normalize_url("https://site.example.com/a?session=SUPERSECRET123#frag")
        blob = f"{n.host}{n.path}{n.canonical}{n.feature_text}{n.registrable_domain}{n.raw}"
        assert "SUPERSECRET123" not in blob
        assert "session" not in blob
        assert "frag" not in blob

    def test_userinfo_and_port_are_destroyed(self):
        n = normalize_url("http://alice:hunter2@site.example.org:8443/x")
        blob = f"{n.host}{n.path}{n.canonical}{n.raw}"
        assert "alice" not in blob and "hunter2" not in blob and "8443" not in blob

    def test_registrable_domain_handles_multipart_suffix(self):
        assert normalize_url("https://a.b.example.co.uk/x").registrable_domain == "example.co.uk"

    def test_invalid_urls_are_rejected_not_guessed(self):
        for bad in ["", "   ", "ftp://x.example.com", "http://localhost/x", "not a url"]:
            assert normalize_url(bad).is_valid is False

    def test_invalid_url_raw_is_still_scrubbed(self):
        n = normalize_url("ftp://alice:hunter2@x.example.com/a?token=SECRET#frag")
        assert n.is_valid is False
        assert "SECRET" not in n.raw
        assert "hunter2" not in n.raw
        assert "frag" not in n.raw

    def test_bare_host_gets_scheme_assumed(self):
        n = normalize_url("example.com/path")
        assert n.is_valid and n.scheme == "http" and n.registrable_domain == "example.com"

    def test_canonical_ignores_scheme_and_trailing_slash(self):
        a = normalize_url("https://x.example.com/a/")
        b = normalize_url("http://x.example.com/a")
        assert a.canonical == b.canonical

    def test_normalize_never_raises(self):
        for weird in [None, 12345, "http://[bad", "http://" + "a" * 5000, "://"]:
            normalize_url(weird)  # must not raise


# --------------------------------------------------------------------------- #
# Splitting and the leakage gate
# --------------------------------------------------------------------------- #

class TestSplits:
    @pytest.fixture
    def ds(self):
        raw = make_synthetic_dataset(n_domains=300, seed=3)
        clean, _ = deduplicate(raw)
        return clean

    def test_domain_aware_split_has_zero_domain_overlap(self, ds):
        s = make_splits(ds, strategy="domain_aware", seed=0)
        assert s.report.status == "PASS"
        assert set(s.train.domains).isdisjoint(set(s.test.domains))
        assert set(s.train.domains).isdisjoint(set(s.val.domains))
        assert set(s.val.domains).isdisjoint(set(s.test.domains))

    def test_random_split_leaks_domains_and_report_says_so(self, ds):
        """The random split is expected to leak domains. That is the finding."""
        s = make_splits(ds, strategy="random", seed=0)
        assert s.report.domain_overlap["train~test"] > 0
        assert s.report.status == "PASS"  # random makes no domain guarantee

    def test_split_covers_dataset_exactly_once(self, ds):
        s = make_splits(ds, strategy="domain_aware", seed=0)
        assert len(s.train) + len(s.val) + len(s.test) == len(ds)

    def test_proportions_approximately_respected(self, ds):
        s = make_splits(ds, strategy="domain_aware", fractions=(0.7, 0.15, 0.15), seed=0)
        assert abs(s.report.proportions["train"] - 0.70) < 0.05

    def test_leakage_gate_raises_on_contaminated_split(self, ds):
        s = make_splits(ds, strategy="domain_aware", seed=0)
        contaminated = URLDataset(
            urls=s.train.urls[:10] + s.test.urls,
            labels=np.concatenate([s.train.labels[:10], s.test.labels]),
        )
        from baize.data.splits import leakage_report

        rep = leakage_report(s.train, s.val, contaminated, "domain_aware", 0)
        assert rep.status.startswith("BLOCKED")
        with pytest.raises(LeakageError):
            assert_no_leakage(rep)

    def test_split_is_deterministic_under_seed(self, ds):
        a = make_splits(ds, strategy="domain_aware", seed=42)
        b = make_splits(ds, strategy="domain_aware", seed=42)
        assert a.train.fingerprint() == b.train.fingerprint()

    def test_different_seeds_give_different_splits(self, ds):
        a = make_splits(ds, strategy="domain_aware", seed=1)
        b = make_splits(ds, strategy="domain_aware", seed=2)
        assert a.train.fingerprint() != b.train.fingerprint()


# --------------------------------------------------------------------------- #
# Validation and deduplication
# --------------------------------------------------------------------------- #

class TestValidation:
    def test_duplicates_are_detected_and_removed(self):
        ds = URLDataset.from_records(
            ["a.example.com/x", "a.example.com/x/", "b.example.com/y"], [1, 1, 0]
        )
        assert validate_dataset(ds, min_records=1, min_positive_rate=0.0).n_exact_duplicates == 1
        clean, rep = deduplicate(ds)
        assert len(clean) == 2 and rep.n_removed == 1

    def test_label_conflicts_are_counted_not_hidden(self):
        ds = URLDataset.from_records(
            ["a.example.com/x", "a.example.com/x", "b.example.com/y"], [1, 0, 0]
        )
        clean, rep = deduplicate(ds, conflict="drop")
        assert rep.n_label_conflicts == 1
        assert len(clean) == 1  # both copies of the conflicting URL dropped

    def test_single_class_dataset_is_blocked(self):
        ds = URLDataset.from_records([f"d{i}.example.com/x" for i in range(200)], [0] * 200)
        assert validate_dataset(ds).status.startswith("BLOCKED")

    def test_too_few_domains_blocks_domain_aware_plan(self):
        urls = [f"a.example.com/{i}" for i in range(100)] + [f"b.example.com/{i}" for i in range(100)]
        ds = URLDataset.from_records(urls, [1] * 100 + [0] * 100)
        rep = validate_dataset(ds)
        assert rep.status.startswith("BLOCKED")
        assert any("unique domains" in f for f in rep.findings)


# --------------------------------------------------------------------------- #
# Noise injection
# --------------------------------------------------------------------------- #

class TestNoise:
    def test_realised_rate_is_close_to_target_at_scale(self):
        y = np.random.default_rng(0).integers(0, 2, 20000).astype(np.int8)
        noisy, rep = apply_noise(y, "symmetric", rate=0.20, seed=1)
        assert rep.status == "PASS"
        assert abs(rep.realised_rate - 0.20) < 0.02
        assert rep.n_flipped == int((noisy != y).sum())

    def test_report_states_realised_not_target(self):
        y = np.zeros(1000, dtype=np.int8)
        _, rep = apply_noise(y, "symmetric", rate=0.30, seed=2)
        assert rep.realised_rate != rep.target_rate  # sampling noise: never identical
        assert "realised" in rep.render()

    def test_zero_noise_changes_nothing(self):
        y = np.random.default_rng(0).integers(0, 2, 500).astype(np.int8)
        noisy, rep = apply_noise(y, "symmetric", rate=0.0, seed=0)
        assert np.array_equal(y, noisy) and rep.n_flipped == 0

    def test_class_conditional_respects_per_class_rates(self):
        y = np.array([0] * 5000 + [1] * 5000, dtype=np.int8)
        _, rep = apply_noise(y, "class_conditional", class_rates={0: 0.05, 1: 0.30}, seed=3)
        assert abs(rep.per_class_realised[0] - 0.05) < 0.02
        assert abs(rep.per_class_realised[1] - 0.30) < 0.02

    def test_protected_array_cannot_be_noised(self):
        """The clean test set tripwire — flag and tagged array both refuse."""
        from baize.data.noise import mark_protected

        with pytest.raises(NoiseValidationError, match="protected"):
            apply_noise(np.zeros(10, dtype=np.int8), rate=0.2, protected=True)
        tagged = mark_protected(np.zeros(10, dtype=np.int8))
        with pytest.raises(NoiseValidationError, match="protected"):
            apply_noise(tagged, rate=0.2)
        with pytest.raises(NoiseValidationError, match="protected"):
            apply_client_noise(tagged, [np.arange(10)], [0.2])

    def test_gate_blocks_when_realised_deviates(self):
        y = np.zeros(20, dtype=np.int8)
        _, rep = apply_noise(y, "symmetric", rate=0.50, seed=0, tolerance=0.001)
        if not rep.status.startswith("PASS"):
            with pytest.raises(NoiseValidationError):
                assert_noise_valid(rep)

    def test_client_heterogeneous_noise_is_per_client(self):
        y = np.random.default_rng(0).integers(0, 2, 6000).astype(np.int8)
        parts, _ = partition(y, "iid", n_clients=3, seed=0)
        rates = [0.0, 0.2, 0.4]
        noisy, rep = apply_client_noise(y, parts, rates, seed=5)
        assert rep.status == "PASS"
        assert rep.per_client[0]["n_flipped"] == 0  # clean client stays clean
        assert np.array_equal(y[parts[0]], noisy[parts[0]])
        assert abs(rep.per_client[2]["realised"] - 0.4) < 0.05

    def test_noise_is_reproducible(self):
        y = np.random.default_rng(0).integers(0, 2, 1000).astype(np.int8)
        a, _ = apply_noise(y, "symmetric", rate=0.25, seed=9)
        b, _ = apply_noise(y, "symmetric", rate=0.25, seed=9)
        assert np.array_equal(a, b)

    def test_input_array_is_not_mutated(self):
        y = np.random.default_rng(0).integers(0, 2, 500).astype(np.int8)
        before = y.copy()
        apply_noise(y, "symmetric", rate=0.3, seed=0)
        assert np.array_equal(y, before)


# --------------------------------------------------------------------------- #
# Partitioning
# --------------------------------------------------------------------------- #

class TestPartition:
    @pytest.fixture
    def labels(self):
        return np.random.default_rng(0).integers(0, 2, 5000).astype(np.int8)

    @pytest.mark.parametrize("strategy", ["iid", "label_skew", "quantity_skew"])
    def test_partition_is_exact_cover(self, labels, strategy):
        parts, rep = partition(labels, strategy, n_clients=10, seed=0)
        assert rep.status == "PASS"
        all_idx = np.concatenate(parts)
        assert len(all_idx) == len(labels)
        assert len(np.unique(all_idx)) == len(labels)

    def test_iid_clients_have_similar_class_balance(self, labels):
        _, rep = partition(labels, "iid", n_clients=10, seed=0)
        spread = max(rep.positive_rates) - min(rep.positive_rates)
        assert spread < 0.10

    def test_label_skew_actually_skews(self, labels):
        _, iid = partition(labels, "iid", n_clients=10, seed=0)
        _, skew = partition(labels, "label_skew", n_clients=10, alpha=0.1, seed=0)
        iid_spread = max(iid.positive_rates) - min(iid.positive_rates)
        skew_spread = max(skew.positive_rates) - min(skew.positive_rates)
        assert skew_spread > iid_spread

    def test_quantity_skew_actually_skews_sizes(self, labels):
        _, iid = partition(labels, "iid", n_clients=10, seed=0)
        _, qs = partition(labels, "quantity_skew", n_clients=10, alpha=0.3, seed=0)
        assert np.std(qs.sizes) > np.std(iid.sizes)

    def test_no_empty_clients(self, labels):
        for strat in ["iid", "label_skew", "quantity_skew"]:
            parts, rep = partition(labels, strat, n_clients=20, seed=1)
            assert all(len(p) > 0 for p in parts), f"{strat} produced an empty client"

    def test_quantity_skew_does_not_dump_remainder_on_last_client(self, labels):
        parts, rep = partition(labels, "quantity_skew", n_clients=10, alpha=0.3, seed=0)
        assert sum(rep.sizes) == len(labels)
        # Hamilton leftover is spread by fractional part; the last client must
        # not be a systematic remainder bucket (its size is not max by index).
        assert rep.status == "PASS"

    def test_too_many_clients_is_refused(self, labels):
        with pytest.raises(ValueError, match="cannot partition"):
            partition(labels[:5], "iid", n_clients=10, seed=0)


# --------------------------------------------------------------------------- #
# Aggregation
# --------------------------------------------------------------------------- #

class TestAggregation:
    def test_fedavg_is_the_weighted_mean(self):
        d = [np.array([1.0, 2.0]), np.array([3.0, 4.0])]
        agg, _ = fedavg(d, weights=np.array([1.0, 3.0]))
        np.testing.assert_allclose(agg, [2.5, 3.5])

    def test_fedavg_is_destroyed_by_one_scaled_update(self):
        """The baseline's failure mode, stated in ASSUMPTIONS['fedavg']."""
        honest = [np.array([1.0, 1.0]) for _ in range(9)]
        attack = [np.array([1000.0, 1000.0])]
        agg, _ = fedavg(honest + attack)
        assert np.linalg.norm(agg) > 100  # a single client moved the aggregate

    def test_median_resists_the_same_attack(self):
        honest = [np.array([1.0, 1.0]) for _ in range(9)]
        attack = [np.array([1000.0, 1000.0])]
        agg, _ = coordinate_median(honest + attack)
        np.testing.assert_allclose(agg, [1.0, 1.0])

    def test_trimmed_mean_resists_the_same_attack(self):
        honest = [np.array([1.0, 1.0]) for _ in range(8)]
        attack = [np.array([1000.0, 1000.0]), np.array([-1000.0, -1000.0])]
        agg, rep = trimmed_mean(honest + attack, beta=0.2)
        np.testing.assert_allclose(agg, [1.0, 1.0])
        assert rep.params["retained"] == 6

    def test_trimmed_mean_records_discarded_weights(self):
        honest = [np.array([1.0, 1.0]) for _ in range(8)]
        _, rep = trimmed_mean(honest, weights=np.arange(1, 9, dtype=float), beta=0.2)
        assert "discarded" in rep.params.get("note", "")

    def test_trimmed_mean_rejects_impossible_beta(self):
        with pytest.raises(ValueError):
            trimmed_mean([np.array([1.0]) for _ in range(4)], beta=0.5)

    def test_norm_clipping_bounds_the_attacker(self):
        honest = [np.array([1.0, 0.0]) for _ in range(9)]
        attack = [np.array([500.0, 0.0])]
        agg, rep = norm_clip_fedavg(honest + attack, clip_norm=2.0)
        assert 0 in [i for i in rep.clipped_clients] or rep.clipped_clients == [9]
        assert np.linalg.norm(agg) <= 2.0 + 1e-9

    def test_non_finite_updates_are_blocked_not_repaired(self):
        with pytest.raises(ValueError, match="non-finite"):
            fedavg([np.array([1.0, 2.0]), np.array([np.nan, 1.0])])

    def test_every_aggregator_declares_a_threat_model(self):
        from baize.federated.aggregation import AGGREGATORS, ASSUMPTIONS

        for name in AGGREGATORS:
            assert name in ASSUMPTIONS, f"{name} has no declared threat model"
            for field in ("defends_against", "assumes", "fails_when"):
                assert ASSUMPTIONS[name][field].strip()


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #

class TestModel:
    def test_param_vector_round_trip(self):
        m = LogisticSGD(50)
        v = np.random.default_rng(0).normal(size=51)
        m.set_params(v)
        np.testing.assert_allclose(m.get_params(), v)

    def test_set_params_rejects_non_finite(self):
        m = LogisticSGD(10)
        bad = init_params(10)
        bad[3] = np.inf
        with pytest.raises(ValueError, match="non-finite"):
            m.set_params(bad)

    def test_set_params_rejects_wrong_shape(self):
        with pytest.raises(ValueError):
            LogisticSGD(10).set_params(np.zeros(5))

    def test_model_learns_a_separable_problem(self):
        rng = np.random.default_rng(0)
        X = rng.normal(size=(600, 5))
        y = (X[:, 0] > 0).astype(np.int8)
        m = LogisticSGD(5)
        m.fit(X, y, epochs=40, batch_size=32, lr=0.5, rng=rng)
        assert (m.predict(X) == y).mean() > 0.90

    def test_sigmoid_is_stable_at_extremes(self):
        from baize.models.linear import sigmoid

        out = sigmoid(np.array([-2000.0, 0.0, 2000.0]))
        assert np.all(np.isfinite(out))
        np.testing.assert_allclose(out, [0.0, 0.5, 1.0], atol=1e-9)


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #

class TestMetrics:
    def test_perfect_predictions(self):
        y = np.array([0, 0, 1, 1])
        m = classification_metrics(y, np.array([0.01, 0.02, 0.98, 0.99]))
        assert m["pr_auc"] == pytest.approx(1.0)
        assert m["fpr"] == 0.0 and m["fnr"] == 0.0

    def test_base_rate_projection_collapses_precision_when_positives_are_rare(self):
        """RESEARCH.md §4.9 - the whole reason this function exists."""
        balanced = precision_at_base_rate(recall=0.90, fpr=0.05, base_rate=0.50)
        rare = precision_at_base_rate(recall=0.90, fpr=0.05, base_rate=0.01)
        assert balanced > 0.9
        assert rare < 0.2

    def test_metrics_reject_non_finite_probabilities(self):
        with pytest.raises(ValueError, match="non-finite"):
            classification_metrics(np.array([0, 1]), np.array([0.5, np.nan]))

    def test_abstention_raises_accuracy_and_lowers_coverage(self):
        from baize.evaluation.metrics import coverage_risk_curve

        rng = np.random.default_rng(0)
        y = rng.integers(0, 2, 2000)
        p = np.clip(y * 0.6 + 0.2 + rng.normal(0, 0.18, 2000), 0.001, 0.999)
        curve = coverage_risk_curve(y, p, n_points=10)
        assert curve[0]["coverage"] == pytest.approx(1.0)
        assert curve[-1]["coverage"] < curve[0]["coverage"]


# --------------------------------------------------------------------------- #
# End to end
# --------------------------------------------------------------------------- #

class TestEndToEnd:
    @pytest.fixture
    def ds(self):
        return make_synthetic_dataset(n_domains=250, seed=11)

    def test_federated_run_completes_and_reports_provenance(self, ds):
        from baize.experiments.runner import ExperimentConfig, run_experiment

        r = run_experiment(ds, ExperimentConfig(mode="federated", n_clients=5, rounds=5,
                                                n_features=2**14, seed=0))
        assert np.isfinite(r.test_metrics["pr_auc"])
        assert len(r.provenance["dataset_fingerprint"]) == 64
        assert r.assumptions  # a run must never claim zero assumptions
        assert r.training_budget["passes_per_example"] == 5 * 3  # rounds * local_epochs
        assert r.selected_checkpoint["kind"] == "round"

    def test_test_labels_are_never_noised(self, ds):
        """The single most important invariant in the project."""
        from baize.experiments.runner import ExperimentConfig, run_experiment
        from baize.data.splits import make_splits
        from baize.data.validation import deduplicate

        clean, _ = deduplicate(ds)
        expected = make_splits(clean, strategy="domain_aware", seed=0).test

        r = run_experiment(ds, ExperimentConfig(mode="federated", n_clients=5, rounds=3,
                                                n_features=2**14, noise_process="symmetric",
                                                noise_rate=0.30, seed=0))
        assert r.noise_report is not None and "PASS" in r.noise_report
        # test set positive rate must equal the untouched split's positive rate
        assert r.test_metrics["positive_rate"] == pytest.approx(expected.positive_rate)

    def test_noise_actually_reaches_the_clients(self, ds):
        """Mechanism test, NOT a test of H2.

        An earlier version of this test asserted that 40% noise lowers test
        PR-AUC on a single seed. It failed - noise appeared to *help*. A
        multi-seed sweep showed why: cross-seed sd on this synthetic corpus is
        ~0.078 PR-AUC, and the clean-vs-40% gap is ~0.088, i.e. 1.1 sd. The
        single-seed result was inside the noise floor.

        That is precisely the error RESEARCH.md §4.10 forbids: reading a
        direction off a difference smaller than the cross-seed spread. Level 1
        unit tests verify MECHANISM; hypothesis H2 is a Level 4 claim and is
        established by the multi-seed experiment matrix, never by CI.

        So this test asserts only what is deterministically true: that the
        requested noise was injected, validated, and delivered to the clients.
        """
        from baize.experiments.runner import ExperimentConfig, run_experiment

        r = run_experiment(
            ds,
            ExperimentConfig(mode="federated", n_clients=5, rounds=3, n_features=2**14,
                             noise_process="symmetric", noise_rate=0.40, seed=0),
        )
        assert r.noise_report is not None
        assert "PASS" in r.noise_report
        assert "0.40" in r.noise_report or "0.4000" in r.noise_report
        # realised rate must be within 4 binomial SE of target, per the gate
        assert "BLOCKED" not in r.noise_report

    def test_noise_gate_catches_a_broken_injector(self):
        """Guard against a silently wrong noise implementation."""
        from baize.data.noise import apply_noise, effective_tolerance

        y = np.zeros(50_000, dtype=np.int8)
        _, rep = apply_noise(y, "symmetric", rate=0.20, seed=0)
        assert rep.status == "PASS"
        # simulate an implementation that flips at half the requested rate
        broken = NoiseReport = type(rep)(
            process="symmetric", target_rate=0.20, realised_rate=0.10,
            n_samples=50_000, n_flipped=5000, seed=0,
            tolerance=effective_tolerance(0.20, 50_000),
        )
        assert abs(broken.realised_rate - broken.target_rate) > broken.tolerance
        assert broken.deviation_sigmas > 10

    def test_run_is_reproducible_under_seed(self, ds):
        from baize.experiments.runner import ExperimentConfig, run_experiment

        cfg = dict(mode="federated", n_clients=5, rounds=5, n_features=2**14, seed=123)
        a = run_experiment(ds, ExperimentConfig(**cfg))
        b = run_experiment(ds, ExperimentConfig(**cfg))
        assert a.test_metrics["pr_auc"] == pytest.approx(b.test_metrics["pr_auc"])


# --------------------------------------------------------------------------- #
# Convergence testing
# --------------------------------------------------------------------------- #

class TestConvergence:
    def test_flat_curve_is_converged(self):
        from baize.evaluation.convergence import check_convergence
        rng = np.random.default_rng(0)
        v = 0.60 + rng.normal(0, 0.0005, 40)
        assert check_convergence(v).status == "CONVERGED"

    def test_noisy_but_stationary_curve_is_converged(self):
        """The case the old spread-based criterion got wrong."""
        from baize.evaluation.convergence import check_convergence
        rng = np.random.default_rng(1)
        v = 0.47 + rng.normal(0, 0.006, 40)   # oscillation like a 20% noise run
        r = check_convergence(v)
        assert r.status == "CONVERGED"
        assert max(v[-5:]) - min(v[-5:]) > 0.005   # old criterion would say False

    def test_rising_curve_is_improving(self):
        from baize.evaluation.convergence import check_convergence
        v = np.linspace(0.50, 0.60, 40)
        assert check_convergence(v).status == "IMPROVING"

    def test_declining_curve_is_degrading(self):
        """40% noise: model fits the noise after an early peak."""
        from baize.evaluation.convergence import check_convergence
        v = np.concatenate([np.linspace(0.20, 0.334, 15), np.linspace(0.334, 0.30, 30)])
        r = check_convergence(v)
        assert r.status == "DEGRADING"
        assert r.best_index == 14
        assert not r.best_at_cap

    def test_tiny_but_significant_slope_is_still_converged(self):
        """Statistical significance alone must not justify more compute."""
        from baize.evaluation.convergence import check_convergence
        v = np.linspace(0.600, 0.6002, 40)   # perfectly linear, negligible gain
        r = check_convergence(v)
        assert abs(r.t_statistic) > 2.0
        assert r.status == "CONVERGED"

    def test_short_curve_reports_insufficient(self):
        from baize.evaluation.convergence import check_convergence
        assert check_convergence([0.1, 0.2, 0.3]).status == "INSUFFICIENT_DATA"

    def test_best_at_cap_is_detected(self):
        from baize.evaluation.convergence import check_convergence
        assert check_convergence(np.linspace(0.5, 0.6, 40)).best_at_cap is True


# --------------------------------------------------------------------------- #
# Checkpoint selection, budget, loaders, resume
# --------------------------------------------------------------------------- #

class TestSelection:
    def test_best_checkpoint_does_not_keep_the_last_epoch(self):
        from baize.evaluation.selection import best_checkpoint

        snaps = [np.array([1.0]), np.array([9.0]), np.array([3.0])]
        params, idx, score = best_checkpoint(snaps, [0.40, 0.61, 0.55])
        assert idx == 2 and score == pytest.approx(0.61)
        np.testing.assert_allclose(params, [9.0])

    def test_ties_keep_the_earliest_checkpoint(self):
        from baize.evaluation.selection import best_checkpoint

        snaps = [np.array([1.0]), np.array([2.0]), np.array([3.0])]
        _, idx, _ = best_checkpoint(snaps, [0.5, 0.5, 0.4])
        assert idx == 1


class TestBudget:
    def test_h1_style_budgets_are_not_equal(self):
        from baize.evaluation.budget import passes_per_example
        from baize.hparams import CENTRALIZED_EPOCHS, LOCAL_EPOCHS, ROUNDS

        central = passes_per_example(centralized_epochs=CENTRALIZED_EPOCHS)
        federated = passes_per_example(rounds=ROUNDS, local_epochs=LOCAL_EPOCHS)
        assert central == 35
        assert federated == 180
        assert federated != central


class TestLoaders:
    def test_unknown_category_is_unmapped_not_silently_negative(self, tmp_path):
        from baize.data.loaders import load_url_csv

        p = tmp_path / "mini.csv"
        p.write_text(
            "1,http://adult.example.com/x,Adult\n"
            "2,http://arts.example.com/y,Arts\n"
            "3,http://weird.example.com/z,NotACategory\n"
        )
        ds, rep = load_url_csv(str(p))
        assert rep.n_unmapped == 1
        assert len(ds) == 2
        assert ds.class_counts.get(1, 0) == 1
        assert ds.class_counts.get(0, 0) == 1
        assert "unmapped" in rep.render()

    def test_sample_is_not_a_positional_category_prefix(self, tmp_path):
        """url.csv is sorted by category; nrows= would be all Adult. Reservoir must mix."""
        from baize.data.loaders import sample_url_csv

        p = tmp_path / "sorted.csv"
        lines = [f"{i},http://adult{i}.example.com/x,Adult" for i in range(80)]
        lines += [f"{i+80},http://arts{i}.example.com/y,Arts" for i in range(320)]
        p.write_text("\n".join(lines) + "\n")
        ds, _rep = sample_url_csv(str(p), n=40, seed=0)
        assert 5 <= ds.class_counts.get(1, 0) <= 20
        assert ds.class_counts.get(0, 0) >= 15


class TestModelResume:
    def test_rng_checkpoint_resumes_training(self):
        """The mechanism fedavg_run.py relies on for bit-exact resume (D-021)."""
        rng = np.random.default_rng(0)
        X = rng.normal(size=(240, 8))
        y = (X[:, 0] > 0).astype(np.int8)
        m1 = LogisticSGD(8, seed=0)
        m2 = LogisticSGD(8, seed=0)
        r1 = np.random.default_rng(1)
        r2 = np.random.default_rng(1)
        m1.fit(X, y, epochs=1, batch_size=32, lr=0.5, rng=r1)
        m2.set_params(m1.get_params())
        r2.bit_generator.state = r1.bit_generator.state
        m1.fit(X, y, epochs=1, batch_size=32, lr=0.5, rng=r1)
        m2.fit(X, y, epochs=1, batch_size=32, lr=0.5, rng=r2)
        np.testing.assert_allclose(m1.get_params(), m2.get_params())


class TestCentralizedSelection:
    def test_runner_keeps_best_validation_epoch_not_the_last(self):
        from baize.experiments.runner import ExperimentConfig, run_experiment

        ds = make_synthetic_dataset(n_domains=180, seed=4)
        r = run_experiment(
            ds,
            ExperimentConfig(
                mode="centralized",
                centralized_epochs=6,
                n_features=2**14,
                seed=0,
            ),
        )
        hist = [h["val_pr_auc"] for h in r.history]
        assert r.selected_checkpoint["kind"] == "epoch"
        assert r.selected_checkpoint["index"] == int(np.argmax(hist)) + 1
        assert r.val_metrics["pr_auc"] == pytest.approx(max(hist))
        assert r.training_budget["passes_per_example"] == 6
        assert "centralized model selected at epoch" in " ".join(r.assumptions)


class TestBugFixesAndEdgeCases:
    def test_bare_url_userinfo_is_scrubbed(self):
        n1 = normalize_url("alice:hunter2@example.com/path")
        assert n1.is_valid is True
        assert "hunter2" not in n1.raw
        assert "alice" not in n1.raw

        n2 = normalize_url("alice:hunter2@localhost")
        assert n2.is_valid is False
        assert "hunter2" not in n2.raw
        assert "alice" not in n2.raw

    def test_check_convergence_on_exact_straight_line(self):
        from baize.evaluation.convergence import check_convergence

        x_up = np.arange(10, dtype=float) * 0.5
        rep_up = check_convergence(x_up, window=10)
        assert rep_up.status == "IMPROVING"
        assert rep_up.t_statistic == float("inf")

        x_down = -np.arange(10, dtype=float) * 0.5
        rep_down = check_convergence(x_down, window=10)
        assert rep_down.status == "DEGRADING"
        assert rep_down.t_statistic == float("-inf")

        x_flat = np.full(10, 0.5)
        rep_flat = check_convergence(x_flat, window=10)
        assert rep_flat.status == "CONVERGED"

    def test_sigmoid_scalar_and_array_inputs(self):
        from baize.models.linear import sigmoid

        assert float(sigmoid(0.0)) == pytest.approx(0.5)
        assert float(sigmoid(1.0)) == pytest.approx(1.0 / (1.0 + np.exp(-1.0)))
        assert float(sigmoid(-1.0)) == pytest.approx(1.0 / (1.0 + np.exp(1.0)))
        arr = sigmoid([0.0, 1.0])
        assert arr.shape == (2,)
        assert arr[0] == pytest.approx(0.5)

    def test_trimmed_mean_validates_beta(self):
        with pytest.raises(ValueError, match="beta must be in"):
            trimmed_mean([np.zeros(5)], beta=-0.1)
        with pytest.raises(ValueError, match="beta must be in"):
            trimmed_mean([np.zeros(5)], beta=0.5)

    def test_norm_clip_fedavg_validates_inputs(self):
        from baize.federated.aggregation import norm_clip_fedavg

        with pytest.raises(ValueError, match="clip_norm must be positive"):
            norm_clip_fedavg([np.zeros(5)], clip_norm=0.0)
        with pytest.raises(ValueError, match="clip_quantile must be in"):
            norm_clip_fedavg([np.zeros(5)], clip_quantile=1.5)

    def test_deduplicate_validates_conflict_param(self):
        ds = make_synthetic_dataset(n_domains=20, seed=1)
        with pytest.raises(ValueError, match="unknown conflict resolution"):
            deduplicate(ds, conflict="unsupported")

    def test_selective_metrics_validates_interval(self):
        from baize.evaluation.metrics import selective_metrics

        with pytest.raises(ValueError, match="lower must be <= upper"):
            selective_metrics([0, 1], [0.2, 0.8], lower=0.7, upper=0.3)

    def test_passes_per_example_mutual_exclusion(self):
        from baize.evaluation.budget import passes_per_example

        with pytest.raises(ValueError, match="provide either centralized_epochs or rounds"):
            passes_per_example(centralized_epochs=5, rounds=5)

    def test_make_splits_validates_fractions(self):
        ds = make_synthetic_dataset(n_domains=20, seed=1)
        with pytest.raises(ValueError, match="fractions must have length 3"):
            make_splits(ds, fractions=(0.8, 0.2))
        with pytest.raises(ValueError, match="fractions must be non-negative"):
            make_splits(ds, fractions=(1.2, -0.1, -0.1))

    def test_runner_validates_config(self):
        from baize.experiments.runner import ExperimentConfig, run_experiment

        ds = make_synthetic_dataset(n_domains=30, seed=1)
        with pytest.raises(ValueError, match="centralized_epochs must be >= 1"):
            run_experiment(ds, ExperimentConfig(mode="centralized", centralized_epochs=0))
        with pytest.raises(ValueError, match="federated training requires a stateless hashing vectorizer"):
            run_experiment(ds, ExperimentConfig(mode="federated", vectorizer="tfidf"))

    def test_discord_notification_payload_formatting(self):
        from scripts.notify_discord import format_payload

        mock_event = {
            "repository": {"full_name": "rafinulhuq/baize_thesis"},
            "ref": "refs/heads/main",
            "compare": "https://github.com/rafinulhuq/baize_thesis/compare/a...b",
            "pusher": {"name": "rafinulhuq"},
            "commits": [
                {
                    "id": "1234567890",
                    "message": "feat: test feature",
                    "url": "https://github.com/rafinulhuq/baize_thesis/commit/1234567",
                    "added": ["file1.py"],
                    "modified": ["file2.py"],
                    "removed": ["file3.py"],
                }
            ],
        }
        payload = format_payload(mock_event)
        assert len(payload["embeds"]) == 1
        embed = payload["embeds"][0]
        assert "1 commit pushed to `main`" in embed["title"]
        assert "feat: test feature" in embed["description"]
        field_names = [f["name"] for f in embed["fields"]]
        assert "🌿 Branch" in field_names
        assert "📁 Changes" in field_names

