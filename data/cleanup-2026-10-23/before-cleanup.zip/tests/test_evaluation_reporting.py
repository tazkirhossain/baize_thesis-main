"""Metric arithmetic, historical-source checks and research report exports."""
from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest
from sklearn.metrics import classification_report, balanced_accuracy_score, f1_score

from src.evaluation.classification import confusion_metrics
from src.evaluation.reporting import (checked_metrics, comparison_coverage, federated_rows,
    numerical_rows, report_markdown, verify_comparability)

ROOT = Path(__file__).resolve().parents[1]
SETTINGS = json.loads((ROOT / "config/reporting/comparison.json").read_text())


@pytest.mark.parametrize("matrix", [[[90, 10], [5, 15]], [[1000, 0], [24, 0]], [[0, 10], [20, 0]], [[10, 0], [0, 3]]])
def test_both_class_metrics_match_independent_sklearn(matrix):
    tn, fp, fn, tp = np.asarray(matrix).ravel()
    labels = [0]*(tn+fp)+[1]*(fn+tp)
    predicted = [0]*tn+[1]*fp+[0]*fn+[1]*tp
    independent = classification_report(labels, predicted, labels=[0, 1], output_dict=True, zero_division=0)
    result = confusion_metrics(matrix)
    for class_id, name in (("0", "non_adult"), ("1", "adult")):
        for suffix, key in (("precision", "precision"), ("recall", "recall"), ("f1", "f1-score")):
            assert result[f"{name}_{suffix}"] == pytest.approx(independent[class_id][key])
    assert result["macro_f1"] == pytest.approx(f1_score(labels, predicted, average="macro", zero_division=0))
    assert result["balanced_accuracy"] == pytest.approx(balanced_accuracy_score(labels, predicted))
    assert result["adult_prevalence"] == (fn+tp)/len(labels)


def test_majority_only_accuracy_does_not_hide_zero_adult_recall():
    result = confusion_metrics([[9763, 0], [237, 0]])
    assert result["accuracy"] == 0.9763
    assert result["adult_recall"] == result["adult_f1"] == 0
    assert result["balanced_accuracy"] == 0.5
    assert result["non_adult_recall"] == 1
    with pytest.raises(ValueError, match="disagrees"):
        checked_metrics(dict(result, adult_recall=0.9))


def test_zero_division_and_invalid_confusion_counts():
    assert confusion_metrics([[5, 0], [0, 0]])["adult_f1"] == 0
    for matrix in ([[0, 0], [0, 0]], [[1.5, 1], [0, 1]], [[np.nan, 0], [1, 2]]):
        with pytest.raises(ValueError):
            confusion_metrics(matrix)


def test_historical_numerical_results_derive_negative_metrics_without_retraining():
    source = ROOT / "data/balancing-four-methods-equal-v2/summary.json"
    if not source.exists():
        pytest.skip("private completed numerical summary is not present in this checkout")
    before = source.read_bytes()
    rows, metadata, skipped = numerical_rows(source, SETTINGS)
    assert len(rows) == 24 and len(metadata) == 12 and not skipped
    assert {row["partition"] for row in rows} == {"iid", "label_skew", "category_skew"}
    assert all("non_adult_f1" in row["metrics"] for row in rows)
    assert all(row["timing"]["training_seconds_sum"] is None for row in rows)
    assert source.read_bytes() == before
    coverage = comparison_coverage(rows, SETTINGS)
    assert all(item["status"] == "not measured" for item in coverage if item["family"] == "character_cnn" and item["method"] != "smote")


def test_duplicate_or_incomparable_experiments_are_rejected():
    row = {"scope": "federated global model", "family": "character_cnn", "data_kind": "real",
           "seed": 42, "partition": "iid", "method": "undersampling", "split": "val", "round": 1,
           "experiment_id": "a"}
    cfg = json.loads((ROOT / "config/federated/character_cnn.json").read_text())
    metadata = {"a": {"configuration": cfg, "data_contracts": {}}}
    with pytest.raises(ValueError, match="duplicate"):
        verify_comparability([row, dict(row)], metadata)
    second = dict(row, method="oversampling", experiment_id="b")
    changed = deepcopy(cfg)
    changed["aggregation_weight"] = "resampled_training"
    metadata["b"] = {"configuration": changed, "data_contracts": {}}
    with pytest.raises(ValueError, match="incompatible"):
        verify_comparability([row, second], metadata)


def test_standalone_figures_and_tables_have_measured_scope(tmp_path):
    pytest.importorskip("matplotlib")
    from src.evaluation.plots import export_plots
    rows = []
    for partition in ("iid", "label_skew", "category_skew"):
        for method in SETTINGS["required_balancing_methods"]:
            for split in ("val", "test"):
                rows.append({"family": "engineered_numeric", "classifier": "sgd_logistic", "data_kind": "real", "scope": "pooled independent local numerical models",
                             "partition": partition, "method": method, "ratio": "1:1", "seed": 42, "split": split,
                             "round": None, "metrics": confusion_metrics([[90, 10], [5, 15]])})
    report = {"rows": rows, "experiments": {}, "limitations": ["Synthetic unit-test values only."],
              "coverage": comparison_coverage(rows, SETTINGS)}
    names = export_plots(report, tmp_path, ("png",))
    assert len(names) == 4 and all((tmp_path / name).stat().st_size > 1000 for name in names)
    markdown = report_markdown(report, names)
    assert "Non-adult P" in markdown and "No method is declared best" in markdown
