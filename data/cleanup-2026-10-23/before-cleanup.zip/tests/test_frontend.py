"""Demo frontend: inference, privacy of the check API, frozen research snapshot."""

from __future__ import annotations

import json
from pathlib import Path
from urllib.request import Request, urlopen

import pytest

from baize.data.dataset import make_synthetic_dataset
from baize.demo_server import safe_web_path, serve_in_thread
from baize.inference import UrlClassifier, train_classifier
from baize.research_snapshot import research_snapshot


def _tiny_classifier() -> UrlClassifier:
    ds = make_synthetic_dataset(n_domains=400, seed=7, name="synthetic-demo")
    return train_classifier(
        ds,
        n_features=2**16,
        epochs=14,
        batch_size=256,
        lr=8.0,
        source="synthetic",
    )


@pytest.fixture(scope="module")
def clf() -> UrlClassifier:
    return _tiny_classifier()


class TestInference:
    def test_synthetic_markers_are_ordered(self, clf: UrlClassifier):
        pos = clf.classify("https://zqvx412.com/krellon")
        neg = clf.classify("https://harbour88.org/about")
        assert pos.ok and neg.ok
        assert pos.p_adult > neg.p_adult
        assert pos.p_adult > 0.5
        assert neg.p_adult < 0.5
        assert pos.verdict == "adult"
        assert neg.verdict == "non_adult"

    def test_invalid_url_is_rejected(self, clf: UrlClassifier):
        r = clf.classify("not a url")
        assert r.ok is False
        assert r.verdict == "invalid"
        assert r.p_adult is None

    def test_query_never_appears_in_the_result(self, clf: UrlClassifier):
        r = clf.classify("https://harbour88.org/about?session=SUPERSECRET123")
        blob = json.dumps(r.to_dict())
        assert "SUPERSECRET123" not in blob
        assert "session" not in blob
        assert r.query_or_userinfo_stripped is True
        assert r.scrubbed_url.endswith("/about")
        assert r.fetched is False

    def test_userinfo_never_appears_in_the_result(self, clf: UrlClassifier):
        r = clf.classify("https://alice:hunter2@harbour88.org/index")
        blob = json.dumps(r.to_dict())
        assert "alice" not in blob
        assert "hunter2" not in blob

    def test_save_and_load_roundtrip(self, clf: UrlClassifier, tmp_path: Path):
        path = tmp_path / "clf.npz"
        clf.save(path)
        loaded = UrlClassifier.load(path)
        a = clf.classify("https://zqvx412.com/vashtu")
        b = loaded.classify("https://zqvx412.com/vashtu")
        assert a.p_adult == pytest.approx(b.p_adult)
        assert loaded.source == "synthetic"


class TestDemoServer:
    def test_check_and_meta_endpoints(self, clf: UrlClassifier):
        httpd, _thread = serve_in_thread(clf, host="127.0.0.1", port=0)
        host, port = httpd.server_address[:2]
        try:
            page = urlopen(f"http://{host}:{port}/", timeout=5).read().decode("utf-8")
            assert "Check a URL" in page
            assert 'id="url-input"' in page

            meta = json.loads(urlopen(f"http://{host}:{port}/api/meta", timeout=5).read())
            assert meta["source"] == "synthetic"
            assert meta["fetches_pages"] is False

            exp = json.loads(urlopen(f"http://{host}:{port}/api/experiments", timeout=5).read())
            ids = [h["id"] for h in exp["hypotheses"]]
            assert ids == ["RQ1", "H1", "H4", "H3", "H5"]

            req = Request(
                f"http://{host}:{port}/api/check",
                data=json.dumps({"url": "https://harbour88.org/x?token=SUPERSECRET123"}).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            body = json.loads(urlopen(req, timeout=5).read())
            assert "SUPERSECRET123" not in json.dumps(body)
            assert body["fetched"] is False
            assert body["ok"] is True
        finally:
            httpd.shutdown()
            httpd.server_close()

    def test_negative_content_length_rejected(self, clf: UrlClassifier):
        import http.client

        httpd, _thread = serve_in_thread(clf, host="127.0.0.1", port=0)
        host, port = httpd.server_address[:2]
        try:
            conn = http.client.HTTPConnection(host, port, timeout=5)
            conn.request("POST", "/api/check", body=b"{}", headers={"Content-Length": "-1", "Content-Type": "application/json"})
            resp = conn.getresponse()
            assert resp.status == 400
            data = json.loads(resp.read().decode())
            assert data["error"] == "bad_length"
            conn.close()
        finally:
            httpd.shutdown()
            httpd.server_close()

    def test_bare_credentials_scrubbed_in_api(self, clf: UrlClassifier):
        httpd, _thread = serve_in_thread(clf, host="127.0.0.1", port=0)
        host, port = httpd.server_address[:2]
        try:
            req = Request(
                f"http://{host}:{port}/api/check",
                data=json.dumps({"url": "alice:hunter2@localhost"}).encode(),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            body = json.loads(urlopen(req, timeout=5).read())
            assert "hunter2" not in json.dumps(body)
            assert "alice" not in json.dumps(body)
            assert body["query_or_userinfo_stripped"] is True
        finally:
            httpd.shutdown()
            httpd.server_close()

    def test_path_traversal_is_rejected(self, tmp_path: Path):
        assert safe_web_path("../README.md", root=tmp_path) is None
        (tmp_path / "styles.css").write_text("x")
        assert safe_web_path("styles.css", root=tmp_path) == (tmp_path / "styles.css").resolve()


class TestResearchSnapshot:
    def test_reads_committed_decision_json(self):
        snap = research_snapshot()
        h1 = next(h for h in snap["hypotheses"] if h["id"] == "H1")
        assert h1["decision"] == "SUPPORTED"
        assert "matched-budget" in h1["note"]
        rq1 = next(h for h in snap["hypotheses"] if h["id"] == "RQ1")
        assert rq1["bars"][1]["value"] == pytest.approx(0.6145, abs=1e-3)
