"""Opt-in real localhost gRPC test (no sockets needed by the default suite)."""
import json
import importlib
import os
from pathlib import Path
import socket
import threading

import pytest

pytestmark = pytest.mark.skipif(os.environ.get("BAIZE_TEST_FLOWER_NETWORK") != "1",
                                reason="opt in to real loopback sockets")
fl = pytest.importorskip("flwr")
torch = pytest.importorskip("torch")
from flwr.server.client_manager import SimpleClientManager
from scripts.federated import synthetic_clients, MAX_MESSAGE
from src.client.flower_client import URLFlowerClient
from src.server.flower_strategy import FederatedServer, FiveClientFedAvg


def test_server_five_clients_over_grpc(tmp_path, monkeypatch):
    # Flower normally runs the server in the main process. Only this threaded
    # test bypasses signal registration; CLI server behavior is unchanged.
    monkeypatch.setattr(importlib.import_module("flwr.compat.server.app"),
                        "register_signal_handlers", lambda **kwargs: None)
    cfg = json.loads((Path(__file__).resolve().parents[1] / "config/federated/character_cnn.json").read_text())
    cfg.update(rounds=1, batch_size=8)
    cfg["model"]["sequence_length"] = 16
    synthetic_clients(tmp_path / "clients")

    class NetworkModel(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.linear = torch.nn.Linear(len(cfg["model"]["characters"]) + 1, 2)

        def forward(self, x):
            return self.linear(x.mean(dim=1))

    with socket.socket() as available:
        available.bind(("127.0.0.1", 0))
        port = available.getsockname()[1]
    address = f"127.0.0.1:{port}"
    strategy = FiveClientFedAvg(cfg, [NetworkModel()], output=tmp_path / "server")
    server = FederatedServer(client_manager=SimpleClientManager(), strategy=strategy)
    server.max_workers = 1
    errors = []

    def serve():
        try:
            fl.server.start_server(server_address=address, server=server,
                                   config=fl.server.ServerConfig(num_rounds=1), grpc_max_message_length=MAX_MESSAGE)
        except Exception as error:
            errors.append(error)

    def connect(cid):
        try:
            endpoint = URLFlowerClient(cid, tmp_path / "clients" / f"client_{cid:03d}", cfg,
                                       models=[NetworkModel()])
            fl.client.start_client(server_address=address, client=endpoint.to_client(),
                                   insecure=True, grpc_max_message_length=MAX_MESSAGE,
                                   max_retries=2, max_wait_time=30)
        except Exception as error:
            errors.append(error)

    workers = [threading.Thread(target=serve, daemon=True)]
    workers += [threading.Thread(target=connect, args=(cid,), daemon=True) for cid in range(5)]
    previous = torch.get_num_threads()
    torch.set_num_threads(1)
    try:
        for worker in workers:
            worker.start()
        for worker in workers:
            worker.join(timeout=45)
        assert not errors, errors
        assert not any(worker.is_alive() for worker in workers)
        assert len(strategy.round_reports[1]["clients"]) == 5
        assert strategy.round_reports[1]["val"]["n_records"] == 20
        assert (tmp_path / "server/global_final.npz").is_file()
    finally:
        torch.set_num_threads(previous)
